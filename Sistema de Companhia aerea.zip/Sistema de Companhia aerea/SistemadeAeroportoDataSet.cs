﻿namespace Sistema_de_compainha_aerea
{


    public partial class SistemadeAeroportoDataSet
    {
    }
}
namespace Sistema_de_compainha_aerea {
    
    
    public partial class SistemadeAeroportoDataSet {
    }
}
