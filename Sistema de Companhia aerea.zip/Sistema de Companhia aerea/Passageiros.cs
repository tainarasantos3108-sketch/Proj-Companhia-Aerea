﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Sistema_de_compainha_aerea
{
    public partial class Passageiros : Form
    {
       private int idPassageiro = 0;
       private string caminhoImagem = "";

        public Passageiros()
        {
            InitializeComponent();
        }

        private void Passageiros_Load(object sender, EventArgs e)
        {
            CarregarPassageiros();
            txtPassaporte.Enabled = false;
            txtPassaporte.ReadOnly = false;
            txtMilhas.Enabled = false;
            ckbAplicardesconto.Checked = false;
            ckbAplicardesconto.Enabled = false;

        }

        private void btnSalvarPassageiro_Click(object sender, EventArgs e)
        {
            try
            {
                Passageiro passageiro = new Passageiro();

                if (!ValidarPassageiro())
                {
                    return;
                }

                string nome = txtNomePassageiro.Text;
                string cpf = mtbCpfPassageiro.Text;
                string contato = mtbContatoPassageiro.Text;
                string email = txtEmailPassageiro.Text;
                DateTime dataNascimanto = dtpNascimentoPassageiro.Value;
                string nacionalidade = txtNacionalidade.Text;
                string passaporte = txtPassaporte.Text;
                char sexo;

                if (rbFeminino.Checked)
                {
                    sexo = 'F';
                }
                else
                {
                    sexo = 'M';
                }

                int milhas = 0;

                if (!string.IsNullOrWhiteSpace(txtMilhas.Text))
                {
                    milhas = Convert.ToInt32(txtMilhas.Text);
                }

                string foto = caminhoImagem;
                string observacao = txtObservacao.Text;

                string classe;

                if (rbClasseVip.Checked)
                {
                    classe = "VIP";
                }
                else
                {
                    classe = "Econômica";
                }

                string vooNI;

                if (rbNacional.Checked)
                {
                    vooNI = "Nacional";
                }
                else
                {
                    vooNI = "Internacional";
                }

                if (idPassageiro == 0)
                {
                    passageiro.SalvarPassageiro(nome, cpf, contato, email, dataNascimanto, nacionalidade, passaporte, sexo, foto, milhas, observacao, classe, vooNI);

                    MessageBox.Show("Passageiro salvo com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LimparCampos();
                    txtNomePassageiro.Focus();
                }
                else
                {
                    passageiro.AlterarPassageiro(idPassageiro, nome, cpf, contato, email, dataNascimanto, nacionalidade, passaporte, sexo, foto, milhas, observacao, classe, vooNI);
                    MessageBox.Show("Passageiro alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LimparCampos();
                    txtNomePassageiro.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar passageiro" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }                   

        private void btnNovoPassageiro_Click(object sender, EventArgs e)
        {
            LimparCampos();
            txtNomePassageiro.Focus();
        }

        private void btnExcluirPassageiro_Click(object sender, EventArgs e)
        {
            try
            {
                Passageiro passageiro = new Passageiro();
                passageiro.ExcluirPassageiro(idPassageiro);
                MessageBox.Show("Passageiro excluído com sucesso!", "Sucesso", MessageBoxButtons.OK,MessageBoxIcon.Information);
                LimparCampos();
                txtNomePassageiro.Focus();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao Excluir passageiro" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CarregarPassageiros()
        {
            Passageiro passageiro = new Passageiro();
            dgvListaPassageiro.DataSource = passageiro.ListarPassageiros();

            dgvListaPassageiro.Columns["ID_PASSAGEIRO"].HeaderText = "Código";
            dgvListaPassageiro.Columns["ID_PASSAGEIRO"].Width = 70;
            dgvListaPassageiro.Columns["NOME_PASSAGEIRO"].HeaderText = "Nome";
            dgvListaPassageiro.Columns["NOME_PASSAGEIRO"].Width = 180;
            dgvListaPassageiro.Columns["CPF_PASSAGEIRO"].HeaderText = "Cpf";
            dgvListaPassageiro.Columns["CPF_PASSaGEIRO"].Width = 120;
            dgvListaPassageiro.Columns["CONTATO_PASSAGEIRO"].HeaderText = "Contato";
            dgvListaPassageiro.Columns["CONTATO_PASSAGEIRO"].Width = 150;
            dgvListaPassageiro.Columns["DATA_NASCIMENTO"].HeaderText = "Nascimento";
            dgvListaPassageiro.Columns["DATA_NASCIMENTO"].Width = 110;
            dgvListaPassageiro.Columns["EMAIL_PASSAGEIRO"].Visible = false;
            dgvListaPassageiro.Columns["NACIONALIDADE"].HeaderText = "Nacionalidade";
            dgvListaPassageiro.Columns["NACIONALIDADE"].Width = 110;
            dgvListaPassageiro.Columns["PASSAPORTE"].HeaderText = "Passaporte";
            dgvListaPassageiro.Columns["PASSAPORTE"].Width = 110;
            dgvListaPassageiro.Columns["SEXO"].HeaderText = "Gênero";
            dgvListaPassageiro.Columns["SEXO"].Width = 100;
            dgvListaPassageiro.Columns["IMAGEM"].Visible = false;
            dgvListaPassageiro.Columns["MILHAS"].Visible = false;
            dgvListaPassageiro.Columns["OBSERVACAO"].Visible = false;
            dgvListaPassageiro.Columns["CLASSE"].HeaderText = "Classe";
            dgvListaPassageiro.Columns["CLASSE"].Width = 100;
            dgvListaPassageiro.Columns["VOO_N_I"].HeaderText = "Voo";
            dgvListaPassageiro.Columns["VOO_N_I"].Width = 110;


            if (!dgvListaPassageiro.Columns.Contains("EditarPassageiro"))
            {
                DataGridViewButtonColumn btnEditar = new DataGridViewButtonColumn();
                 
                btnEditar.Name = "EditarPassageiro";
                btnEditar.HeaderText = "Editar";
                btnEditar.Text = "Editar";
                btnEditar.UseColumnTextForButtonValue = true;
                dgvListaPassageiro.Columns.Add(btnEditar);
            }
        }

        private void dgvListaPassageiro_CellContentClick(object sender, DataGridViewCellEventArgs e)
        { 
            if (e.RowIndex >= 0 &&
                dgvListaPassageiro.Columns[e.ColumnIndex].Name == "EditarPassageiro")
            {
                idPassageiro = Convert.ToInt32(dgvListaPassageiro.Rows[e.RowIndex].Cells["ID_PASSAGEIRO"].Value);
                txtNomePassageiro.Text = dgvListaPassageiro.Rows[e.RowIndex].Cells["NOME_PASSAGEIRO"].Value.ToString();
                mtbCpfPassageiro.Text = dgvListaPassageiro.Rows[e.RowIndex].Cells["CPF_PASSAGEIRO"].Value.ToString();
                mtbContatoPassageiro.Text = dgvListaPassageiro.Rows[e.RowIndex].Cells["CONTATO_PASSAGEIRO"].Value.ToString();
                txtEmailPassageiro.Text = dgvListaPassageiro.Rows[e.RowIndex].Cells["EMAIL_PASSAGEIRO"].Value.ToString();
                dtpNascimentoPassageiro.Value = Convert.ToDateTime(dgvListaPassageiro.Rows[e.RowIndex].Cells["DATA_NASCIMENTO"].Value);
                txtMilhas.Text = dgvListaPassageiro.Rows[e.RowIndex].Cells["MILHAS"].Value.ToString();
                txtNacionalidade.Text = dgvListaPassageiro.Rows[e.RowIndex].Cells["NACIONALIDADE"].Value.ToString();
                txtPassaporte.Text = dgvListaPassageiro.Rows[e.RowIndex].Cells["PASSAPORTE"].Value.ToString();
                string sexo = dgvListaPassageiro.Rows[e.RowIndex].Cells["SEXO"].Value.ToString();

                if (sexo == "F")
                {
                    rbFeminino.Checked = true;
                }
                else if (sexo == "M")
                {
                    rbMasculino.Checked = true;
                }

                string classe = dgvListaPassageiro.Rows[e.RowIndex].Cells["CLASSE"].Value.ToString();

                if (classe == "VIP")
                {
                    rbClasseVip.Checked = true;
                }
                else if (classe == "Econômico")
                {
                    rbClasseEconomica.Checked = true;
                }

                object imagem = dgvListaPassageiro.Rows[e.RowIndex].Cells["IMAGEM"].Value;

                if (imagem != null && imagem != DBNull.Value)
                {
                    caminhoImagem = imagem.ToString();

                    if (File.Exists(caminhoImagem))
                    {
                        pbImagemPassageiro.Image = Image.FromFile(caminhoImagem);
                        pbImagemPassageiro.SizeMode = PictureBoxSizeMode.Zoom;
                    }
                    else
                    {
                        pbImagemPassageiro.Image = null;
                    }
                }
                else
                {
                    caminhoImagem = "";
                    pbImagemPassageiro.Image = null;
                }

                txtObservacao.Text = dgvListaPassageiro.Rows[e.RowIndex].Cells["OBSERVACAO"].Value == DBNull.Value? "": dgvListaPassageiro.Rows[e.RowIndex].Cells["OBSERVACAO"].Value.ToString();
            }
        }

        private void LimparCampos()
        {
            txtNomePassageiro.Clear();
            mtbCpfPassageiro.Clear();
            mtbContatoPassageiro.Clear();
            txtEmailPassageiro.Clear();
            dtpNascimentoPassageiro.Value = DateTime.Now;
            txtNacionalidade.Clear();
            txtPassaporte.Clear();
            rbFeminino.Checked = false;
            rbMasculino.Checked = false;
            rbClasseEconomica.Checked = false;
            rbClasseVip.Checked = false;
            txtObservacao.Clear();
            txtMilhas.Clear();
            pbImagemPassageiro.Image = null;
            caminhoImagem = "";
            txtPassaporte.Enabled = false;
            txtPassaporte.ReadOnly = false;
            txtMilhas.Enabled = false;
            ckbAplicardesconto.Checked = false;
            ckbAplicardesconto.Enabled = false;
        }

        private bool ValidarPassageiro()
        {
            if (string.IsNullOrWhiteSpace(txtNomePassageiro.Text))
            {
                MessageBox.Show("Preencha o nome do passageiro.");
                txtNomePassageiro.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(mtbCpfPassageiro.Text))
            {
                MessageBox.Show("Preencha o CPF do passageiro.");
                mtbCpfPassageiro.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtNacionalidade.Text))
            {
                MessageBox.Show("Preencha a nacionalidade do passageiro.");
                txtNacionalidade.Focus();
                return false;
            }

            return true;
        }

        private void btnSelecionaFotoPassageiro_Click(object sender, EventArgs e)
        {
            OpenFileDialog abrirFoto = new OpenFileDialog();
            abrirFoto.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp";

            if (abrirFoto.ShowDialog() == DialogResult.OK)
            {
                caminhoImagem = abrirFoto.FileName;

                pbImagemPassageiro.Load(abrirFoto.FileName);
                pbImagemPassageiro.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void btnRemoverFotoPassageiro_Click(object sender, EventArgs e)
        {
            pbImagemPassageiro.Image = null;
        }

        private void rbNacional_CheckedChanged(object sender, EventArgs e)
        {
            if (rbNacional.Checked)
            {
                txtPassaporte.Enabled = false;

                txtPassaporte.Clear();
            }
        }

        private void ckbAplicardesconto_CheckedChanged(object sender, EventArgs e)
        {
            if (ckbAplicardesconto.Checked)
            {
                int milhas = Convert.ToInt32(txtMilhas.Text);

                if (rbClasseVip.Checked && milhas >= 4500)
                {
                    MessageBox.Show(
                        "Desconto de 15% liberado para este passageiro!",
                        "Desconto",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                else
                {
                    MessageBox.Show(
                        "O desconto é exclusivo para clientes VIP com 4.500 milhas ou mais.",
                        "Desconto não disponível",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );

                    ckbAplicardesconto.Checked = false;
                }
            }
        }

        private void rbClasseVip_CheckedChanged(object sender, EventArgs e)
        {
            if (rbClasseVip.Checked)
            {
                txtMilhas.Enabled = true;
                ckbAplicardesconto.Enabled = true;
                txtMilhas.Focus();
            }
        }

        private void rbClasseEconomica_CheckedChanged(object sender, EventArgs e)
        {
            if (rbClasseEconomica.Checked)
            {
                txtMilhas.Clear();
                txtMilhas.Enabled = false;

                ckbAplicardesconto.Checked = false;
                ckbAplicardesconto.Enabled = false;
            }
        }

        private void rbInternacional_CheckedChanged(object sender, EventArgs e)
        {
            if (rbInternacional.Checked)
            {
                txtPassaporte.Enabled = true;
                txtPassaporte.ReadOnly = false;
                txtPassaporte.Focus();
                MessageBox.Show("Internacional ativado");
            }
        }
    }
}
