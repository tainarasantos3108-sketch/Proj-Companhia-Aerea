﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_de_compainha_aerea
{
    public partial class ClassePassageiros : Form
    {
        public ClassePassageiros()
        {
            InitializeComponent(); //Usa as intruções da classe Passageiro
        }

        private void btnCadastroPassageiro_Click(object sender, EventArgs e)
        {
            Passageiros passageiros = new Passageiros();
            passageiros.Show();
        }

        private void ClassePassageiros_Load(object sender, EventArgs e)
        {
            Passageiro passageiro = new Passageiro();
            dgvPesquisarPassageiros.DataSource = passageiro.ListarPassageiros();
        }

        private void btnPesquisarcadastroPassageiro_Click(object sender, EventArgs e)
        {
            Passageiro passageiro = new Passageiro();
            dgvPesquisarPassageiros.DataSource = passageiro.PesquisarPassageiro(txtNomePesquisarPassageiro.Text, txtcpfPesquisarPassageiro.Text, txtPassaportePesquisar.Text);
        }
    }
}
