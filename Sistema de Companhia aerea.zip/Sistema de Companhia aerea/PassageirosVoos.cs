﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_de_compainha_aerea
{
    public class PassageirosVoos
    {
        public void SalvarPassageiroVoo(int idPassageiro, int idVoo)
        {
           using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
                {
                    string sql = @"INSERT INTO PASSAGEIROS_VOOS
                           (ID_PASSAGEIRO, ID_VOO)
                           VALUES
                           (@idPassageiro, @idVoo)";

                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@idPassageiro", idPassageiro);
                        comando.Parameters.AddWithValue("@idVoo", idVoo);

                        conexao.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }

        public void ExcluirPassageiroVoo(int idPassageiro, int idVoo)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"DELETE FROM PASSAGEIROS_VOOS WHERE ID_PASSAGEIRO = @idPassageiro AND ID_VOO = @idVoo";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@idPassageiro", idPassageiro);
                    comando.Parameters.AddWithValue("@idVoo", idVoo);

                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

    }
 }

