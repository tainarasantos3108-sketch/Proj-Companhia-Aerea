﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_compainha_aerea
{
    public class Pagamento
    {
        public DataTable ListarAgendados()
        {
            DataTable dados = new DataTable();

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"SELECT P.ID_PASSAGEIRO, P.NOME_PASSAGEIRO, P.CPF_PASSAGEIRO, P.PASSAPORTE, P.CLASSE, V.ID_VOO, V.ORIGEM, V.DESTINO, V.DATA_HORA_PARTIDA, V.DATA_HORA_CHEGADA, V.STATUS FROM PASSAGEIROS P INNER JOIN PASSAGEIROS_VOOS PV ON P.ID_PASSAGEIRO = PV.ID_PASSAGEIRO INNER JOIN VOOS V ON PV.ID_VOO = V.ID_VOO WHERE V.STATUS = 'Confirmado'";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        adapter.Fill(dados);
                    }
                }
            }

            return dados;
        }

        public void SalvarPagamento(int idPassageiro, int idVoo, decimal valor, DateTime dataPagamento, string formaPagamento, string estadoPagamento)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"INSERT INTO PAGAMENTOS (ID_PASSAGEIRO, ID_VOO, VALOR, DATA_PAGAMENTO, FORMA_PAGAMENTO, STATUS_PAGAMENTO) VALUES (@idPassageiro, @idVoo, @valor, @dataPagamento, @formaPagamento, @statusPagamento)";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@idPassageiro", idPassageiro);
                    comando.Parameters.AddWithValue("@idVoo", idVoo);
                    comando.Parameters.AddWithValue("@valor", valor);
                    comando.Parameters.AddWithValue("@dataPagamento", dataPagamento);
                    comando.Parameters.AddWithValue("@formaPagamento", formaPagamento);
                    comando.Parameters.AddWithValue("@statusPagamento", estadoPagamento);

                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public void AlterarPagamento(int idPagamento, int idPassageiro, int idVoo, decimal valor, DateTime dataPagamento, string formaPagamento, string statusPagamento)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"UPDATE PAGAMENTOS SET ID_PASSAGEIRO = @idPassageiro, ID_VOO = @idVoo, VALOR = @valor, DATA_PAGAMENTO = @dataPagamento, FORMA_PAGAMENTO = @formaPagamento, STATUS_PAGAMENTO = @statusPagamento WHERE ID_PAGAMENTO = @idPagamento";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@idPagamento", idPagamento);
                    comando.Parameters.AddWithValue("@idPassageiro", idPassageiro);
                    comando.Parameters.AddWithValue("@idVoo", idVoo);
                    comando.Parameters.AddWithValue("@valor", valor);
                    comando.Parameters.AddWithValue("@dataPagamento", dataPagamento);
                    comando.Parameters.AddWithValue("@formaPagamento", formaPagamento);
                    comando.Parameters.AddWithValue("@statusPagamento", statusPagamento);
                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public DataTable ListarPagamentos()
        {
            DataTable dados = new DataTable();

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"SELECT PG.ID_PAGAMENTO, P.NOME_PASSAGEIRO, PG.VALOR, PG.STATUS_PAGAMENTO, PG.DATA_PAGAMENTO FROM PAGAMENTOS PG INNER JOIN PASSAGEIROS P ON PG.ID_PASSAGEIRO = P.ID_PASSAGEIRO";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        adapter.Fill(dados);
                    }
                }

                return dados;
            }
        }

        public DataTable BuscarDadosPagamento(int idPagamento)
        {
            DataTable dados = new DataTable();

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"SELECT PG.ID_PASSAGEIRO, PG.ID_VOO, P.NOME_PASSAGEIRO, PG.VALOR, PG.STATUS_PAGAMENTO, PG.DATA_PAGAMENTO, PG.FORMA_PAGAMENTO FROM PAGAMENTOS PG INNER JOIN PASSAGEIROS P ON PG.ID_PASSAGEIRO = P.ID_PASSAGEIRO  WHERE PG.ID_PAGAMENTO = @idPagamento";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@idPagamento", idPagamento);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        adapter.Fill(dados);
                    }
                }
            }

            return dados;
        }

        public int BuscarVooDoPassageiro(int idPassageiro)
        {
            int idVoo = 0;

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"SELECT TOP 1 ID_VOO FROM PASSAGEIROS_VOOS WHERE ID_PASSAGEIRO = @idPassageiro";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@idPassageiro", idPassageiro);
                    conexao.Open();

                    object resultado = comando.ExecuteScalar();

                    if (resultado != null)
                    {
                        idVoo = Convert.ToInt32(resultado);
                    }
                }
            }

            return idVoo;
        }

        public DataTable BuscarClasseEMilhas(int idPassageiro)
        {
            DataTable dados = new DataTable();

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"SELECT CLASSE, MILHAS FROM PASSAGEIROS WHERE ID_PASSAGEIRO = @idPassageiro";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@idPassageiro", idPassageiro);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        adapter.Fill(dados);
                    }
                }
            }

            return dados;
        }

        public void ExcluirPagamento(int idPagamento)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"DELETE FROM PAGAMENTOS
                       WHERE ID_PAGAMENTO = @idPagamento";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@idPagamento", idPagamento);

                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

    }
}
