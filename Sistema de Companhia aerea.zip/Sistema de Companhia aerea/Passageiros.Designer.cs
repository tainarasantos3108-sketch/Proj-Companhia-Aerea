﻿namespace Sistema_de_compainha_aerea
{
    partial class Passageiros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbMasculino = new System.Windows.Forms.RadioButton();
            this.rbFeminino = new System.Windows.Forms.RadioButton();
            this.txtPassaporte = new System.Windows.Forms.TextBox();
            this.txtNacionalidade = new System.Windows.Forms.TextBox();
            this.txtEmailPassageiro = new System.Windows.Forms.TextBox();
            this.mtbContatoPassageiro = new System.Windows.Forms.MaskedTextBox();
            this.dtpNascimentoPassageiro = new System.Windows.Forms.DateTimePicker();
            this.mtbCpfPassageiro = new System.Windows.Forms.MaskedTextBox();
            this.txtNomePassageiro = new System.Windows.Forms.TextBox();
            this.btnNovoPassageiro = new System.Windows.Forms.Button();
            this.btnExcluirPassageiro = new System.Windows.Forms.Button();
            this.btnSalvarPassageiro = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pbImagemPassageiro = new System.Windows.Forms.PictureBox();
            this.btnRemoverFotoPassageiro = new System.Windows.Forms.Button();
            this.btnSelecionaFotoPassageiro = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtObservacao = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rbClasseVip = new System.Windows.Forms.RadioButton();
            this.rbClasseEconomica = new System.Windows.Forms.RadioButton();
            this.gpbDesconto = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.ckbAplicardesconto = new System.Windows.Forms.CheckBox();
            this.txtMilhas = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dgvListaPassageiro = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.rbInternacional = new System.Windows.Forms.RadioButton();
            this.rbNacional = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImagemPassageiro)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.gpbDesconto.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaPassageiro)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(40, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(227, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ficha de Passageiros";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbMasculino);
            this.groupBox1.Controls.Add(this.rbFeminino);
            this.groupBox1.Controls.Add(this.txtPassaporte);
            this.groupBox1.Controls.Add(this.txtNacionalidade);
            this.groupBox1.Controls.Add(this.txtEmailPassageiro);
            this.groupBox1.Controls.Add(this.mtbContatoPassageiro);
            this.groupBox1.Controls.Add(this.dtpNascimentoPassageiro);
            this.groupBox1.Controls.Add(this.mtbCpfPassageiro);
            this.groupBox1.Controls.Add(this.txtNomePassageiro);
            this.groupBox1.Controls.Add(this.btnNovoPassageiro);
            this.groupBox1.Controls.Add(this.btnExcluirPassageiro);
            this.groupBox1.Controls.Add(this.btnSalvarPassageiro);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(24, 78);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(694, 342);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dados do Passageiro";
            // 
            // rbMasculino
            // 
            this.rbMasculino.AutoSize = true;
            this.rbMasculino.Location = new System.Drawing.Point(524, 268);
            this.rbMasculino.Name = "rbMasculino";
            this.rbMasculino.Size = new System.Drawing.Size(47, 27);
            this.rbMasculino.TabIndex = 22;
            this.rbMasculino.TabStop = true;
            this.rbMasculino.Text = "M";
            this.rbMasculino.UseVisualStyleBackColor = true;
            // 
            // rbFeminino
            // 
            this.rbFeminino.AutoSize = true;
            this.rbFeminino.Location = new System.Drawing.Point(466, 270);
            this.rbFeminino.Name = "rbFeminino";
            this.rbFeminino.Size = new System.Drawing.Size(40, 27);
            this.rbFeminino.TabIndex = 21;
            this.rbFeminino.TabStop = true;
            this.rbFeminino.Text = "F";
            this.rbFeminino.UseVisualStyleBackColor = true;
            // 
            // txtPassaporte
            // 
            this.txtPassaporte.Location = new System.Drawing.Point(158, 263);
            this.txtPassaporte.Name = "txtPassaporte";
            this.txtPassaporte.Size = new System.Drawing.Size(207, 30);
            this.txtPassaporte.TabIndex = 20;
            // 
            // txtNacionalidade
            // 
            this.txtNacionalidade.Location = new System.Drawing.Point(158, 221);
            this.txtNacionalidade.Name = "txtNacionalidade";
            this.txtNacionalidade.Size = new System.Drawing.Size(361, 30);
            this.txtNacionalidade.TabIndex = 19;
            // 
            // txtEmailPassageiro
            // 
            this.txtEmailPassageiro.Location = new System.Drawing.Point(102, 172);
            this.txtEmailPassageiro.Name = "txtEmailPassageiro";
            this.txtEmailPassageiro.Size = new System.Drawing.Size(417, 30);
            this.txtEmailPassageiro.TabIndex = 18;
            // 
            // mtbContatoPassageiro
            // 
            this.mtbContatoPassageiro.Location = new System.Drawing.Point(102, 129);
            this.mtbContatoPassageiro.Mask = "(99) 9 0000-0000";
            this.mtbContatoPassageiro.Name = "mtbContatoPassageiro";
            this.mtbContatoPassageiro.Size = new System.Drawing.Size(156, 30);
            this.mtbContatoPassageiro.TabIndex = 17;
            // 
            // dtpNascimentoPassageiro
            // 
            this.dtpNascimentoPassageiro.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNascimentoPassageiro.Location = new System.Drawing.Point(364, 86);
            this.dtpNascimentoPassageiro.Name = "dtpNascimentoPassageiro";
            this.dtpNascimentoPassageiro.Size = new System.Drawing.Size(155, 30);
            this.dtpNascimentoPassageiro.TabIndex = 16;
            // 
            // mtbCpfPassageiro
            // 
            this.mtbCpfPassageiro.Location = new System.Drawing.Point(102, 82);
            this.mtbCpfPassageiro.Mask = "000.000.000-00";
            this.mtbCpfPassageiro.Name = "mtbCpfPassageiro";
            this.mtbCpfPassageiro.Size = new System.Drawing.Size(141, 30);
            this.mtbCpfPassageiro.TabIndex = 15;
            // 
            // txtNomePassageiro
            // 
            this.txtNomePassageiro.Location = new System.Drawing.Point(102, 34);
            this.txtNomePassageiro.Name = "txtNomePassageiro";
            this.txtNomePassageiro.Size = new System.Drawing.Size(417, 30);
            this.txtNomePassageiro.TabIndex = 14;
            // 
            // btnNovoPassageiro
            // 
            this.btnNovoPassageiro.Location = new System.Drawing.Point(562, 30);
            this.btnNovoPassageiro.Name = "btnNovoPassageiro";
            this.btnNovoPassageiro.Size = new System.Drawing.Size(103, 37);
            this.btnNovoPassageiro.TabIndex = 10;
            this.btnNovoPassageiro.Text = "Novo";
            this.btnNovoPassageiro.UseVisualStyleBackColor = true;
            this.btnNovoPassageiro.Click += new System.EventHandler(this.btnNovoPassageiro_Click);
            // 
            // btnExcluirPassageiro
            // 
            this.btnExcluirPassageiro.Location = new System.Drawing.Point(562, 129);
            this.btnExcluirPassageiro.Name = "btnExcluirPassageiro";
            this.btnExcluirPassageiro.Size = new System.Drawing.Size(103, 32);
            this.btnExcluirPassageiro.TabIndex = 9;
            this.btnExcluirPassageiro.Text = "Excluir";
            this.btnExcluirPassageiro.UseVisualStyleBackColor = true;
            this.btnExcluirPassageiro.Click += new System.EventHandler(this.btnExcluirPassageiro_Click);
            // 
            // btnSalvarPassageiro
            // 
            this.btnSalvarPassageiro.Location = new System.Drawing.Point(562, 77);
            this.btnSalvarPassageiro.Name = "btnSalvarPassageiro";
            this.btnSalvarPassageiro.Size = new System.Drawing.Size(103, 39);
            this.btnSalvarPassageiro.TabIndex = 8;
            this.btnSalvarPassageiro.Text = "Salvar";
            this.btnSalvarPassageiro.UseVisualStyleBackColor = true;
            this.btnSalvarPassageiro.Click += new System.EventHandler(this.btnSalvarPassageiro_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(390, 270);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 23);
            this.label9.TabIndex = 7;
            this.label9.Text = "Gênero:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(253, 92);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 23);
            this.label8.TabIndex = 6;
            this.label8.Text = "Nascimento:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 270);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 23);
            this.label7.TabIndex = 5;
            this.label7.Text = "ℹ️Passaporte:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 224);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 23);
            this.label6.TabIndex = 4;
            this.label6.Text = "Nacionalidade:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 23);
            this.label5.TabIndex = 3;
            this.label5.Text = "E-mail:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 23);
            this.label4.TabIndex = 2;
            this.label4.Text = "Telefone:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 23);
            this.label3.TabIndex = 1;
            this.label3.Text = "CPF:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nome:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pbImagemPassageiro);
            this.groupBox2.Controls.Add(this.btnRemoverFotoPassageiro);
            this.groupBox2.Controls.Add(this.btnSelecionaFotoPassageiro);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox2.Location = new System.Drawing.Point(739, 78);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(319, 342);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Foto";
            // 
            // pbImagemPassageiro
            // 
            this.pbImagemPassageiro.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pbImagemPassageiro.Location = new System.Drawing.Point(21, 44);
            this.pbImagemPassageiro.Name = "pbImagemPassageiro";
            this.pbImagemPassageiro.Size = new System.Drawing.Size(159, 203);
            this.pbImagemPassageiro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImagemPassageiro.TabIndex = 13;
            this.pbImagemPassageiro.TabStop = false;
            // 
            // btnRemoverFotoPassageiro
            // 
            this.btnRemoverFotoPassageiro.Location = new System.Drawing.Point(202, 86);
            this.btnRemoverFotoPassageiro.Name = "btnRemoverFotoPassageiro";
            this.btnRemoverFotoPassageiro.Size = new System.Drawing.Size(97, 40);
            this.btnRemoverFotoPassageiro.TabIndex = 12;
            this.btnRemoverFotoPassageiro.Text = "Remover";
            this.btnRemoverFotoPassageiro.UseVisualStyleBackColor = true;
            this.btnRemoverFotoPassageiro.Click += new System.EventHandler(this.btnRemoverFotoPassageiro_Click);
            // 
            // btnSelecionaFotoPassageiro
            // 
            this.btnSelecionaFotoPassageiro.Location = new System.Drawing.Point(202, 44);
            this.btnSelecionaFotoPassageiro.Name = "btnSelecionaFotoPassageiro";
            this.btnSelecionaFotoPassageiro.Size = new System.Drawing.Size(97, 32);
            this.btnSelecionaFotoPassageiro.TabIndex = 11;
            this.btnSelecionaFotoPassageiro.Text = "Seleciona";
            this.btnSelecionaFotoPassageiro.UseVisualStyleBackColor = true;
            this.btnSelecionaFotoPassageiro.Click += new System.EventHandler(this.btnSelecionaFotoPassageiro_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txtObservacao);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox3.Location = new System.Drawing.Point(1076, 78);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(400, 342);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Observação";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(17, 267);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(234, 23);
            this.label16.TabIndex = 28;
            this.label16.Text = "Limite de caracteres de 0/200";
            // 
            // txtObservacao
            // 
            this.txtObservacao.Location = new System.Drawing.Point(21, 34);
            this.txtObservacao.MaxLength = 200;
            this.txtObservacao.Multiline = true;
            this.txtObservacao.Name = "txtObservacao";
            this.txtObservacao.Size = new System.Drawing.Size(362, 217);
            this.txtObservacao.TabIndex = 27;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rbClasseVip);
            this.groupBox5.Controls.Add(this.rbClasseEconomica);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox5.Location = new System.Drawing.Point(450, 456);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(189, 180);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Classe";
            // 
            // rbClasseVip
            // 
            this.rbClasseVip.AutoSize = true;
            this.rbClasseVip.Location = new System.Drawing.Point(16, 90);
            this.rbClasseVip.Name = "rbClasseVip";
            this.rbClasseVip.Size = new System.Drawing.Size(56, 27);
            this.rbClasseVip.TabIndex = 26;
            this.rbClasseVip.TabStop = true;
            this.rbClasseVip.Text = "Vip";
            this.rbClasseVip.UseVisualStyleBackColor = true;
            this.rbClasseVip.CheckedChanged += new System.EventHandler(this.rbClasseVip_CheckedChanged);
            // 
            // rbClasseEconomica
            // 
            this.rbClasseEconomica.AutoSize = true;
            this.rbClasseEconomica.Location = new System.Drawing.Point(16, 40);
            this.rbClasseEconomica.Name = "rbClasseEconomica";
            this.rbClasseEconomica.Size = new System.Drawing.Size(114, 27);
            this.rbClasseEconomica.TabIndex = 25;
            this.rbClasseEconomica.TabStop = true;
            this.rbClasseEconomica.Text = "Economica";
            this.rbClasseEconomica.UseVisualStyleBackColor = true;
            this.rbClasseEconomica.CheckedChanged += new System.EventHandler(this.rbClasseEconomica_CheckedChanged);
            // 
            // gpbDesconto
            // 
            this.gpbDesconto.Controls.Add(this.label15);
            this.gpbDesconto.Controls.Add(this.groupBox7);
            this.gpbDesconto.Controls.Add(this.txtMilhas);
            this.gpbDesconto.Controls.Add(this.label12);
            this.gpbDesconto.Controls.Add(this.label11);
            this.gpbDesconto.Controls.Add(this.label10);
            this.gpbDesconto.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.gpbDesconto.Location = new System.Drawing.Point(657, 456);
            this.gpbDesconto.Margin = new System.Windows.Forms.Padding(4);
            this.gpbDesconto.Name = "gpbDesconto";
            this.gpbDesconto.Padding = new System.Windows.Forms.Padding(4);
            this.gpbDesconto.Size = new System.Drawing.Size(822, 180);
            this.gpbDesconto.TabIndex = 0;
            this.gpbDesconto.TabStop = false;
            this.gpbDesconto.Text = "ℹ️ Desconto";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label15.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label15.Location = new System.Drawing.Point(24, 136);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(325, 23);
            this.label15.TabIndex = 28;
            this.label15.Text = "ℹ️ Desconto aplicado automaticamente ";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.ckbAplicardesconto);
            this.groupBox7.Location = new System.Drawing.Point(397, 30);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(403, 129);
            this.groupBox7.TabIndex = 27;
            this.groupBox7.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Green;
            this.label14.Location = new System.Drawing.Point(45, 90);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(291, 23);
            this.label14.TabIndex = 2;
            this.label14.Text = "Desconto aplicado automaticamente";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label13.Location = new System.Drawing.Point(6, 41);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(340, 46);
            this.label13.TabIndex = 1;
            this.label13.Text = "Disponivel apenas a cliente vip\'s com milha\r\naparte de 4.500 ou mais.";
            // 
            // ckbAplicardesconto
            // 
            this.ckbAplicardesconto.AutoSize = true;
            this.ckbAplicardesconto.ForeColor = System.Drawing.Color.Green;
            this.ckbAplicardesconto.Location = new System.Drawing.Point(6, 11);
            this.ckbAplicardesconto.Name = "ckbAplicardesconto";
            this.ckbAplicardesconto.Size = new System.Drawing.Size(223, 27);
            this.ckbAplicardesconto.TabIndex = 0;
            this.ckbAplicardesconto.Text = "Aplicar 15% de desconto ";
            this.ckbAplicardesconto.UseVisualStyleBackColor = true;
            this.ckbAplicardesconto.CheckedChanged += new System.EventHandler(this.ckbAplicardesconto_CheckedChanged);
            // 
            // txtMilhas
            // 
            this.txtMilhas.Location = new System.Drawing.Point(185, 33);
            this.txtMilhas.Name = "txtMilhas";
            this.txtMilhas.Size = new System.Drawing.Size(197, 30);
            this.txtMilhas.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Green;
            this.label12.Location = new System.Drawing.Point(298, 79);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 23);
            this.label12.TabIndex = 25;
            this.label12.Text = "4.500";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 79);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(268, 23);
            this.label11.TabIndex = 24;
            this.label11.Text = "Milhas necessárias para beneficio:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(155, 23);
            this.label10.TabIndex = 23;
            this.label10.Text = "Número de milhas:";
            // 
            // dgvListaPassageiro
            // 
            this.dgvListaPassageiro.AllowUserToAddRows = false;
            this.dgvListaPassageiro.AllowUserToDeleteRows = false;
            this.dgvListaPassageiro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaPassageiro.Location = new System.Drawing.Point(24, 660);
            this.dgvListaPassageiro.Margin = new System.Windows.Forms.Padding(4);
            this.dgvListaPassageiro.Name = "dgvListaPassageiro";
            this.dgvListaPassageiro.ReadOnly = true;
            this.dgvListaPassageiro.RowHeadersVisible = false;
            this.dgvListaPassageiro.RowHeadersWidth = 51;
            this.dgvListaPassageiro.RowTemplate.Height = 24;
            this.dgvListaPassageiro.Size = new System.Drawing.Size(1366, 305);
            this.dgvListaPassageiro.TabIndex = 4;
            this.dgvListaPassageiro.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListaPassageiro_CellContentClick);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.rbInternacional);
            this.groupBox6.Controls.Add(this.rbNacional);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox6.Location = new System.Drawing.Point(24, 456);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(409, 180);
            this.groupBox6.TabIndex = 11;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Tipo de voo";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label17.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label17.Location = new System.Drawing.Point(18, 92);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(343, 69);
            this.label17.TabIndex = 28;
            this.label17.Text = "ℹ️ Para voos internacionais \r\no preenchimentos do campo do passaporte\r\ne obrigato" +
    "rio!";
            // 
            // rbInternacional
            // 
            this.rbInternacional.AutoSize = true;
            this.rbInternacional.Location = new System.Drawing.Point(149, 30);
            this.rbInternacional.Name = "rbInternacional";
            this.rbInternacional.Size = new System.Drawing.Size(131, 27);
            this.rbInternacional.TabIndex = 24;
            this.rbInternacional.TabStop = true;
            this.rbInternacional.Text = "Internacional";
            this.rbInternacional.UseVisualStyleBackColor = true;
            this.rbInternacional.CheckedChanged += new System.EventHandler(this.rbInternacional_CheckedChanged);
            // 
            // rbNacional
            // 
            this.rbNacional.AutoSize = true;
            this.rbNacional.Location = new System.Drawing.Point(18, 29);
            this.rbNacional.Name = "rbNacional";
            this.rbNacional.Size = new System.Drawing.Size(98, 27);
            this.rbNacional.TabIndex = 23;
            this.rbNacional.TabStop = true;
            this.rbNacional.Text = "Nacional";
            this.rbNacional.UseVisualStyleBackColor = true;
            this.rbNacional.CheckedChanged += new System.EventHandler(this.rbNacional_CheckedChanged);
            // 
            // Passageiros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1513, 1055);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.dgvListaPassageiro);
            this.Controls.Add(this.gpbDesconto);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Passageiros";
            this.Text = "Passageiros";
            this.Load += new System.EventHandler(this.Passageiros_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbImagemPassageiro)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.gpbDesconto.ResumeLayout(false);
            this.gpbDesconto.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaPassageiro)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox gpbDesconto;
        private System.Windows.Forms.DataGridView dgvListaPassageiro;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpNascimentoPassageiro;
        private System.Windows.Forms.MaskedTextBox mtbCpfPassageiro;
        private System.Windows.Forms.TextBox txtNomePassageiro;
        private System.Windows.Forms.Button btnNovoPassageiro;
        private System.Windows.Forms.Button btnExcluirPassageiro;
        private System.Windows.Forms.Button btnSalvarPassageiro;
        private System.Windows.Forms.PictureBox pbImagemPassageiro;
        private System.Windows.Forms.Button btnRemoverFotoPassageiro;
        private System.Windows.Forms.Button btnSelecionaFotoPassageiro;
        private System.Windows.Forms.RadioButton rbMasculino;
        private System.Windows.Forms.RadioButton rbFeminino;
        private System.Windows.Forms.TextBox txtPassaporte;
        private System.Windows.Forms.TextBox txtNacionalidade;
        private System.Windows.Forms.TextBox txtEmailPassageiro;
        private System.Windows.Forms.MaskedTextBox mtbContatoPassageiro;
        private System.Windows.Forms.RadioButton rbClasseVip;
        private System.Windows.Forms.RadioButton rbClasseEconomica;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtMilhas;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox ckbAplicardesconto;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtObservacao;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton rbInternacional;
        private System.Windows.Forms.RadioButton rbNacional;
    }
}