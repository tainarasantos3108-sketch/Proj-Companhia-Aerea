﻿namespace Sistema_de_compainha_aerea
{
    partial class Voos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbStatusVoos = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.btnNovoVoo = new System.Windows.Forms.Button();
            this.txtDestino = new System.Windows.Forms.TextBox();
            this.txtOrigem = new System.Windows.Forms.TextBox();
            this.cmbTerminal = new System.Windows.Forms.ComboBox();
            this.cmbPortao = new System.Windows.Forms.ComboBox();
            this.dtpHoraChegada = new System.Windows.Forms.DateTimePicker();
            this.dtpDataChegada = new System.Windows.Forms.DateTimePicker();
            this.dtpHoraPartida = new System.Windows.Forms.DateTimePicker();
            this.dtpDataPartida = new System.Windows.Forms.DateTimePicker();
            this.cmbTipoVoo = new System.Windows.Forms.ComboBox();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnBuscarVoos = new System.Windows.Forms.Button();
            this.dtpBuscarDataVoo = new System.Windows.Forms.DateTimePicker();
            this.txtBuscarVoos = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnExcluirvoos = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.btnLimparVoo = new System.Windows.Forms.Button();
            this.btnSalvarVoos = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dgvVoos = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVoos)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbStatusVoos);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.btnNovoVoo);
            this.groupBox1.Controls.Add(this.txtDestino);
            this.groupBox1.Controls.Add(this.txtOrigem);
            this.groupBox1.Controls.Add(this.cmbTerminal);
            this.groupBox1.Controls.Add(this.cmbPortao);
            this.groupBox1.Controls.Add(this.dtpHoraChegada);
            this.groupBox1.Controls.Add(this.dtpDataChegada);
            this.groupBox1.Controls.Add(this.dtpHoraPartida);
            this.groupBox1.Controls.Add(this.dtpDataPartida);
            this.groupBox1.Controls.Add(this.cmbTipoVoo);
            this.groupBox1.Controls.Add(this.txtCodigo);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(31, 39);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(458, 641);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dados Voos";
            // 
            // cmbStatusVoos
            // 
            this.cmbStatusVoos.FormattingEnabled = true;
            this.cmbStatusVoos.Items.AddRange(new object[] {
            "",
            "Pedente",
            "Confirmado",
            "Cancelado"});
            this.cmbStatusVoos.Location = new System.Drawing.Point(210, 510);
            this.cmbStatusVoos.Name = "cmbStatusVoos";
            this.cmbStatusVoos.Size = new System.Drawing.Size(228, 31);
            this.cmbStatusVoos.TabIndex = 23;
            // 
            // label43
            // 
            this.label43.Location = new System.Drawing.Point(32, 518);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(65, 23);
            this.label43.TabIndex = 0;
            this.label43.Text = "Status:";
            // 
            // btnNovoVoo
            // 
            this.btnNovoVoo.BackColor = System.Drawing.Color.Transparent;
            this.btnNovoVoo.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btnNovoVoo.Image = global::Sistema_de_compainha_aerea.Properties.Resources.Design_sem_nome__10_;
            this.btnNovoVoo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnNovoVoo.Location = new System.Drawing.Point(30, 553);
            this.btnNovoVoo.Name = "btnNovoVoo";
            this.btnNovoVoo.Size = new System.Drawing.Size(74, 64);
            this.btnNovoVoo.TabIndex = 22;
            this.btnNovoVoo.Text = "Novo";
            this.btnNovoVoo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNovoVoo.UseVisualStyleBackColor = false;
            this.btnNovoVoo.Click += new System.EventHandler(this.btnNovoVoo_Click);
            // 
            // txtDestino
            // 
            this.txtDestino.Location = new System.Drawing.Point(210, 194);
            this.txtDestino.Name = "txtDestino";
            this.txtDestino.Size = new System.Drawing.Size(228, 30);
            this.txtDestino.TabIndex = 21;
            this.txtDestino.TextChanged += new System.EventHandler(this.txtDestino_TextChanged);
            // 
            // txtOrigem
            // 
            this.txtOrigem.Location = new System.Drawing.Point(210, 148);
            this.txtOrigem.Name = "txtOrigem";
            this.txtOrigem.Size = new System.Drawing.Size(224, 30);
            this.txtOrigem.TabIndex = 20;
            this.txtOrigem.TextChanged += new System.EventHandler(this.txtOrigem_TextChanged);
            // 
            // cmbTerminal
            // 
            this.cmbTerminal.FormattingEnabled = true;
            this.cmbTerminal.Items.AddRange(new object[] {
            "",
            "Terminal 01",
            "Terminal 02",
            "Terminal 03"});
            this.cmbTerminal.Location = new System.Drawing.Point(210, 465);
            this.cmbTerminal.Name = "cmbTerminal";
            this.cmbTerminal.Size = new System.Drawing.Size(228, 31);
            this.cmbTerminal.TabIndex = 19;
            this.cmbTerminal.SelectedIndexChanged += new System.EventHandler(this.cmbTerminal_SelectedIndexChanged);
            // 
            // cmbPortao
            // 
            this.cmbPortao.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPortao.FormattingEnabled = true;
            this.cmbPortao.Items.AddRange(new object[] {
            "",
            "Portão A",
            "Portão B",
            "Portão C"});
            this.cmbPortao.Location = new System.Drawing.Point(210, 418);
            this.cmbPortao.Name = "cmbPortao";
            this.cmbPortao.Size = new System.Drawing.Size(228, 31);
            this.cmbPortao.TabIndex = 18;
            this.cmbPortao.SelectedIndexChanged += new System.EventHandler(this.cmbPortao_SelectedIndexChanged);
            // 
            // dtpHoraChegada
            // 
            this.dtpHoraChegada.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpHoraChegada.Location = new System.Drawing.Point(210, 371);
            this.dtpHoraChegada.Name = "dtpHoraChegada";
            this.dtpHoraChegada.Size = new System.Drawing.Size(228, 30);
            this.dtpHoraChegada.TabIndex = 17;
            // 
            // dtpDataChegada
            // 
            this.dtpDataChegada.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDataChegada.Location = new System.Drawing.Point(210, 327);
            this.dtpDataChegada.Name = "dtpDataChegada";
            this.dtpDataChegada.Size = new System.Drawing.Size(228, 30);
            this.dtpDataChegada.TabIndex = 16;
            // 
            // dtpHoraPartida
            // 
            this.dtpHoraPartida.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpHoraPartida.Location = new System.Drawing.Point(210, 284);
            this.dtpHoraPartida.Name = "dtpHoraPartida";
            this.dtpHoraPartida.Size = new System.Drawing.Size(228, 30);
            this.dtpHoraPartida.TabIndex = 15;
            this.dtpHoraPartida.ValueChanged += new System.EventHandler(this.dtpHoraPartida_ValueChanged);
            // 
            // dtpDataPartida
            // 
            this.dtpDataPartida.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDataPartida.Location = new System.Drawing.Point(210, 240);
            this.dtpDataPartida.Name = "dtpDataPartida";
            this.dtpDataPartida.Size = new System.Drawing.Size(228, 30);
            this.dtpDataPartida.TabIndex = 14;
            this.dtpDataPartida.ValueChanged += new System.EventHandler(this.dtpDataPartida_ValueChanged);
            // 
            // cmbTipoVoo
            // 
            this.cmbTipoVoo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoVoo.FormattingEnabled = true;
            this.cmbTipoVoo.Items.AddRange(new object[] {
            "",
            "Nacional",
            "Internacional"});
            this.cmbTipoVoo.Location = new System.Drawing.Point(210, 105);
            this.cmbTipoVoo.Name = "cmbTipoVoo";
            this.cmbTipoVoo.Size = new System.Drawing.Size(224, 31);
            this.cmbTipoVoo.TabIndex = 11;
            this.cmbTipoVoo.SelectedIndexChanged += new System.EventHandler(this.cmbTipoVoo_SelectedIndexChanged);
            // 
            // txtCodigo
            // 
            this.txtCodigo.Enabled = false;
            this.txtCodigo.Location = new System.Drawing.Point(210, 64);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(110, 30);
            this.txtCodigo.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(26, 473);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 23);
            this.label10.TabIndex = 9;
            this.label10.Text = "Terminal:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(26, 426);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 23);
            this.label9.TabIndex = 8;
            this.label9.Text = "Portão:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(26, 377);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(166, 23);
            this.label8.TabIndex = 7;
            this.label8.Text = "Horário de chegada:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 334);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 23);
            this.label7.TabIndex = 6;
            this.label7.Text = "Data  de Chegada:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 290);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 23);
            this.label6.TabIndex = 5;
            this.label6.Text = "Horário de partida:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 247);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 23);
            this.label5.TabIndex = 4;
            this.label5.Text = "Data de partida:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 201);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "Destino:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Origem:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tipo de voo:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número do voo:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label50);
            this.groupBox2.Controls.Add(this.label49);
            this.groupBox2.Controls.Add(this.label48);
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox2.Location = new System.Drawing.Point(519, 39);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(621, 314);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Informações do voo";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label50.Location = new System.Drawing.Point(82, 263);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(83, 25);
            this.label50.TabIndex = 16;
            this.label50.Text = "290 - 300";
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label49.Location = new System.Drawing.Point(379, 184);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(120, 25);
            this.label49.TabIndex = 15;
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label48.Location = new System.Drawing.Point(78, 184);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(112, 25);
            this.label48.TabIndex = 14;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label47.Location = new System.Drawing.Point(368, 97);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(131, 23);
            this.label47.TabIndex = 13;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label46.Location = new System.Drawing.Point(118, 97);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(114, 23);
            this.label46.TabIndex = 12;
            // 
            // label45
            // 
            this.label45.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label45.Location = new System.Drawing.Point(343, 48);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(101, 23);
            this.label45.TabIndex = 11;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label44.Location = new System.Drawing.Point(167, 48);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(92, 23);
            this.label44.TabIndex = 10;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Location = new System.Drawing.Point(477, 262);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(121, 23);
            this.label25.TabIndex = 9;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(440, 240);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(103, 23);
            this.label24.TabIndex = 9;
            this.label24.Text = "🛫 Terminal";
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Location = new System.Drawing.Point(279, 263);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(141, 23);
            this.label23.TabIndex = 9;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(245, 240);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(94, 23);
            this.label21.TabIndex = 8;
            this.label21.Text = "🚪  Portão";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(39, 240);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(138, 23);
            this.label20.TabIndex = 7;
            this.label20.Text = "💺​   Capacidade\r\n";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(329, 148);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(182, 46);
            this.label19.TabIndex = 6;
            this.label19.Text = "🗓️   Data da Chegada\r\n ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(37, 148);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(168, 23);
            this.label18.TabIndex = 5;
            this.label18.Text = "🗓️   Data de Partida";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(285, 96);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 25);
            this.label17.TabIndex = 4;
            this.label17.Text = "Destino";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(245, 97);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(34, 23);
            this.label16.TabIndex = 3;
            this.label16.Text = "✈️";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(37, 96);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 25);
            this.label15.TabIndex = 2;
            this.label15.Text = "Origem";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(279, 48);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 23);
            this.label14.TabIndex = 1;
            this.label14.Text = "Tipo";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(37, 44);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(124, 31);
            this.label13.TabIndex = 0;
            this.label13.Text = "Nº do Voo";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.pictureBox1);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox3.Location = new System.Drawing.Point(519, 359);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(621, 321);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Aeronave";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(329, 184);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(189, 23);
            this.label28.TabIndex = 4;
            this.label28.Text = "Alcance:              14.010";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(329, 145);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(210, 23);
            this.label27.TabIndex = 3;
            this.label27.Text = "Velocidade:         903km/h";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(329, 106);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(170, 23);
            this.label26.TabIndex = 2;
            this.label26.Text = "Capacidade:        300";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(327, 57);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(283, 31);
            this.label22.TabIndex = 1;
            this.label22.Text = "Boeing 787-9 Dreamliner";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Sistema_de_compainha_aerea.Properties.Resources.Gemini_Generated_Image_bqhtx2bqhtx2bqht;
            this.pictureBox1.Location = new System.Drawing.Point(15, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(303, 156);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnBuscarVoos);
            this.groupBox4.Controls.Add(this.dtpBuscarDataVoo);
            this.groupBox4.Controls.Add(this.txtBuscarVoos);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox4.Location = new System.Drawing.Point(1162, 39);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(420, 178);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Buscar Voos";
            // 
            // btnBuscarVoos
            // 
            this.btnBuscarVoos.Image = global::Sistema_de_compainha_aerea.Properties.Resources.Design_sem_nome__6_;
            this.btnBuscarVoos.Location = new System.Drawing.Point(312, 97);
            this.btnBuscarVoos.Name = "btnBuscarVoos";
            this.btnBuscarVoos.Size = new System.Drawing.Size(87, 38);
            this.btnBuscarVoos.TabIndex = 3;
            this.btnBuscarVoos.UseVisualStyleBackColor = true;
            this.btnBuscarVoos.Click += new System.EventHandler(this.btnBuscarVoos_Click);
            // 
            // dtpBuscarDataVoo
            // 
            this.dtpBuscarDataVoo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpBuscarDataVoo.Location = new System.Drawing.Point(107, 102);
            this.dtpBuscarDataVoo.Name = "dtpBuscarDataVoo";
            this.dtpBuscarDataVoo.Size = new System.Drawing.Size(188, 30);
            this.dtpBuscarDataVoo.TabIndex = 0;
            // 
            // txtBuscarVoos
            // 
            this.txtBuscarVoos.Location = new System.Drawing.Point(107, 42);
            this.txtBuscarVoos.Name = "txtBuscarVoos";
            this.txtBuscarVoos.Size = new System.Drawing.Size(263, 30);
            this.txtBuscarVoos.TabIndex = 2;
            this.txtBuscarVoos.TextChanged += new System.EventHandler(this.txtBuscarVoos_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(29, 105);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 23);
            this.label12.TabIndex = 1;
            this.label12.Text = "Data:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 49);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 23);
            this.label11.TabIndex = 0;
            this.label11.Text = "Pesquisar:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnExcluirvoos);
            this.groupBox5.Controls.Add(this.label42);
            this.groupBox5.Controls.Add(this.label41);
            this.groupBox5.Controls.Add(this.label40);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.label38);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.label33);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.label31);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Controls.Add(this.label29);
            this.groupBox5.Controls.Add(this.btnLimparVoo);
            this.groupBox5.Controls.Add(this.btnSalvarVoos);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox5.Location = new System.Drawing.Point(1162, 223);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(420, 457);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Resumo do voo";
            // 
            // btnExcluirvoos
            // 
            this.btnExcluirvoos.BackColor = System.Drawing.Color.Transparent;
            this.btnExcluirvoos.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btnExcluirvoos.Image = global::Sistema_de_compainha_aerea.Properties.Resources.Design_sem_nome__7_;
            this.btnExcluirvoos.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnExcluirvoos.Location = new System.Drawing.Point(295, 242);
            this.btnExcluirvoos.Name = "btnExcluirvoos";
            this.btnExcluirvoos.Size = new System.Drawing.Size(104, 62);
            this.btnExcluirvoos.TabIndex = 16;
            this.btnExcluirvoos.Text = "Excluir";
            this.btnExcluirvoos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExcluirvoos.UseVisualStyleBackColor = false;
            this.btnExcluirvoos.Click += new System.EventHandler(this.btnExcluirvoos_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label42.Location = new System.Drawing.Point(153, 326);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(76, 25);
            this.label42.TabIndex = 15;
            this.label42.Text = "Terminal";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label41.Location = new System.Drawing.Point(153, 281);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(62, 25);
            this.label41.TabIndex = 14;
            this.label41.Text = "Portão";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label40.Location = new System.Drawing.Point(153, 242);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(50, 25);
            this.label40.TabIndex = 13;
            this.label40.Text = "Hora";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label39.Location = new System.Drawing.Point(153, 194);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(48, 25);
            this.label39.TabIndex = 12;
            this.label39.Text = "Data";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label38.Location = new System.Drawing.Point(153, 143);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(70, 25);
            this.label38.TabIndex = 11;
            this.label38.Text = "Destino";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label37.Location = new System.Drawing.Point(153, 101);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(69, 25);
            this.label37.TabIndex = 10;
            this.label37.Text = "Origem";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label36.Location = new System.Drawing.Point(153, 62);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(42, 25);
            this.label36.TabIndex = 9;
            this.label36.Text = "Voo";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(23, 326);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(107, 23);
            this.label35.TabIndex = 8;
            this.label35.Text = "🛫 Terminal:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(23, 281);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(93, 23);
            this.label34.TabIndex = 7;
            this.label34.Text = "🚪 Portão:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(23, 236);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(81, 23);
            this.label33.TabIndex = 6;
            this.label33.Text = "🕒 Hora:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(23, 191);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(84, 23);
            this.label32.TabIndex = 5;
            this.label32.Text = "🗓️  Data:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(23, 146);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(96, 23);
            this.label31.TabIndex = 4;
            this.label31.Text = "📍Destino:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(23, 101);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(100, 23);
            this.label30.TabIndex = 3;
            this.label30.Text = "📍Origem: ";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(23, 56);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(73, 23);
            this.label29.TabIndex = 2;
            this.label29.Text = "✈️ Voo:";
            // 
            // btnLimparVoo
            // 
            this.btnLimparVoo.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btnLimparVoo.Image = global::Sistema_de_compainha_aerea.Properties.Resources.Design_sem_nome__11_;
            this.btnLimparVoo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnLimparVoo.Location = new System.Drawing.Point(295, 150);
            this.btnLimparVoo.Name = "btnLimparVoo";
            this.btnLimparVoo.Size = new System.Drawing.Size(107, 64);
            this.btnLimparVoo.TabIndex = 1;
            this.btnLimparVoo.Text = "Limpar";
            this.btnLimparVoo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnLimparVoo.UseVisualStyleBackColor = true;
            this.btnLimparVoo.Click += new System.EventHandler(this.btnLimparVoo_Click);
            // 
            // btnSalvarVoos
            // 
            this.btnSalvarVoos.BackColor = System.Drawing.Color.Transparent;
            this.btnSalvarVoos.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btnSalvarVoos.Image = global::Sistema_de_compainha_aerea.Properties.Resources.Design_sem_nome__9_;
            this.btnSalvarVoos.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSalvarVoos.Location = new System.Drawing.Point(295, 56);
            this.btnSalvarVoos.Name = "btnSalvarVoos";
            this.btnSalvarVoos.Size = new System.Drawing.Size(108, 68);
            this.btnSalvarVoos.TabIndex = 0;
            this.btnSalvarVoos.Text = "Salvar";
            this.btnSalvarVoos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSalvarVoos.UseVisualStyleBackColor = false;
            this.btnSalvarVoos.Click += new System.EventHandler(this.btnSalvarVoos_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dgvVoos);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox6.Location = new System.Drawing.Point(31, 705);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1506, 310);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Voos cadastrados";
            // 
            // dgvVoos
            // 
            this.dgvVoos.AllowUserToAddRows = false;
            this.dgvVoos.AllowUserToDeleteRows = false;
            this.dgvVoos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVoos.Location = new System.Drawing.Point(45, 29);
            this.dgvVoos.Name = "dgvVoos";
            this.dgvVoos.ReadOnly = true;
            this.dgvVoos.RowHeadersVisible = false;
            this.dgvVoos.RowHeadersWidth = 51;
            this.dgvVoos.RowTemplate.Height = 24;
            this.dgvVoos.Size = new System.Drawing.Size(1411, 257);
            this.dgvVoos.TabIndex = 0;
            this.dgvVoos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVoos_CellContentClick);
            // 
            // Voos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1604, 1055);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Voos";
            this.Text = "Voos";
            this.Load += new System.EventHandler(this.Voos_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVoos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbPortao;
        private System.Windows.Forms.DateTimePicker dtpHoraChegada;
        private System.Windows.Forms.DateTimePicker dtpDataChegada;
        private System.Windows.Forms.DateTimePicker dtpHoraPartida;
        private System.Windows.Forms.DateTimePicker dtpDataPartida;
        private System.Windows.Forms.ComboBox cmbTipoVoo;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.ComboBox cmbTerminal;
        private System.Windows.Forms.TextBox txtDestino;
        private System.Windows.Forms.TextBox txtOrigem;
        private System.Windows.Forms.DataGridView dgvVoos;
        private System.Windows.Forms.TextBox txtBuscarVoos;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnBuscarVoos;
        private System.Windows.Forms.DateTimePicker dtpBuscarDataVoo;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button btnNovoVoo;
        private System.Windows.Forms.Button btnLimparVoo;
        private System.Windows.Forms.Button btnSalvarVoos;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btnExcluirvoos;
        private System.Windows.Forms.ComboBox cmbStatusVoos;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
    }
}