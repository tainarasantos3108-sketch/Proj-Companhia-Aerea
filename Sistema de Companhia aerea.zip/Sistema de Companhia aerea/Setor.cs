﻿using System.Data;
using System.Data.SqlClient;

namespace Sistema_de_compainha_aerea
{
    public class Setor
    {
        public void SalvarSetor(string nome)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "INSERT INTO Setores (NOME_SETOR) VALUES (@NOME_SETOR)";
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@NOME_SETOR", nome);
                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public DataTable ListarSetores()

        {
            DataTable dataTable = new DataTable();

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "SELECT * FROM Setores";
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        DataTable dataSetores = new DataTable();
                        adapter.Fill(dataSetores);
                        return dataSetores;
                    }
                }
            }
        }

        public void AlterarSetor(int codigo, string nome)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "UPDATE Setores SET NOME_SETOR = @NOME_SETOR WHERE ID_SETOR = @ID_SETOR";
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@NOME_SETOR", nome);
                    comando.Parameters.AddWithValue("@ID_SETOR", codigo);
                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public void ExcluirSetor(int codigo)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "DELETE FROM Setores WHERE ID_SETOR = @ID_SETOR";
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@ID_SETOR", codigo);
                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public DataTable PesquisarSetor(string nome)
        {
            DataTable dataSetores = new DataTable();

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "SELECT ID_SETOR, NOME_SETOR FROM Setores WHERE NOME_SETOR LIKE @NOME_SETOR";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@NOME_SETOR", "%" + nome + "%");

                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        adapter.Fill(dataSetores);
                    }
                }
            }

            return dataSetores;
        }
    }
}
