﻿using System;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Drawing;
using System.Globalization;
using System.IO;

namespace Sistema_de_compainha_aerea
{
    public partial class GerenciamentoFuncionarioeSetores : Form
    {
        private int idSetor = 0; // Variável para armazenar o ID do setor selecionado
        private int idFuncionario = 0; // Variável para armazenar o ID do funcionário selecionado
        private string caminhoImagem = ""; // Variável para armazenar o caminho da imagem selecionada
        public GerenciamentoFuncionarioeSetores()
        {
            InitializeComponent();
        }

        private void GerenciamentoFuncionarioeSetores_Load(object sender, EventArgs e)
        {
            CarregarSetores();
            CarregarSetoresComboBox();
            CarregarFuncionarios();
        }
        private void btnSalvarSetor_Click(object sender, EventArgs e)
        {
            try
            {
                Setor setor = new Setor();

                if (string.IsNullOrWhiteSpace(txtNomeSetor.Text))
                {
                    MessageBox.Show("O campo nome do setor não pode estar vazio.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (idSetor == 0)
                {
                    setor.SalvarSetor(txtNomeSetor.Text);
                    MessageBox.Show("Setor salvo com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    setor.AlterarSetor(idSetor, txtNomeSetor.Text);
                    MessageBox.Show("Setor alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                txtNomeSetor.Clear();
                idSetor = 0;
                CarregarSetores();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao salvar o setor: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CarregarSetores()
        {
            try
            {
                Setor setor = new Setor();
                dgvSetores.DataSource = setor.ListarSetores();
                dgvSetores.Columns["ID_SETOR"].HeaderText = "Código";
                dgvSetores.Columns["ID_SETOR"].Width = 70;
                dgvSetores.Columns["NOME_SETOR"].HeaderText = "Setor";
                dgvSetores.Columns["NOME_SETOR"].Width = 200;

                if (!dgvSetores.Columns.Contains("EditarSetor"))
                {
                    DataGridViewButtonColumn btnEditarSetor = new DataGridViewButtonColumn();
                    btnEditarSetor.Name = "EditarSetor";
                    btnEditarSetor.HeaderText = "Editar";
                    btnEditarSetor.Text = "Editar";
                    btnEditarSetor.UseColumnTextForButtonValue = true;
                    dgvSetores.Columns.Add(btnEditarSetor);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar os setores: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCadastrarSetor_Click(object sender, EventArgs e)
        {
            txtNomeSetor.Clear();
            txtNomeSetor.Focus();
            idSetor = 0; // Resetar o ID do setor selecionado    
        }

        private void btnExcluirSetor_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSetores.CurrentRow == null)
                {
                    MessageBox.Show("Selecione um setor para excluir.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int codigoSetor = Convert.ToInt32(dgvSetores.CurrentRow.Cells["ID_SETOR"].Value);
                DialogResult resultado = MessageBox.Show("Tem certeza que deseja excluir o setor selecionado?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    Setor setor = new Setor();
                    setor.ExcluirSetor(codigoSetor);
                    MessageBox.Show("Setor excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CarregarSetores();
                    txtNomeSetor.Clear();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao excluir o setor: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvSetores_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvSetores.Columns[e.ColumnIndex].Name == "EditarSetor")
            {
                idSetor = Convert.ToInt32(dgvSetores.Rows[e.RowIndex].Cells["ID_SETOR"].Value);
                txtNomeSetor.Text = dgvSetores.Rows[e.RowIndex].Cells["NOME_SETOR"].Value.ToString();
                txtNomeSetor.Focus();
            }
        }

        private void btnPesquisarSetor_Click(object sender, EventArgs e)
        {
            try
            {
                Setor setor = new Setor();

                if (txtPesquisarSetor.Text == "")
                {
                    CarregarSetores();

                }
                else
                {
                    dgvSetores.DataSource = setor.PesquisarSetor(txtPesquisarSetor.Text);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao pesquisar o setor: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtPesquisarSetor_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Setor setor = new Setor();

                if (txtPesquisarSetor.Text == "")
                {
                    CarregarSetores();
                }
                else
                {
                    dgvSetores.DataSource = setor.PesquisarSetor(txtPesquisarSetor.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao pesquisar o setor: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNomeSetor.Clear();
        }

        private void btnSalvarFuncionario_Click(object sender, EventArgs e)
        {
            try
            {
                Funcionario funcionario = new Funcionario();

                string nome = txtNomeFuncionario.Text;
                string cpf = mtbCpfFuncionario.Text;
                string telefone = mtbCaontatoFuncionario.Text;
                string email = txtEmailFuncionario.Text;
                string cargo = txtCargo.Text;
                int idSetor = Convert.ToInt32(cmbSetorFuncionario.SelectedValue.ToString());
                decimal salarios = Convert.ToDecimal(txtSalario.Text);
                DateTime dataAdmissao = dtpAdmissao.Value;
                string foto = caminhoImagem;

                if (!ValidaFuncionarios())
                {
                    return;
                }

                if (idFuncionario == 0)
                {
                    funcionario.SalvarFuncionario(nome, cpf, telefone, email, cargo, idSetor, salarios, dataAdmissao, foto);
                    MessageBox.Show("Funcionário salvo com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparFuncionarios();
                }
                else
                {
                    funcionario.AlterarFuncionario(idFuncionario, nome, cpf, telefone, email, cargo, idSetor, salarios, dataAdmissao, foto);
                    MessageBox.Show("Funcionário alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparFuncionarios();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar o funcionário: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //MessageBox.Show(ex.ToString(), "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error); //exibir aonde esta acontecendo o erro no evento e o nuúmero da linha.
            }
        }

        private void CarregarSetoresComboBox()
        {
            Setor setor = new Setor();
            cmbSetorFuncionario.DataSource = setor.ListarSetores();
            cmbSetorFuncionario.ValueMember = "ID_SETOR";// Valor associado a cada item do ComboBox
            cmbSetorFuncionario.SelectedIndex = -1; // Nenhum item selecionado inicialmente
            cmbSetorFuncionario.DisplayMember = "NOME_SETOR";// Exibir o nome do setor no ComboBox
        }

        private void CarregarFuncionarios()
        {
            try
            {
                Funcionario funcionario = new Funcionario();

                dgvFuncionarios.DataSource = funcionario.ListarFuncionarios();

                dgvFuncionarios.Columns["ID_FUNCIONARIO"].HeaderText = "Código";
                dgvFuncionarios.Columns["ID_FUNCIONARIO"].Width = 70;
                dgvFuncionarios.Columns["ID_FUNCIONARIO"].DisplayIndex = 0; // Definir a coluna "ID_FUNCIONARIO" como a primeira coluna
                dgvFuncionarios.Columns["NOME_FUNCIONARIO"].HeaderText = "Funcionário";
                dgvFuncionarios.Columns["NOME_FUNCIONARIO"].Width = 200;
                dgvFuncionarios.Columns["CPF_FUNCIONARIO"].HeaderText = "CPF";
                dgvFuncionarios.Columns["CPF_FUNCIONARIO"].Width = 100;
                dgvFuncionarios.Columns["TELEFONE_FUNCIONARIO"].HeaderText = "Telefone";
                dgvFuncionarios.Columns["TELEFONE_FUNCIONARIO"].Width = 120;
                dgvFuncionarios.Columns["EMAIL_FUNCIONARIO"].HeaderText = "Email";
                dgvFuncionarios.Columns["EMAIL_FUNCIONARIO"].Width = 200;
                dgvFuncionarios.Columns["CARGO"].HeaderText = "Cargo";
                dgvFuncionarios.Columns["CARGO"].Width = 150;
                dgvFuncionarios.Columns["ID_SETOR"].Visible = false; // Ocultar a coluna "ID_SETOR"
                dgvFuncionarios.Columns["NOME_SETOR"].HeaderText = "Setor";
                dgvFuncionarios.Columns["NOME_SETOR"].Width = 150;
                dgvFuncionarios.Columns["SALARIOS"].HeaderText = "Salário";
                dgvFuncionarios.Columns["SALARIOS"].Width = 100;
                dgvFuncionarios.Columns["SALARIOS"].DefaultCellStyle.Format = "C2"; // Formatar como moeda
                dgvFuncionarios.Columns["DATA_ADMISSAO"].HeaderText = "Data de Admissão";
                dgvFuncionarios.Columns["DATA_ADMISSAO"].Width = 120;
                dgvFuncionarios.Columns["IMAGEM_FUNCIONARIO"].Visible = false;// Ocultar a coluna "IMAGEM_FUNCIONARIO"

                if (!dgvFuncionarios.Columns.Contains("EditarFuncionario"))
                {
                    DataGridViewButtonColumn btnEditarFuncionarios = new DataGridViewButtonColumn();

                    btnEditarFuncionarios.Name = "EditarFuncionario";
                    btnEditarFuncionarios.HeaderText = "Editar";
                    btnEditarFuncionarios.Text = "Editar";
                    btnEditarFuncionarios.UseColumnTextForButtonValue = true;
                    btnEditarFuncionarios.DefaultCellStyle.NullValue = "Editar";
                    dgvFuncionarios.Columns.Add(btnEditarFuncionarios);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Erro ao carregar funcionarios", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dgvFuncionarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvFuncionarios.Columns[e.ColumnIndex].Name == "EditarFuncionario")
            {
                idFuncionario = Convert.ToInt32(dgvFuncionarios.Rows[e.RowIndex].Cells["ID_FUNCIONARIO"].Value);
                txtNomeFuncionario.Text = dgvFuncionarios.Rows[e.RowIndex].Cells["NOME_FUNCIONARIO"].Value.ToString();
                mtbCpfFuncionario.Text = dgvFuncionarios.Rows[e.RowIndex].Cells["CPF_FUNCIONARIO"].Value.ToString();
                mtbCaontatoFuncionario.Text = dgvFuncionarios.Rows[e.RowIndex].Cells["TELEFONE_FUNCIONARIO"].Value.ToString();
                txtEmailFuncionario.Text = dgvFuncionarios.Rows[e.RowIndex].Cells["EMAIL_FUNCIONARIO"].Value.ToString();
                txtCargo.Text = dgvFuncionarios.Rows[e.RowIndex].Cells["CARGO"].Value.ToString();
                cmbSetorFuncionario.SelectedValue = dgvFuncionarios.Rows[e.RowIndex].Cells["ID_SETOR"].Value;
                txtSalario.Text = dgvFuncionarios.Rows[e.RowIndex].Cells["SALARIOS"].Value.ToString();
                dtpAdmissao.Value = Convert.ToDateTime(dgvFuncionarios.Rows[e.RowIndex].Cells["DATA_ADMISSAO"].Value);
                string caminhoImagemFuncionario = dgvFuncionarios.Rows[e.RowIndex].Cells["IMAGEM_FUNCIONARIO"].Value.ToString();
                caminhoImagem = caminhoImagemFuncionario; // Armazena o caminho da imagem do funcionário

                if(!String.IsNullOrWhiteSpace(caminhoImagem) && File.Exists(caminhoImagem))
                {
                    pbFuncionario.Load(caminhoImagem);
                    pbFuncionario.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else
                {
                    pbFuncionario.Image = null; // Limpa a imagem se o caminho estiver vazio ou o arquivo não existir
                }

                txtNomeFuncionario.Focus();// Define o foco no campo de nome do funcionário
            }
        }

        private void btnSelecionaFotoFuncionario_Click(object sender, EventArgs e)
        {
            OpenFileDialog abrirFoto = new OpenFileDialog();
            abrirFoto.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp";

            if(abrirFoto.ShowDialog() == DialogResult.OK)
            {
                caminhoImagem = abrirFoto.FileName;
                
                pbFuncionario.Load(abrirFoto.FileName);
                pbFuncionario.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void btnRemoverFotoFuncionario_Click(object sender, EventArgs e)
        {
            pbFuncionario.Image = null;
        }

        private void btnExcluirFuncionario_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvFuncionarios.CurrentRow == null)
                {
                    MessageBox.Show("Selecione um funcionário para excluir.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int codigoFuncionario = Convert.ToInt32(dgvFuncionarios.CurrentRow.Cells["ID_FUNCIONARIO"].Value);
                DialogResult resultado = MessageBox.Show("Tem certeza que deseja excluir o funcionário selecionado?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    Funcionario funcionario = new Funcionario();
                    funcionario.ExcluirFuncionario(codigoFuncionario);
                    MessageBox.Show("Funcionário excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CarregarFuncionarios();
                    LimparFuncionarios();
                    txtNomeFuncionario.Focus();// Define o foco no campo de nome do funcionário
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao excluir o funcionário: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimparFuncionario_Click(object sender, EventArgs e)
        {
            LimparFuncionarios();
        }

        private void LimparFuncionarios()
        {
            txtNomeFuncionario.Clear();
            mtbCpfFuncionario.Clear();
            mtbCaontatoFuncionario.Clear();
            txtEmailFuncionario.Clear();
            txtCargo.Clear();
            cmbSetorFuncionario.SelectedIndex = -1;
            txtSalario.Clear();
            dtpAdmissao.Value = DateTime.Now;
            pbFuncionario.Image = null;
            caminhoImagem = "";
            idFuncionario = 0; // Resetar o ID do funcionário selecionado
        }

        private void btnCadastrarFuncionario_Click(object sender, EventArgs e)
        {
            txtNomeFuncionario.Clear();
            mtbCpfFuncionario.Clear();
            mtbCaontatoFuncionario.Clear();
            txtEmailFuncionario.Clear();
            txtCargo.Clear();
            cmbSetorFuncionario.SelectedIndex = -1;
            txtSalario.Clear();
            dtpAdmissao.Value = DateTime.Now;
            pbFuncionario.Image = null;
            caminhoImagem = "";
            idFuncionario = 0; // Resetar o ID do funcionário selecionado
            txtNomeFuncionario.Focus();// Define o foco no campo de nome do funcionário
        }

        private void txtPesquisarFuncionario_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Funcionario funcionario = new Funcionario();

                if (txtPesquisarFuncionario.Text == "")
                {
                    CarregarFuncionarios();
                }
                else
                {
                    dgvFuncionarios.DataSource = funcionario.PesquisarFuncionario(txtPesquisarFuncionario.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao pesquisar o funcionário: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnPesquisarFuncionario_Click(object sender, EventArgs e)
        {
            try
            {
                Funcionario funcionario = new Funcionario();

                if (txtPesquisarFuncionario.Text == "")
                {
                    CarregarFuncionarios();

                }
                else
                {
                    dgvFuncionarios.DataSource = funcionario.PesquisarFuncionario(txtPesquisarFuncionario.Text);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao pesquisar o funcionário: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidaFuncionarios()
        {
            if (string.IsNullOrWhiteSpace(txtNomeFuncionario.Text))
            {
                MessageBox.Show("O campo nome do funcionário não pode estar vazio.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNomeFuncionario.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(mtbCpfFuncionario.Text) || mtbCpfFuncionario.Text.Length < 11)
            {
                MessageBox.Show("O campo CPF do funcionário não pode estar vazio e deve conter 11 dígitos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                mtbCpfFuncionario.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(mtbCaontatoFuncionario.Text) || mtbCaontatoFuncionario.Text.Length < 10)
            {
                MessageBox.Show("O campo telefone do funcionário não pode estar vazio e deve conter pelo menos 10 dígitos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                mtbCaontatoFuncionario.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtEmailFuncionario.Text))
            {
                MessageBox.Show("O campo email do funcionário não pode estar vazio.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEmailFuncionario.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtCargo.Text))
            {
                MessageBox.Show("O campo cargo do funcionário não pode estar vazio.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCargo.Focus();
                return false;
            }
            if (cmbSetorFuncionario.SelectedIndex == -1)
            {
                MessageBox.Show("Selecione um setor para o funcionário.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbSetorFuncionario.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtSalario.Text) || !decimal.TryParse(txtSalario.Text, out decimal salario) || salario <= 0)
            {
                MessageBox.Show("O campo salário do funcionário não pode estar vazio e deve ser um valor positivo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSalario.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(pbFuncionario.ImageLocation))
            {
                MessageBox.Show("Selecione uma foto para o funcionário.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                pbFuncionario.Focus();
                return false;
            }
            return true; // Todos os campos são válidos
        }
    }
}