﻿namespace Sistema_de_compainha_aerea
{
    public static class Conexao
    {
        // Conexão com o banco de dados
        private static string ConexaoString = @"Server=TAINARA\SQLEXPRESS;Database=SistemadeAeroporto;Integrated Security=True;Pooling=False;Encrypt=True;TrustServerCertificate=True;";
        // Propriedade para acessar a string de conexão
        public static string StringConexao
        {
            get { return ConexaoString; }
        }
    }
}
