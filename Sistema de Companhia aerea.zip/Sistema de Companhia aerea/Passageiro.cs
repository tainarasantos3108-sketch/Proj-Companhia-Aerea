﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Sistema_de_compainha_aerea
{
    public class Passageiro
    {
        public void SalvarPassageiro(string nome, string cpf, string contato, string email, DateTime dataNascimento, string nacionalidade, string passaporte, char sexo, string foto, int milhas, string observacao, string classe, string vooNI)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "INSERT INTO PASSAGEIROS (NOME_PASSAGEIRO, CPF_PASSAGEIRO, CONTATO_PASSAGEIRO, EMAIL_PASSAGEIRO, DATA_NASCIMENTO, NACIONALIDADE, PASSAPORTE, SEXO, IMAGEM, MILHAS, OBSERVACAO, CLASSE, VOO_N_I) " + "VALUES (@Nome, @CPF, @Telefone, @Email, @DataNascimento, @Nacionalidade, @Passaporte, @Sexo, @Imagem, @Milhas, @Observacao, @Classe, @VooNI)";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@Nome", nome);
                    comando.Parameters.AddWithValue("@CPF", cpf);
                    comando.Parameters.AddWithValue("@Telefone", contato);
                    comando.Parameters.AddWithValue("@Email", email);
                    comando.Parameters.AddWithValue("@DataNascimento", dataNascimento);
                    comando.Parameters.AddWithValue("@Nacionalidade", nacionalidade);
                    comando.Parameters.AddWithValue("@Passaporte", passaporte);
                    comando.Parameters.AddWithValue("@Sexo", sexo);
                    comando.Parameters.AddWithValue("@Imagem", foto);
                    comando.Parameters.AddWithValue("@Milhas", milhas);
                    comando.Parameters.AddWithValue("@Observacao", observacao);
                    comando.Parameters.AddWithValue("@Classe", classe);
                    comando.Parameters.AddWithValue("@VooNI", vooNI);

                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public void AlterarPassageiro(int codigo, string nome, string cpf, string contato, string email, DateTime dataNascimento, string nacionalidade, string passaporte, char sexo, string foto, int milhas, string observacao, string classe, string vooNI)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "UPDATE PASSAGEIROS SET NOME_PASSAGEIRO = @Nome, CPF_PASSAGEIRO = @CPF, CONTATO_PASSAGEIRO = @Telefone, EMAIL_PASSAGEIRO = @Email, DATA_NASCIMENTO = @DataNascimento, NACIONALIDADE = @Nacionalidade, PASSAPORTE = @Passaporte, SEXO = @Sexo, IMAGEM = @Imagem, MILHAS = @Milhas, OBSERVACAO = @Observacao, CLASSE = @Classe, VOO_N_I = @VooNI WHERE ID_PASSAGEIRO = @Codigo";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@Codigo", codigo);
                    comando.Parameters.AddWithValue("@Nome", nome);
                    comando.Parameters.AddWithValue("@CPF", cpf);
                    comando.Parameters.AddWithValue("@Telefone", contato);
                    comando.Parameters.AddWithValue("@Email", email);
                    comando.Parameters.AddWithValue("@DataNascimento", dataNascimento);
                    comando.Parameters.AddWithValue("@Nacionalidade", nacionalidade);
                    comando.Parameters.AddWithValue("@Passaporte", passaporte);
                    comando.Parameters.AddWithValue("@Sexo", sexo);
                    comando.Parameters.AddWithValue("@Imagem", foto);
                    comando.Parameters.AddWithValue("@Milhas", milhas);
                    comando.Parameters.AddWithValue("@Observacao", observacao);
                    comando.Parameters.AddWithValue("@Classe", classe);
                    comando.Parameters.AddWithValue("@VooNI", vooNI);

                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public void ExcluirPassageiro(int codigo)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "DELETE FROM PASSAGEIROS WHERE ID_PASSAGEIRO = @Codigo";
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@Codigo", codigo);
                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public DataTable ListarPassageiros()
        {
            DataTable dataPassageiros = new DataTable();

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "SELECT * FROM PASSAGEIROS";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        adapter.Fill(dataPassageiros);
                        return dataPassageiros;
                    }
                }
            }
        }

        public DataTable PesquisarPassageiro(string nome, string cpf, string passaporte)
        {
            DataTable dataPassageiro = new DataTable();

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"SELECT P.ID_PASSAGEIRO, P.NOME_PASSAGEIRO, P.CPF_PASSAGEIRO, P.CONTATO_PASSAGEIRO, P.EMAIL_PASSAGEIRO, P.DATA_NASCIMENTO, P.NACIONALIDADE, P.PASSAPORTE, P.SEXO, P.IMAGEM, P.MILHAS, P.OBSERVACAO, P.CLASSE, P.VOO_N_I FROM PASSAGEIROS P WHERE 1 = 1";

                if (!string.IsNullOrWhiteSpace(nome))
                {
                    sql += " AND P.NOME_PASSAGEIRO LIKE @Nome";
                }

                if (!string.IsNullOrWhiteSpace(cpf))
                {
                    sql += " AND P.CPF_PASSAGEIRO LIKE @Cpf";
                }

                if (!string.IsNullOrWhiteSpace(passaporte))
                {
                    sql += " AND P.PASSAPORTE LIKE @Passaporte";
                }

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    if (!string.IsNullOrWhiteSpace(nome))
                    {
                        comando.Parameters.AddWithValue("@Nome", "%" + nome + "%");
                    }

                    if (!string.IsNullOrWhiteSpace(cpf))
                    {
                        comando.Parameters.AddWithValue("@Cpf", "%" + cpf + "%");
                    }

                    if (!string.IsNullOrWhiteSpace(passaporte))
                    {
                        comando.Parameters.AddWithValue("@Passaporte", "%" + passaporte + "%");
                    }

                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        adapter.Fill(dataPassageiro);
                    }
                }
            }

            return dataPassageiro;
        }

    }
}