﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_compainha_aerea
{
    public class Funcionario
    {
        public void SalvarFuncionario(string nome, string cpf, string telefone, string email, string cargo, int idSetor, decimal salarios, DateTime dataAdmissao, string foto)
        {
            // Lógica para salvar o funcionário no banco de dados
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "INSERT INTO FUNCIONARIOS (NOME_FUNCIONARIO, CPF_FUNCIONARIO, TELEFONE_FUNCIONARIO, EMAIL_FUNCIONARIO, CARGO, ID_SETOR, SALARIOS, DATA_ADMISSAO, IMAGEM_FUNCIONARIO) " +
                             "VALUES (@Nome, @CPF, @Telefone, @Email, @Cargo, @IdSetor, @Salarios, @DataAdmissao, @Imagem)";
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@Nome", nome);
                    comando.Parameters.AddWithValue("@CPF", cpf);
                    comando.Parameters.AddWithValue("@Telefone", telefone);
                    comando.Parameters.AddWithValue("@Email", email);
                    comando.Parameters.AddWithValue("@Cargo", cargo);
                    comando.Parameters.AddWithValue("@IdSetor", idSetor);
                    comando.Parameters.AddWithValue("@Salarios", salarios);
                    comando.Parameters.AddWithValue("@DataAdmissao", dataAdmissao);

                    comando.Parameters.AddWithValue("@Imagem", foto);

                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public DataTable ListarFuncionarios()
        {
            DataTable dataFuncionarios = new DataTable();

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "SELECT F.ID_FUNCIONARIO, " + "F.NOME_FUNCIONARIO, " + "F.CPF_FUNCIONARIO, " + "F.TELEFONE_FUNCIONARIO, " + "F.EMAIL_FUNCIONARIO, " + "F.CARGO, " + "F.ID_SETOR, " + "S.NOME_SETOR, " + "F.SALARIOS, " + "F.DATA_ADMISSAO, " + "F.IMAGEM_FUNCIONARIO " + "FROM FUNCIONARIOS F " + "INNER JOIN SETORES S ON F.ID_SETOR = S.ID_SETOR";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        adapter.Fill(dataFuncionarios);
                        return dataFuncionarios;
                    }
                }
            }
        }

        public void AlterarFuncionario(int codigo, string nome, string cpf, string contato, string email, string cargo, int idsetor, decimal salario, DateTime dataadmissao, string foto)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "UPDATE Funcionarios SET " +"NOME_FUNCIONARIO = @Nome, " + "CPF_FUNCIONARIO = @CPF, " + "TELEFONE_FUNCIONARIO = @Contato, " + "EMAIL_FUNCIONARIO = @Email, " + "CARGO = @Cargo, " + "ID_SETOR = @IdSetor, " + "SALARIOS = @Salario, " + "DATA_ADMISSAO = @DataAdmissao, " + "IMAGEM_FUNCIONARIO = @Foto " + "WHERE ID_FUNCIONARIO = @Codigo";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@Codigo", codigo);
                    comando.Parameters.AddWithValue("@Nome", nome);
                    comando.Parameters.AddWithValue("@CPF", cpf);
                    comando.Parameters.AddWithValue("@Contato", contato);
                    comando.Parameters.AddWithValue("@Email", email);
                    comando.Parameters.AddWithValue("@Cargo", cargo);
                    comando.Parameters.AddWithValue("@IdSetor", idsetor);
                    comando.Parameters.AddWithValue("@Salario", salario);
                    comando.Parameters.AddWithValue("@DataAdmissao", dataadmissao);
                    comando.Parameters.AddWithValue("@Foto", foto);

                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public void ExcluirFuncionario(int codigo)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "DELETE FROM Funcionarios WHERE ID_FUNCIONARIO = @ID_FUNCIONARIO";
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@ID_FUNCIONARIO", codigo);
                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public DataTable PesquisarFuncionario(string nome)
        {
            DataTable dataFuncionarios = new DataTable();
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "SELECT F.ID_FUNCIONARIO, " + "F.NOME_FUNCIONARIO, " + "F.CPF_FUNCIONARIO, " + "F.TELEFONE_FUNCIONARIO, " + "F.EMAIL_FUNCIONARIO, " + "F.CARGO, " + "F.ID_SETOR, " + "S.NOME_SETOR, " + "F.SALARIOS, " + "F.DATA_ADMISSAO, " + "F.IMAGEM_FUNCIONARIO " + "FROM FUNCIONARIOS F " + "INNER JOIN SETORES S ON F.ID_SETOR = S.ID_SETOR WHERE F.NOME_FUNCIONARIO LIKE @Nome";
                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@Nome", "%" + nome + "%");
                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        adapter.Fill(dataFuncionarios);
                        return dataFuncionarios;
                    }
                }
            }
        }
    }
}