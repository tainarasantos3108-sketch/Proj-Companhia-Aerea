﻿namespace Sistema_de_compainha_aerea
{
    partial class MenuInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuInicial));
            this.tsMenu = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.btnFuncionariosSetores = new System.Windows.Forms.ToolStripButton();
            this.btnChecking = new System.Windows.Forms.ToolStripButton();
            this.btnVoos = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.gbFuncionariosSetores = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFuncionarioSetores = new System.Windows.Forms.TextBox();
            this.pbFuncionariosSetores = new System.Windows.Forms.PictureBox();
            this.btnentraFuncionariosSetores = new System.Windows.Forms.Button();
            this.dgvFuncionariosSetores = new System.Windows.Forms.DataGridView();
            this.cmbFuncionariosSetores = new System.Windows.Forms.ComboBox();
            this.gbPassageiros = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvEconomica = new System.Windows.Forms.DataGridView();
            this.button4 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgvVip = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gbCaixa = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.dgvExibirPagamentos = new System.Windows.Forms.DataGridView();
            this.gbAgendamentos = new System.Windows.Forms.GroupBox();
            this.dgvVoos = new System.Windows.Forms.DataGridView();
            this.btnAgendamento = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.gbRelatorios = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.sistemadeAeroportoDataSet = new Sistema_de_compainha_aerea.SistemadeAeroportoDataSet();
            this.passageirosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.passageirosTableAdapter = new Sistema_de_compainha_aerea.SistemadeAeroportoDataSetTableAdapters.PassageirosTableAdapter();
            this.tsMenu.SuspendLayout();
            this.gbFuncionariosSetores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFuncionariosSetores)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFuncionariosSetores)).BeginInit();
            this.gbPassageiros.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEconomica)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.gbCaixa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExibirPagamentos)).BeginInit();
            this.gbAgendamentos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVoos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.gbRelatorios.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemadeAeroportoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passageirosBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tsMenu
            // 
            this.tsMenu.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tsMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.tsMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.btnFuncionariosSetores,
            this.btnChecking,
            this.btnVoos,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton6});
            this.tsMenu.Location = new System.Drawing.Point(0, 0);
            this.tsMenu.Name = "tsMenu";
            this.tsMenu.Size = new System.Drawing.Size(172, 802);
            this.tsMenu.TabIndex = 0;
            this.tsMenu.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = global::Sistema_de_compainha_aerea.Properties.Resources.casa;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(169, 24);
            this.toolStripButton1.Text = "Inicio";
            // 
            // btnFuncionariosSetores
            // 
            this.btnFuncionariosSetores.Image = global::Sistema_de_compainha_aerea.Properties.Resources.do_utilizador;
            this.btnFuncionariosSetores.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnFuncionariosSetores.Name = "btnFuncionariosSetores";
            this.btnFuncionariosSetores.Size = new System.Drawing.Size(169, 24);
            this.btnFuncionariosSetores.Text = "Funcionarios/Setores";
            this.btnFuncionariosSetores.Click += new System.EventHandler(this.btnFuncionariosSetores_Click);
            // 
            // btnChecking
            // 
            this.btnChecking.Image = global::Sistema_de_compainha_aerea.Properties.Resources.check_in;
            this.btnChecking.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnChecking.Name = "btnChecking";
            this.btnChecking.Size = new System.Drawing.Size(169, 24);
            this.btnChecking.Text = "Passageiros";
            this.btnChecking.Click += new System.EventHandler(this.btnChecking_Click);
            // 
            // btnVoos
            // 
            this.btnVoos.Name = "btnVoos";
            this.btnVoos.Size = new System.Drawing.Size(169, 24);
            this.btnVoos.Text = "Cadastro de Voo";
            this.btnVoos.Click += new System.EventHandler(this.btnVoos_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = global::Sistema_de_compainha_aerea.Properties.Resources.calendario__1_;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(169, 24);
            this.toolStripButton4.Text = "Agendamentos";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = global::Sistema_de_compainha_aerea.Properties.Resources.saco_de_dolar;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(169, 24);
            this.toolStripButton5.Text = "Pagamentos";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.Image = global::Sistema_de_compainha_aerea.Properties.Resources.estatisticas;
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(169, 24);
            this.toolStripButton6.Text = "Relatorios";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // gbFuncionariosSetores
            // 
            this.gbFuncionariosSetores.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.gbFuncionariosSetores.Controls.Add(this.label2);
            this.gbFuncionariosSetores.Controls.Add(this.txtFuncionarioSetores);
            this.gbFuncionariosSetores.Controls.Add(this.pbFuncionariosSetores);
            this.gbFuncionariosSetores.Controls.Add(this.btnentraFuncionariosSetores);
            this.gbFuncionariosSetores.Controls.Add(this.dgvFuncionariosSetores);
            this.gbFuncionariosSetores.Controls.Add(this.cmbFuncionariosSetores);
            this.gbFuncionariosSetores.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFuncionariosSetores.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.gbFuncionariosSetores.Location = new System.Drawing.Point(205, 10);
            this.gbFuncionariosSetores.Name = "gbFuncionariosSetores";
            this.gbFuncionariosSetores.Size = new System.Drawing.Size(376, 767);
            this.gbFuncionariosSetores.TabIndex = 1;
            this.gbFuncionariosSetores.TabStop = false;
            this.gbFuncionariosSetores.Text = "Funcionarios e Setores";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(124, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 23);
            this.label2.TabIndex = 5;
            this.label2.Text = "Status";
            // 
            // txtFuncionarioSetores
            // 
            this.txtFuncionarioSetores.Location = new System.Drawing.Point(124, 100);
            this.txtFuncionarioSetores.Multiline = true;
            this.txtFuncionarioSetores.Name = "txtFuncionarioSetores";
            this.txtFuncionarioSetores.Size = new System.Drawing.Size(224, 39);
            this.txtFuncionarioSetores.TabIndex = 4;
            this.txtFuncionarioSetores.TextChanged += new System.EventHandler(this.txtFuncionarioSetores_TextChanged);
            // 
            // pbFuncionariosSetores
            // 
            this.pbFuncionariosSetores.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pbFuncionariosSetores.Location = new System.Drawing.Point(18, 100);
            this.pbFuncionariosSetores.Name = "pbFuncionariosSetores";
            this.pbFuncionariosSetores.Size = new System.Drawing.Size(100, 133);
            this.pbFuncionariosSetores.TabIndex = 3;
            this.pbFuncionariosSetores.TabStop = false;
            // 
            // btnentraFuncionariosSetores
            // 
            this.btnentraFuncionariosSetores.Image = global::Sistema_de_compainha_aerea.Properties.Resources.search_magnifier_icon_145939;
            this.btnentraFuncionariosSetores.Location = new System.Drawing.Point(127, 715);
            this.btnentraFuncionariosSetores.Name = "btnentraFuncionariosSetores";
            this.btnentraFuncionariosSetores.Size = new System.Drawing.Size(96, 35);
            this.btnentraFuncionariosSetores.TabIndex = 2;
            this.btnentraFuncionariosSetores.Text = "Entra";
            this.btnentraFuncionariosSetores.UseVisualStyleBackColor = true;
            this.btnentraFuncionariosSetores.Click += new System.EventHandler(this.btnentraFuncionariosSetores_Click);
            // 
            // dgvFuncionariosSetores
            // 
            this.dgvFuncionariosSetores.AllowUserToAddRows = false;
            this.dgvFuncionariosSetores.AllowUserToDeleteRows = false;
            this.dgvFuncionariosSetores.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvFuncionariosSetores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFuncionariosSetores.Location = new System.Drawing.Point(18, 272);
            this.dgvFuncionariosSetores.Name = "dgvFuncionariosSetores";
            this.dgvFuncionariosSetores.ReadOnly = true;
            this.dgvFuncionariosSetores.RowHeadersVisible = false;
            this.dgvFuncionariosSetores.RowHeadersWidth = 51;
            this.dgvFuncionariosSetores.RowTemplate.Height = 24;
            this.dgvFuncionariosSetores.Size = new System.Drawing.Size(333, 423);
            this.dgvFuncionariosSetores.TabIndex = 1;
            this.dgvFuncionariosSetores.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFuncionariosSetores_CellClick);
            // 
            // cmbFuncionariosSetores
            // 
            this.cmbFuncionariosSetores.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFuncionariosSetores.FormattingEnabled = true;
            this.cmbFuncionariosSetores.Location = new System.Drawing.Point(18, 43);
            this.cmbFuncionariosSetores.Name = "cmbFuncionariosSetores";
            this.cmbFuncionariosSetores.Size = new System.Drawing.Size(333, 31);
            this.cmbFuncionariosSetores.TabIndex = 0;
            this.cmbFuncionariosSetores.SelectedIndexChanged += new System.EventHandler(this.cmbFuncionariosSetores_SelectedIndexChanged);
            // 
            // gbPassageiros
            // 
            this.gbPassageiros.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.gbPassageiros.Controls.Add(this.tabControl1);
            this.gbPassageiros.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPassageiros.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.gbPassageiros.Location = new System.Drawing.Point(602, 10);
            this.gbPassageiros.Name = "gbPassageiros";
            this.gbPassageiros.Size = new System.Drawing.Size(470, 276);
            this.gbPassageiros.TabIndex = 2;
            this.gbPassageiros.TabStop = false;
            this.gbPassageiros.Text = "Passageiros";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(3, 26);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(461, 244);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tabPage1.Controls.Add(this.dgvEconomica);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 32);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(453, 208);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Econômica";
            // 
            // dgvEconomica
            // 
            this.dgvEconomica.AllowUserToAddRows = false;
            this.dgvEconomica.AllowUserToDeleteRows = false;
            this.dgvEconomica.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEconomica.Location = new System.Drawing.Point(143, 6);
            this.dgvEconomica.Name = "dgvEconomica";
            this.dgvEconomica.ReadOnly = true;
            this.dgvEconomica.RowHeadersVisible = false;
            this.dgvEconomica.RowHeadersWidth = 51;
            this.dgvEconomica.RowTemplate.Height = 24;
            this.dgvEconomica.Size = new System.Drawing.Size(304, 148);
            this.dgvEconomica.TabIndex = 3;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(348, 160);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(99, 42);
            this.button4.TabIndex = 2;
            this.button4.Text = "Entra";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Sistema_de_compainha_aerea.Properties.Resources.Gemini_Generated_Image_y06v51y06v51y06v_removebg_preview;
            this.pictureBox2.Location = new System.Drawing.Point(3, 20);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(134, 93);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.MidnightBlue;
            this.tabPage2.Controls.Add(this.dgvVip);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tabPage2.Location = new System.Drawing.Point(4, 32);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(453, 208);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Vip";
            // 
            // dgvVip
            // 
            this.dgvVip.AllowUserToAddRows = false;
            this.dgvVip.AllowUserToDeleteRows = false;
            this.dgvVip.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvVip.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVip.Location = new System.Drawing.Point(141, 7);
            this.dgvVip.Name = "dgvVip";
            this.dgvVip.ReadOnly = true;
            this.dgvVip.RowHeadersVisible = false;
            this.dgvVip.RowHeadersWidth = 51;
            this.dgvVip.RowTemplate.Height = 24;
            this.dgvVip.Size = new System.Drawing.Size(306, 138);
            this.dgvVip.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label1.Location = new System.Drawing.Point(6, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "Desconto 15%";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(341, 163);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(106, 39);
            this.button2.TabIndex = 2;
            this.button2.Text = "Entra";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Sistema_de_compainha_aerea.Properties.Resources.Gemini_Generated_Image_p5bsd3p5bsd3p5bs_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(6, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(129, 84);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // gbCaixa
            // 
            this.gbCaixa.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.gbCaixa.Controls.Add(this.button3);
            this.gbCaixa.Controls.Add(this.dgvExibirPagamentos);
            this.gbCaixa.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbCaixa.ForeColor = System.Drawing.SystemColors.Highlight;
            this.gbCaixa.Location = new System.Drawing.Point(602, 311);
            this.gbCaixa.Name = "gbCaixa";
            this.gbCaixa.Size = new System.Drawing.Size(470, 287);
            this.gbCaixa.TabIndex = 3;
            this.gbCaixa.TabStop = false;
            this.gbCaixa.Text = "Pagamentos";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(189, 226);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(92, 48);
            this.button3.TabIndex = 1;
            this.button3.Text = "Entra";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dgvExibirPagamentos
            // 
            this.dgvExibirPagamentos.AllowUserToAddRows = false;
            this.dgvExibirPagamentos.AllowUserToDeleteRows = false;
            this.dgvExibirPagamentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvExibirPagamentos.Location = new System.Drawing.Point(20, 29);
            this.dgvExibirPagamentos.Name = "dgvExibirPagamentos";
            this.dgvExibirPagamentos.ReadOnly = true;
            this.dgvExibirPagamentos.RowHeadersVisible = false;
            this.dgvExibirPagamentos.RowHeadersWidth = 51;
            this.dgvExibirPagamentos.RowTemplate.Height = 24;
            this.dgvExibirPagamentos.Size = new System.Drawing.Size(434, 177);
            this.dgvExibirPagamentos.TabIndex = 0;
            // 
            // gbAgendamentos
            // 
            this.gbAgendamentos.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.gbAgendamentos.Controls.Add(this.dgvVoos);
            this.gbAgendamentos.Controls.Add(this.btnAgendamento);
            this.gbAgendamentos.Controls.Add(this.pictureBox3);
            this.gbAgendamentos.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbAgendamentos.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.gbAgendamentos.Location = new System.Drawing.Point(1088, 10);
            this.gbAgendamentos.Name = "gbAgendamentos";
            this.gbAgendamentos.Size = new System.Drawing.Size(556, 276);
            this.gbAgendamentos.TabIndex = 4;
            this.gbAgendamentos.TabStop = false;
            this.gbAgendamentos.Text = "Agendamentos voos";
            // 
            // dgvVoos
            // 
            this.dgvVoos.AllowUserToAddRows = false;
            this.dgvVoos.AllowUserToDeleteRows = false;
            this.dgvVoos.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvVoos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVoos.Location = new System.Drawing.Point(13, 26);
            this.dgvVoos.Name = "dgvVoos";
            this.dgvVoos.ReadOnly = true;
            this.dgvVoos.RowHeadersVisible = false;
            this.dgvVoos.RowHeadersWidth = 51;
            this.dgvVoos.RowTemplate.Height = 24;
            this.dgvVoos.Size = new System.Drawing.Size(531, 150);
            this.dgvVoos.TabIndex = 8;
            // 
            // btnAgendamento
            // 
            this.btnAgendamento.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnAgendamento.Location = new System.Drawing.Point(223, 201);
            this.btnAgendamento.Name = "btnAgendamento";
            this.btnAgendamento.Size = new System.Drawing.Size(78, 39);
            this.btnAgendamento.TabIndex = 7;
            this.btnAgendamento.Text = "Entra";
            this.btnAgendamento.UseVisualStyleBackColor = true;
            this.btnAgendamento.Click += new System.EventHandler(this.btnAgendamento_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::Sistema_de_compainha_aerea.Properties.Resources.Gemini_Generated_Image_we8c15we8c15we8c_removebg_preview;
            this.pictureBox3.Location = new System.Drawing.Point(427, 201);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(111, 59);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // gbRelatorios
            // 
            this.gbRelatorios.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.gbRelatorios.Controls.Add(this.button6);
            this.gbRelatorios.Controls.Add(this.dataGridView2);
            this.gbRelatorios.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbRelatorios.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.gbRelatorios.Location = new System.Drawing.Point(1088, 321);
            this.gbRelatorios.Name = "gbRelatorios";
            this.gbRelatorios.Size = new System.Drawing.Size(544, 277);
            this.gbRelatorios.TabIndex = 8;
            this.gbRelatorios.TabStop = false;
            this.gbRelatorios.Text = "Relatorios";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(223, 216);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(116, 40);
            this.button6.TabIndex = 1;
            this.button6.Text = "Entra";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(13, 26);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(508, 172);
            this.dataGridView2.TabIndex = 0;
            // 
            // sistemadeAeroportoDataSet
            // 
            this.sistemadeAeroportoDataSet.DataSetName = "SistemadeAeroportoDataSet";
            this.sistemadeAeroportoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // passageirosBindingSource
            // 
            this.passageirosBindingSource.DataMember = "Passageiros";
            this.passageirosBindingSource.DataSource = this.sistemadeAeroportoDataSet;
            // 
            // passageirosTableAdapter
            // 
            this.passageirosTableAdapter.ClearBeforeFill = true;
            // 
            // MenuInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1652, 802);
            this.Controls.Add(this.gbRelatorios);
            this.Controls.Add(this.gbAgendamentos);
            this.Controls.Add(this.gbCaixa);
            this.Controls.Add(this.gbPassageiros);
            this.Controls.Add(this.gbFuncionariosSetores);
            this.Controls.Add(this.tsMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MenuInicial";
            this.Text = "Início";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MenuInicial_FormClosed);
            this.Load += new System.EventHandler(this.MenuInicial_Load);
            this.tsMenu.ResumeLayout(false);
            this.tsMenu.PerformLayout();
            this.gbFuncionariosSetores.ResumeLayout(false);
            this.gbFuncionariosSetores.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFuncionariosSetores)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFuncionariosSetores)).EndInit();
            this.gbPassageiros.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEconomica)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.gbCaixa.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvExibirPagamentos)).EndInit();
            this.gbAgendamentos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVoos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.gbRelatorios.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemadeAeroportoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passageirosBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tsMenu;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton btnFuncionariosSetores;
        private System.Windows.Forms.ToolStripButton btnChecking;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.GroupBox gbFuncionariosSetores;
        private System.Windows.Forms.Button btnentraFuncionariosSetores;
        private System.Windows.Forms.DataGridView dgvFuncionariosSetores;
        private System.Windows.Forms.ComboBox cmbFuncionariosSetores;
        private System.Windows.Forms.GroupBox gbPassageiros;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox gbCaixa;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dgvExibirPagamentos;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbAgendamentos;
        private System.Windows.Forms.Button btnAgendamento;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox gbRelatorios;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.PictureBox pbFuncionariosSetores;
        private System.Windows.Forms.TextBox txtFuncionarioSetores;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripButton btnVoos;
        private SistemadeAeroportoDataSet sistemadeAeroportoDataSet;
        private System.Windows.Forms.BindingSource passageirosBindingSource;
        private SistemadeAeroportoDataSetTableAdapters.PassageirosTableAdapter passageirosTableAdapter;
        private System.Windows.Forms.DataGridView dgvEconomica;
        private System.Windows.Forms.DataGridView dgvVip;
        private System.Windows.Forms.DataGridView dgvVoos;
    }
}