﻿namespace Sistema_de_compainha_aerea
{
    partial class agendamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Pesquisarporvoos = new System.Windows.Forms.Button();
            this.dtpdatavoo = new System.Windows.Forms.DateTimePicker();
            this.txtDestinovoo = new System.Windows.Forms.TextBox();
            this.txtorigemvoo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnAtulizarvoos = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnConfirmaVoo = new System.Windows.Forms.Button();
            this.dgvVoosEncontrados = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnConsultarPassageiro = new System.Windows.Forms.Button();
            this.btnPesquisarPassageiroagendamento = new System.Windows.Forms.Button();
            this.txtPassaporteAgendamento = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtcpfPassageiroAgendamento = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnRemoverAgendamento = new System.Windows.Forms.Button();
            this.btnConfirmarAgendamento = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgvListaAgendamento = new System.Windows.Forms.DataGridView();
            this.btnLimparDadosAgendamento = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pnlCartaoEmbarque = new System.Windows.Forms.Panel();
            this.btnimprimircartao = new System.Windows.Forms.Button();
            this.lbTerminal = new System.Windows.Forms.Label();
            this.lbTituloTerminal = new System.Windows.Forms.Label();
            this.lbportao = new System.Windows.Forms.Label();
            this.lbTituloPortao = new System.Windows.Forms.Label();
            this.lbHoraCartao = new System.Windows.Forms.Label();
            this.lbTituloHora = new System.Windows.Forms.Label();
            this.lbDatacartao = new System.Windows.Forms.Label();
            this.lbTituloData = new System.Windows.Forms.Label();
            this.lbVooCartao = new System.Windows.Forms.Label();
            this.lbVooTitulo = new System.Windows.Forms.Label();
            this.lbDestinoCartao = new System.Windows.Forms.Label();
            this.lbTituloPara = new System.Windows.Forms.Label();
            this.lbOrigemCartao = new System.Windows.Forms.Label();
            this.lbRotaTituloDe = new System.Windows.Forms.Label();
            this.lbClasse = new System.Windows.Forms.Label();
            this.lbClasseTitulo = new System.Windows.Forms.Label();
            this.lbNomePassageiroCartao = new System.Windows.Forms.Label();
            this.lbPassageiroTitulo = new System.Windows.Forms.Label();
            this.pbLogoEmpressa = new System.Windows.Forms.PictureBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVoosEncontrados)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaAgendamento)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.pnlCartaoEmbarque.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoEmpressa)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Pesquisarporvoos);
            this.groupBox1.Controls.Add(this.dtpdatavoo);
            this.groupBox1.Controls.Add(this.txtDestinovoo);
            this.groupBox1.Controls.Add(this.txtorigemvoo);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(12, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(825, 120);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pesquisar Voos";
            // 
            // Pesquisarporvoos
            // 
            this.Pesquisarporvoos.Location = new System.Drawing.Point(624, 56);
            this.Pesquisarporvoos.Name = "Pesquisarporvoos";
            this.Pesquisarporvoos.Size = new System.Drawing.Size(111, 41);
            this.Pesquisarporvoos.TabIndex = 8;
            this.Pesquisarporvoos.Text = "Pesquisar";
            this.Pesquisarporvoos.UseVisualStyleBackColor = true;
            this.Pesquisarporvoos.Click += new System.EventHandler(this.Pesquisarporvoos_Click);
            // 
            // dtpdatavoo
            // 
            this.dtpdatavoo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdatavoo.Location = new System.Drawing.Point(391, 67);
            this.dtpdatavoo.Name = "dtpdatavoo";
            this.dtpdatavoo.Size = new System.Drawing.Size(161, 30);
            this.dtpdatavoo.TabIndex = 6;
            // 
            // txtDestinovoo
            // 
            this.txtDestinovoo.Location = new System.Drawing.Point(188, 67);
            this.txtDestinovoo.Name = "txtDestinovoo";
            this.txtDestinovoo.Size = new System.Drawing.Size(177, 30);
            this.txtDestinovoo.TabIndex = 5;
            // 
            // txtorigemvoo
            // 
            this.txtorigemvoo.Location = new System.Drawing.Point(6, 67);
            this.txtorigemvoo.Name = "txtorigemvoo";
            this.txtorigemvoo.Size = new System.Drawing.Size(156, 30);
            this.txtorigemvoo.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(387, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Data do voo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(184, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Destino:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Origem:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnAtulizarvoos);
            this.groupBox2.Controls.Add(this.btnCancelar);
            this.groupBox2.Controls.Add(this.btnConfirmaVoo);
            this.groupBox2.Controls.Add(this.dgvVoosEncontrados);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox2.Location = new System.Drawing.Point(12, 147);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(825, 321);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Voos Encontrados";
            // 
            // btnAtulizarvoos
            // 
            this.btnAtulizarvoos.Location = new System.Drawing.Point(339, 270);
            this.btnAtulizarvoos.Name = "btnAtulizarvoos";
            this.btnAtulizarvoos.Size = new System.Drawing.Size(110, 36);
            this.btnAtulizarvoos.TabIndex = 3;
            this.btnAtulizarvoos.Text = "Atualizar";
            this.btnAtulizarvoos.UseVisualStyleBackColor = true;
            this.btnAtulizarvoos.Click += new System.EventHandler(this.btnAtulizarvoos_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.Red;
            this.btnCancelar.Location = new System.Drawing.Point(188, 270);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(127, 36);
            this.btnCancelar.TabIndex = 2;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnConfirmaVoo
            // 
            this.btnConfirmaVoo.BackColor = System.Drawing.Color.GreenYellow;
            this.btnConfirmaVoo.Location = new System.Drawing.Point(10, 270);
            this.btnConfirmaVoo.Name = "btnConfirmaVoo";
            this.btnConfirmaVoo.Size = new System.Drawing.Size(152, 36);
            this.btnConfirmaVoo.TabIndex = 1;
            this.btnConfirmaVoo.Text = "Confirma";
            this.btnConfirmaVoo.UseVisualStyleBackColor = false;
            this.btnConfirmaVoo.Click += new System.EventHandler(this.btnConfirmaVoo_Click);
            // 
            // dgvVoosEncontrados
            // 
            this.dgvVoosEncontrados.AllowUserToAddRows = false;
            this.dgvVoosEncontrados.AllowUserToDeleteRows = false;
            this.dgvVoosEncontrados.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvVoosEncontrados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVoosEncontrados.Location = new System.Drawing.Point(3, 28);
            this.dgvVoosEncontrados.Name = "dgvVoosEncontrados";
            this.dgvVoosEncontrados.ReadOnly = true;
            this.dgvVoosEncontrados.RowHeadersVisible = false;
            this.dgvVoosEncontrados.RowHeadersWidth = 51;
            this.dgvVoosEncontrados.RowTemplate.Height = 24;
            this.dgvVoosEncontrados.Size = new System.Drawing.Size(762, 224);
            this.dgvVoosEncontrados.TabIndex = 0;
            this.dgvVoosEncontrados.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVoosEncontrados_CellClick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnConsultarPassageiro);
            this.groupBox3.Controls.Add(this.btnPesquisarPassageiroagendamento);
            this.groupBox3.Controls.Add(this.txtPassaporteAgendamento);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.txtcpfPassageiroAgendamento);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox3.Location = new System.Drawing.Point(12, 494);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(825, 144);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Dados Passageiros";
            // 
            // btnConsultarPassageiro
            // 
            this.btnConsultarPassageiro.Location = new System.Drawing.Point(544, 92);
            this.btnConsultarPassageiro.Name = "btnConsultarPassageiro";
            this.btnConsultarPassageiro.Size = new System.Drawing.Size(227, 37);
            this.btnConsultarPassageiro.TabIndex = 9;
            this.btnConsultarPassageiro.Text = "Consulta Passageiro";
            this.btnConsultarPassageiro.UseVisualStyleBackColor = true;
            this.btnConsultarPassageiro.Click += new System.EventHandler(this.btnConsultarPassageiro_Click);
            // 
            // btnPesquisarPassageiroagendamento
            // 
            this.btnPesquisarPassageiroagendamento.Location = new System.Drawing.Point(580, 31);
            this.btnPesquisarPassageiroagendamento.Name = "btnPesquisarPassageiroagendamento";
            this.btnPesquisarPassageiroagendamento.Size = new System.Drawing.Size(147, 37);
            this.btnPesquisarPassageiroagendamento.TabIndex = 8;
            this.btnPesquisarPassageiroagendamento.Text = "Pesquisar";
            this.btnPesquisarPassageiroagendamento.UseVisualStyleBackColor = true;
            this.btnPesquisarPassageiroagendamento.Click += new System.EventHandler(this.btnPesquisarPassageiroagendamento_Click);
            // 
            // txtPassaporteAgendamento
            // 
            this.txtPassaporteAgendamento.Location = new System.Drawing.Point(247, 54);
            this.txtPassaporteAgendamento.Name = "txtPassaporteAgendamento";
            this.txtPassaporteAgendamento.Size = new System.Drawing.Size(202, 30);
            this.txtPassaporteAgendamento.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(243, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 23);
            this.label4.TabIndex = 6;
            this.label4.Text = "Passaporte";
            // 
            // txtcpfPassageiroAgendamento
            // 
            this.txtcpfPassageiroAgendamento.Location = new System.Drawing.Point(13, 54);
            this.txtcpfPassageiroAgendamento.Name = "txtcpfPassageiroAgendamento";
            this.txtcpfPassageiroAgendamento.Size = new System.Drawing.Size(201, 30);
            this.txtcpfPassageiroAgendamento.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 23);
            this.label6.TabIndex = 1;
            this.label6.Text = "CPF:";
            // 
            // btnRemoverAgendamento
            // 
            this.btnRemoverAgendamento.BackColor = System.Drawing.Color.Red;
            this.btnRemoverAgendamento.Location = new System.Drawing.Point(272, 229);
            this.btnRemoverAgendamento.Name = "btnRemoverAgendamento";
            this.btnRemoverAgendamento.Size = new System.Drawing.Size(109, 37);
            this.btnRemoverAgendamento.TabIndex = 5;
            this.btnRemoverAgendamento.Text = "Remover";
            this.btnRemoverAgendamento.UseVisualStyleBackColor = false;
            this.btnRemoverAgendamento.Click += new System.EventHandler(this.btnRemoverAgendamento_Click);
            // 
            // btnConfirmarAgendamento
            // 
            this.btnConfirmarAgendamento.BackColor = System.Drawing.Color.GreenYellow;
            this.btnConfirmarAgendamento.Location = new System.Drawing.Point(0, 229);
            this.btnConfirmarAgendamento.Name = "btnConfirmarAgendamento";
            this.btnConfirmarAgendamento.Size = new System.Drawing.Size(250, 37);
            this.btnConfirmarAgendamento.TabIndex = 4;
            this.btnConfirmarAgendamento.Text = "Confirma agendamento";
            this.btnConfirmarAgendamento.UseVisualStyleBackColor = false;
            this.btnConfirmarAgendamento.Click += new System.EventHandler(this.btnConfirmarAgendamento_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dgvListaAgendamento);
            this.groupBox4.Controls.Add(this.btnConfirmarAgendamento);
            this.groupBox4.Controls.Add(this.btnRemoverAgendamento);
            this.groupBox4.Controls.Add(this.btnLimparDadosAgendamento);
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox4.Location = new System.Drawing.Point(12, 657);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(825, 295);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Agendamento de Passageiros";
            // 
            // dgvListaAgendamento
            // 
            this.dgvListaAgendamento.AllowUserToAddRows = false;
            this.dgvListaAgendamento.AllowUserToDeleteRows = false;
            this.dgvListaAgendamento.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvListaAgendamento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaAgendamento.Location = new System.Drawing.Point(0, 29);
            this.dgvListaAgendamento.Name = "dgvListaAgendamento";
            this.dgvListaAgendamento.ReadOnly = true;
            this.dgvListaAgendamento.RowHeadersVisible = false;
            this.dgvListaAgendamento.RowHeadersWidth = 51;
            this.dgvListaAgendamento.RowTemplate.Height = 24;
            this.dgvListaAgendamento.Size = new System.Drawing.Size(771, 185);
            this.dgvListaAgendamento.TabIndex = 0;
            this.dgvListaAgendamento.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListaAgendamento_CellClick);
            // 
            // btnLimparDadosAgendamento
            // 
            this.btnLimparDadosAgendamento.Location = new System.Drawing.Point(401, 229);
            this.btnLimparDadosAgendamento.Name = "btnLimparDadosAgendamento";
            this.btnLimparDadosAgendamento.Size = new System.Drawing.Size(94, 37);
            this.btnLimparDadosAgendamento.TabIndex = 4;
            this.btnLimparDadosAgendamento.Text = "Limpar";
            this.btnLimparDadosAgendamento.UseVisualStyleBackColor = true;
            this.btnLimparDadosAgendamento.Click += new System.EventHandler(this.btnLimparDadosAgendamento_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.pnlCartaoEmbarque);
            this.groupBox5.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox5.Location = new System.Drawing.Point(874, 21);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(554, 931);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Cartão de Embarque";
            // 
            // pnlCartaoEmbarque
            // 
            this.pnlCartaoEmbarque.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCartaoEmbarque.Controls.Add(this.btnimprimircartao);
            this.pnlCartaoEmbarque.Controls.Add(this.lbTerminal);
            this.pnlCartaoEmbarque.Controls.Add(this.lbTituloTerminal);
            this.pnlCartaoEmbarque.Controls.Add(this.lbportao);
            this.pnlCartaoEmbarque.Controls.Add(this.lbTituloPortao);
            this.pnlCartaoEmbarque.Controls.Add(this.lbHoraCartao);
            this.pnlCartaoEmbarque.Controls.Add(this.lbTituloHora);
            this.pnlCartaoEmbarque.Controls.Add(this.lbDatacartao);
            this.pnlCartaoEmbarque.Controls.Add(this.lbTituloData);
            this.pnlCartaoEmbarque.Controls.Add(this.lbVooCartao);
            this.pnlCartaoEmbarque.Controls.Add(this.lbVooTitulo);
            this.pnlCartaoEmbarque.Controls.Add(this.lbDestinoCartao);
            this.pnlCartaoEmbarque.Controls.Add(this.lbTituloPara);
            this.pnlCartaoEmbarque.Controls.Add(this.lbOrigemCartao);
            this.pnlCartaoEmbarque.Controls.Add(this.lbRotaTituloDe);
            this.pnlCartaoEmbarque.Controls.Add(this.lbClasse);
            this.pnlCartaoEmbarque.Controls.Add(this.lbClasseTitulo);
            this.pnlCartaoEmbarque.Controls.Add(this.lbNomePassageiroCartao);
            this.pnlCartaoEmbarque.Controls.Add(this.lbPassageiroTitulo);
            this.pnlCartaoEmbarque.Controls.Add(this.pbLogoEmpressa);
            this.pnlCartaoEmbarque.Location = new System.Drawing.Point(3, 56);
            this.pnlCartaoEmbarque.Name = "pnlCartaoEmbarque";
            this.pnlCartaoEmbarque.Size = new System.Drawing.Size(545, 859);
            this.pnlCartaoEmbarque.TabIndex = 0;
            // 
            // btnimprimircartao
            // 
            this.btnimprimircartao.Location = new System.Drawing.Point(150, 737);
            this.btnimprimircartao.Name = "btnimprimircartao";
            this.btnimprimircartao.Size = new System.Drawing.Size(201, 46);
            this.btnimprimircartao.TabIndex = 22;
            this.btnimprimircartao.Text = "Imprimir cartao";
            this.btnimprimircartao.UseVisualStyleBackColor = true;
            this.btnimprimircartao.Click += new System.EventHandler(this.btnimprimircartao_Click);
            // 
            // lbTerminal
            // 
            this.lbTerminal.AutoSize = true;
            this.lbTerminal.Location = new System.Drawing.Point(182, 620);
            this.lbTerminal.Name = "lbTerminal";
            this.lbTerminal.Size = new System.Drawing.Size(31, 23);
            this.lbTerminal.TabIndex = 21;
            this.lbTerminal.Text = "---";
            // 
            // lbTituloTerminal
            // 
            this.lbTituloTerminal.AutoSize = true;
            this.lbTituloTerminal.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTituloTerminal.Location = new System.Drawing.Point(182, 569);
            this.lbTituloTerminal.Name = "lbTituloTerminal";
            this.lbTituloTerminal.Size = new System.Drawing.Size(74, 23);
            this.lbTituloTerminal.TabIndex = 20;
            this.lbTituloTerminal.Text = "Terminal";
            // 
            // lbportao
            // 
            this.lbportao.AutoSize = true;
            this.lbportao.Location = new System.Drawing.Point(35, 620);
            this.lbportao.Name = "lbportao";
            this.lbportao.Size = new System.Drawing.Size(31, 23);
            this.lbportao.TabIndex = 19;
            this.lbportao.Text = "---";
            // 
            // lbTituloPortao
            // 
            this.lbTituloPortao.AutoSize = true;
            this.lbTituloPortao.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTituloPortao.Location = new System.Drawing.Point(35, 569);
            this.lbTituloPortao.Name = "lbTituloPortao";
            this.lbTituloPortao.Size = new System.Drawing.Size(60, 23);
            this.lbTituloPortao.TabIndex = 18;
            this.lbTituloPortao.Text = "Portão";
            // 
            // lbHoraCartao
            // 
            this.lbHoraCartao.AutoSize = true;
            this.lbHoraCartao.Location = new System.Drawing.Point(345, 486);
            this.lbHoraCartao.Name = "lbHoraCartao";
            this.lbHoraCartao.Size = new System.Drawing.Size(31, 23);
            this.lbHoraCartao.TabIndex = 17;
            this.lbHoraCartao.Text = "---";
            // 
            // lbTituloHora
            // 
            this.lbTituloHora.AutoSize = true;
            this.lbTituloHora.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTituloHora.Location = new System.Drawing.Point(343, 429);
            this.lbTituloHora.Name = "lbTituloHora";
            this.lbTituloHora.Size = new System.Drawing.Size(47, 23);
            this.lbTituloHora.TabIndex = 16;
            this.lbTituloHora.Text = "Hora";
            // 
            // lbDatacartao
            // 
            this.lbDatacartao.AutoSize = true;
            this.lbDatacartao.Location = new System.Drawing.Point(198, 486);
            this.lbDatacartao.Name = "lbDatacartao";
            this.lbDatacartao.Size = new System.Drawing.Size(31, 23);
            this.lbDatacartao.TabIndex = 15;
            this.lbDatacartao.Text = "---";
            // 
            // lbTituloData
            // 
            this.lbTituloData.AutoSize = true;
            this.lbTituloData.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTituloData.Location = new System.Drawing.Point(198, 429);
            this.lbTituloData.Name = "lbTituloData";
            this.lbTituloData.Size = new System.Drawing.Size(46, 23);
            this.lbTituloData.TabIndex = 14;
            this.lbTituloData.Text = "Data";
            // 
            // lbVooCartao
            // 
            this.lbVooCartao.AutoSize = true;
            this.lbVooCartao.Location = new System.Drawing.Point(40, 486);
            this.lbVooCartao.Name = "lbVooCartao";
            this.lbVooCartao.Size = new System.Drawing.Size(31, 23);
            this.lbVooCartao.TabIndex = 13;
            this.lbVooCartao.Text = "---";
            // 
            // lbVooTitulo
            // 
            this.lbVooTitulo.AutoSize = true;
            this.lbVooTitulo.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVooTitulo.Location = new System.Drawing.Point(40, 429);
            this.lbVooTitulo.Name = "lbVooTitulo";
            this.lbVooTitulo.Size = new System.Drawing.Size(40, 23);
            this.lbVooTitulo.TabIndex = 12;
            this.lbVooTitulo.Text = "Voo";
            // 
            // lbDestinoCartao
            // 
            this.lbDestinoCartao.AutoSize = true;
            this.lbDestinoCartao.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDestinoCartao.Location = new System.Drawing.Point(280, 312);
            this.lbDestinoCartao.Name = "lbDestinoCartao";
            this.lbDestinoCartao.Size = new System.Drawing.Size(50, 38);
            this.lbDestinoCartao.TabIndex = 11;
            this.lbDestinoCartao.Text = "---";
            // 
            // lbTituloPara
            // 
            this.lbTituloPara.AutoSize = true;
            this.lbTituloPara.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTituloPara.Location = new System.Drawing.Point(283, 266);
            this.lbTituloPara.Name = "lbTituloPara";
            this.lbTituloPara.Size = new System.Drawing.Size(43, 23);
            this.lbTituloPara.TabIndex = 10;
            this.lbTituloPara.Text = "Para";
            // 
            // lbOrigemCartao
            // 
            this.lbOrigemCartao.AutoSize = true;
            this.lbOrigemCartao.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOrigemCartao.Location = new System.Drawing.Point(50, 312);
            this.lbOrigemCartao.Name = "lbOrigemCartao";
            this.lbOrigemCartao.Size = new System.Drawing.Size(50, 38);
            this.lbOrigemCartao.TabIndex = 9;
            this.lbOrigemCartao.Text = "---";
            // 
            // lbRotaTituloDe
            // 
            this.lbRotaTituloDe.AutoSize = true;
            this.lbRotaTituloDe.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRotaTituloDe.Location = new System.Drawing.Point(50, 266);
            this.lbRotaTituloDe.Name = "lbRotaTituloDe";
            this.lbRotaTituloDe.Size = new System.Drawing.Size(31, 23);
            this.lbRotaTituloDe.TabIndex = 8;
            this.lbRotaTituloDe.Text = "De";
            // 
            // lbClasse
            // 
            this.lbClasse.AutoSize = true;
            this.lbClasse.Font = new System.Drawing.Font("Segoe UI Semibold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbClasse.Location = new System.Drawing.Point(329, 179);
            this.lbClasse.Name = "lbClasse";
            this.lbClasse.Size = new System.Drawing.Size(50, 38);
            this.lbClasse.TabIndex = 5;
            this.lbClasse.Text = "---";
            // 
            // lbClasseTitulo
            // 
            this.lbClasseTitulo.AutoSize = true;
            this.lbClasseTitulo.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbClasseTitulo.Location = new System.Drawing.Point(322, 135);
            this.lbClasseTitulo.Name = "lbClasseTitulo";
            this.lbClasseTitulo.Size = new System.Drawing.Size(57, 23);
            this.lbClasseTitulo.TabIndex = 4;
            this.lbClasseTitulo.Text = "Classe";
            // 
            // lbNomePassageiroCartao
            // 
            this.lbNomePassageiroCartao.AutoSize = true;
            this.lbNomePassageiroCartao.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNomePassageiroCartao.Location = new System.Drawing.Point(34, 179);
            this.lbNomePassageiroCartao.Name = "lbNomePassageiroCartao";
            this.lbNomePassageiroCartao.Size = new System.Drawing.Size(50, 38);
            this.lbNomePassageiroCartao.TabIndex = 3;
            this.lbNomePassageiroCartao.Text = "---";
            // 
            // lbPassageiroTitulo
            // 
            this.lbPassageiroTitulo.AutoSize = true;
            this.lbPassageiroTitulo.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPassageiroTitulo.Location = new System.Drawing.Point(24, 135);
            this.lbPassageiroTitulo.Name = "lbPassageiroTitulo";
            this.lbPassageiroTitulo.Size = new System.Drawing.Size(90, 23);
            this.lbPassageiroTitulo.TabIndex = 2;
            this.lbPassageiroTitulo.Text = "Passageiro";
            // 
            // pbLogoEmpressa
            // 
            this.pbLogoEmpressa.Image = global::Sistema_de_compainha_aerea.Properties.Resources.Gemini_Generated_Image_2a399k2a399k2a398;
            this.pbLogoEmpressa.Location = new System.Drawing.Point(0, 0);
            this.pbLogoEmpressa.Name = "pbLogoEmpressa";
            this.pbLogoEmpressa.Size = new System.Drawing.Size(544, 118);
            this.pbLogoEmpressa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogoEmpressa.TabIndex = 0;
            this.pbLogoEmpressa.TabStop = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // agendamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1460, 1002);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Name = "agendamento";
            this.Text = "agendamento";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVoosEncontrados)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaAgendamento)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.pnlCartaoEmbarque.ResumeLayout(false);
            this.pnlCartaoEmbarque.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoEmpressa)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Pesquisarporvoos;
        private System.Windows.Forms.DateTimePicker dtpdatavoo;
        private System.Windows.Forms.TextBox txtDestinovoo;
        private System.Windows.Forms.TextBox txtorigemvoo;
        private System.Windows.Forms.Button btnRemoverAgendamento;
        private System.Windows.Forms.Button btnConfirmarAgendamento;
        private System.Windows.Forms.DataGridView dgvVoosEncontrados;
        private System.Windows.Forms.DataGridView dgvListaAgendamento;
        private System.Windows.Forms.TextBox txtcpfPassageiroAgendamento;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnConfirmaVoo;
        private System.Windows.Forms.Button btnAtulizarvoos;
        private System.Windows.Forms.Button btnLimparDadosAgendamento;
        private System.Windows.Forms.TextBox txtPassaporteAgendamento;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnPesquisarPassageiroagendamento;
        private System.Windows.Forms.Button btnConsultarPassageiro;
        private System.Windows.Forms.Panel pnlCartaoEmbarque;
        private System.Windows.Forms.Label lbNomePassageiroCartao;
        private System.Windows.Forms.Label lbPassageiroTitulo;
        private System.Windows.Forms.PictureBox pbLogoEmpressa;
        private System.Windows.Forms.Label lbClasse;
        private System.Windows.Forms.Label lbClasseTitulo;
        private System.Windows.Forms.Label lbDestinoCartao;
        private System.Windows.Forms.Label lbTituloPara;
        private System.Windows.Forms.Label lbOrigemCartao;
        private System.Windows.Forms.Label lbRotaTituloDe;
        private System.Windows.Forms.Label lbTerminal;
        private System.Windows.Forms.Label lbTituloTerminal;
        private System.Windows.Forms.Label lbportao;
        private System.Windows.Forms.Label lbTituloPortao;
        private System.Windows.Forms.Label lbHoraCartao;
        private System.Windows.Forms.Label lbTituloHora;
        private System.Windows.Forms.Label lbDatacartao;
        private System.Windows.Forms.Label lbTituloData;
        private System.Windows.Forms.Label lbVooCartao;
        private System.Windows.Forms.Label lbVooTitulo;
        private System.Windows.Forms.Button btnimprimircartao;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}