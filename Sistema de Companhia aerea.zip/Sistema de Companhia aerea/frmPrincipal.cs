﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Sistema_de_compainha_aerea
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnAcessar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtId.Text) && string.IsNullOrWhiteSpace(txtSenha.Text))
                {
                    MessageBox.Show("Por favor, preencha os campos de ID e Senha.", "Campos Vazios", MessageBoxButtons.OK, MessageBoxIcon.Warning);// Exibe uma mensagem de aviso caso ambos os campos estejam vazios

                    txtId.Focus(); // Define o foco no campo de ID
                }
                else
                {
                    Loginsenha login = new Loginsenha();

                    bool resultado = login.ValidarLogin(txtId.Text, txtSenha.Text);

                    if (resultado)
                    {
                        MessageBox.Show("Login bem-sucedido!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);// Exibe uma mensagem de sucesso caso o login seja válido")

                        MenuInicial menu = new MenuInicial();
                        menu.Show();

                        this.Hide(); // Oculta o formulário de login após o login bem-sucedido

                    }

                    else
                    {
                        MessageBox.Show("ID ou senha incorretos. Tente novamente.", "Erro de Login", MessageBoxButtons.OK, MessageBoxIcon.Error);// Exibe uma mensagem de erro caso o login seja inválido

                        txtId.Clear(); // Limpa o campo de ID
                        txtSenha.Clear(); // Limpa o campo de senha
                        txtId.Focus(); // Define o foco no campo de ID para que o usuário possa tentar novamente
                    }
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Ocorreu um erro ao tentar fazer o login. Por favor, tente novamente ou entre em contato com o suporte caso o erro persista.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);// Exibe uma mensagem de erro caso ocorra uma exceção durante o processo de login
            }
        }

        private void frmPrincipal_Resize(object sender, EventArgs e)
        {
            gbLogin.Left = (this.ClientSize.Width - gbLogin.Width) / 2; // Centraliza o GroupBox horizontalmente
            gbLogin.Top = (this.ClientSize.Height - gbLogin.Height) / 2;// Centraliza o GroupBox verticalmente

            timerDataHora.Start(); // Inicia o timer para atualizar a data e hora
        }

        private void timerDataHora_Tick(object sender, EventArgs e)
        {
            lblDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy    HH:mm:ss");// Atualiza o Label com a data e hora atual
        }

        private void txtSenha_TextChanged(object sender, EventArgs e)
        {
            txtSenha.UseSystemPasswordChar = true;// Define o campo de senha para ocultar os caracteres digitados
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                try
                {
                    conexao.Open();// Tenta abrir a conexão com o banco de dados
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);// Exibe uma mensagem de erro caso ocorra uma exceção ao tentar conectar ao banco de dados
                }
            }
        }
    }
}
