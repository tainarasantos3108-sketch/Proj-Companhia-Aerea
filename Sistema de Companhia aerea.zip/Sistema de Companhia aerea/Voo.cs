﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_compainha_aerea
{
    public class Voo
    {
        public void Salvarvoos(string tipovoo, string origem, string destino, DateTime datahorapartida, DateTime datahorachegada, string portao, string terminal, string status)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"INSERT INTO VOOS (TIPO_VOO, ORIGEM, DESTINO, DATA_HORA_PARTIDA, DATA_HORA_CHEGADA, PORTAO, TERMINAL, STATUS) VALUES (@tipovoo, @origem, @destino, @datahorapartida, @datahorachegada, @portao, @terminal, @status)";
                {
                    SqlCommand comando = new SqlCommand(sql, conexao);

                    comando.Parameters.AddWithValue("@tipovoo", tipovoo);
                    comando.Parameters.AddWithValue("@origem", origem);
                    comando.Parameters.AddWithValue("@destino", destino);
                    comando.Parameters.AddWithValue("@datahorapartida", datahorapartida);
                    comando.Parameters.AddWithValue("@datahorachegada", datahorachegada);
                    comando.Parameters.AddWithValue("@portao", portao);
                    comando.Parameters.AddWithValue("@terminal", terminal);
                    comando.Parameters.AddWithValue("@status", status);

                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }

        public void AlterarVoos(int idVoo, string tipovoo, string origem, string destino, DateTime datahorapartida, DateTime datahorachegada, string portao, string terminal, string status)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"UPDATE VOOS SET TIPO_VOO = @tipovoo, ORIGEM = @origem, DESTINO = @destino, DATA_HORA_PARTIDA = @datahorapartida, DATA_HORA_CHEGADA = @dataHoraChegada, PORTAO = @portao, TERMINAL = @terminal, STATUS = @status WHERE ID_VOO = @idvoo";

                SqlCommand comando = new SqlCommand(sql, conexao);
                comando.Parameters.AddWithValue("@idvoo", idVoo);
                comando.Parameters.AddWithValue("@tipovoo", tipovoo);
                comando.Parameters.AddWithValue("@origem", origem);
                comando.Parameters.AddWithValue("@destino", destino);
                comando.Parameters.AddWithValue("@datahorapartida", datahorapartida);
                comando.Parameters.AddWithValue("@datahorachegada", datahorachegada);
                comando.Parameters.AddWithValue("@portao", portao);
                comando.Parameters.AddWithValue("@terminal", terminal);
                comando.Parameters.AddWithValue("@status", status);

                conexao.Open();
                comando.ExecuteNonQuery();
            }
        }

        public void ExcluirVoos(int idvoo)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "DELETE FROM VOOS WHERE ID_VOO = @idvoo";

                SqlCommand comando = new SqlCommand( sql, conexao);
                comando.Parameters.AddWithValue("@idvoo", idvoo);
                conexao.Open();
                comando.ExecuteNonQuery();
            }
        }

        public DataTable ListarVoos()
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = "SELECT * FROM VOOS";

                SqlCommand comando = new SqlCommand(sql, conexao);
                SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                DataTable tabela = new DataTable();
                adaptador.Fill(tabela);
                return tabela;
            }
        }

        public DataTable Pesquisarvoo(string pesquisa, DateTime data)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"SELECT * FROM VOOS WHERE (TIPO_VOO LIKE @pesquisa OR ORIGEM LIKE @pesquisa OR DESTINO LIKE @pesquisa OR STATUS LIKE @pesquisa) AND CAST(DATA_HORA_PARTIDA AS DATE) = @data";

                SqlCommand comando = new SqlCommand(sql, conexao);
                comando.Parameters.AddWithValue("@pesquisa", "%" + pesquisa + "%");
                comando.Parameters.AddWithValue("@data", data.Date);
                SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                DataTable tabela = new DataTable();

                adaptador.Fill(tabela);

                return tabela;
            }
        }

        public DataTable PesquisarVoosAgendamento(string origem, string destino, DateTime data)
        {
            DataTable dados = new DataTable();

            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"SELECT * FROM VOOS WHERE ORIGEM = @origem AND DESTINO = @destino AND CAST(DATA_HORA_PARTIDA AS DATE) = @data";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@origem", origem);
                    comando.Parameters.AddWithValue("@destino", destino);
                    comando.Parameters.AddWithValue("@data", data.Date);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(comando))
                    {
                        adapter.Fill(dados);
                    }
                }
            }

            return dados;
        }

        public void AlterarStatusVoo(int idVoo, string status)
        {
            using (SqlConnection conexao = new SqlConnection(Conexao.StringConexao))
            {
                string sql = @"UPDATE VOOS SET STATUS = @status WHERE ID_VOO = @idVoo";

                using (SqlCommand comando = new SqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@status", status);
                    comando.Parameters.AddWithValue("@idVoo", idVoo);
                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
            }
        }
    }
}
