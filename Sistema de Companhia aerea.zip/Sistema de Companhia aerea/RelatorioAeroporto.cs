﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_de_compainha_aerea
{
    public partial class RelatorioAeroporto : Form
    {
        public RelatorioAeroporto()
        {
            InitializeComponent();
        }

        private void RelatorioAeroporto_Load(object sender, EventArgs e)
        {
           this.reportViewer1.RefreshReport();
        }
    }
}
