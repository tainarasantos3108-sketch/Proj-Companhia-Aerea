﻿namespace Sistema_de_compainha_aerea
{
    partial class ClassePassageiros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnPesquisarcadastroPassageiro = new System.Windows.Forms.Button();
            this.txtPassaportePesquisar = new System.Windows.Forms.TextBox();
            this.txtcpfPesquisarPassageiro = new System.Windows.Forms.TextBox();
            this.txtNomePesquisarPassageiro = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvPesquisarPassageiros = new System.Windows.Forms.DataGridView();
            this.btnCadastroPassageiro = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPesquisarPassageiros)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnPesquisarcadastroPassageiro);
            this.groupBox1.Controls.Add(this.txtPassaportePesquisar);
            this.groupBox1.Controls.Add(this.txtcpfPesquisarPassageiro);
            this.groupBox1.Controls.Add(this.txtNomePesquisarPassageiro);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(26, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1056, 111);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pesquisar passageiros";
            // 
            // btnPesquisarcadastroPassageiro
            // 
            this.btnPesquisarcadastroPassageiro.Location = new System.Drawing.Point(839, 31);
            this.btnPesquisarcadastroPassageiro.Name = "btnPesquisarcadastroPassageiro";
            this.btnPesquisarcadastroPassageiro.Size = new System.Drawing.Size(131, 54);
            this.btnPesquisarcadastroPassageiro.TabIndex = 6;
            this.btnPesquisarcadastroPassageiro.Text = "Pesquisar";
            this.btnPesquisarcadastroPassageiro.UseVisualStyleBackColor = true;
            this.btnPesquisarcadastroPassageiro.Click += new System.EventHandler(this.btnPesquisarcadastroPassageiro_Click);
            // 
            // txtPassaportePesquisar
            // 
            this.txtPassaportePesquisar.Location = new System.Drawing.Point(644, 62);
            this.txtPassaportePesquisar.Name = "txtPassaportePesquisar";
            this.txtPassaportePesquisar.Size = new System.Drawing.Size(165, 30);
            this.txtPassaportePesquisar.TabIndex = 5;
            // 
            // txtcpfPesquisarPassageiro
            // 
            this.txtcpfPesquisarPassageiro.Location = new System.Drawing.Point(427, 62);
            this.txtcpfPesquisarPassageiro.Name = "txtcpfPesquisarPassageiro";
            this.txtcpfPesquisarPassageiro.Size = new System.Drawing.Size(167, 30);
            this.txtcpfPesquisarPassageiro.TabIndex = 4;
            // 
            // txtNomePesquisarPassageiro
            // 
            this.txtNomePesquisarPassageiro.Location = new System.Drawing.Point(39, 62);
            this.txtNomePesquisarPassageiro.Name = "txtNomePesquisarPassageiro";
            this.txtNomePesquisarPassageiro.Size = new System.Drawing.Size(322, 30);
            this.txtNomePesquisarPassageiro.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(641, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Passaporte:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(424, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "CPF:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome:";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.dgvPesquisarPassageiros);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox2.Location = new System.Drawing.Point(26, 161);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1190, 394);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Passageiros encontrados";
            // 
            // dgvPesquisarPassageiros
            // 
            this.dgvPesquisarPassageiros.AllowUserToAddRows = false;
            this.dgvPesquisarPassageiros.AllowUserToDeleteRows = false;
            this.dgvPesquisarPassageiros.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPesquisarPassageiros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPesquisarPassageiros.Location = new System.Drawing.Point(22, 52);
            this.dgvPesquisarPassageiros.Name = "dgvPesquisarPassageiros";
            this.dgvPesquisarPassageiros.ReadOnly = true;
            this.dgvPesquisarPassageiros.RowHeadersVisible = false;
            this.dgvPesquisarPassageiros.RowHeadersWidth = 51;
            this.dgvPesquisarPassageiros.RowTemplate.Height = 24;
            this.dgvPesquisarPassageiros.Size = new System.Drawing.Size(1128, 320);
            this.dgvPesquisarPassageiros.TabIndex = 0;
            // 
            // btnCadastroPassageiro
            // 
            this.btnCadastroPassageiro.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastroPassageiro.Location = new System.Drawing.Point(26, 577);
            this.btnCadastroPassageiro.Name = "btnCadastroPassageiro";
            this.btnCadastroPassageiro.Size = new System.Drawing.Size(120, 59);
            this.btnCadastroPassageiro.TabIndex = 2;
            this.btnCadastroPassageiro.Text = "Cadastro Passageiros";
            this.btnCadastroPassageiro.UseVisualStyleBackColor = true;
            this.btnCadastroPassageiro.Click += new System.EventHandler(this.btnCadastroPassageiro_Click);
            // 
            // ClassePassageiros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1367, 682);
            this.Controls.Add(this.btnCadastroPassageiro);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Name = "ClassePassageiros";
            this.Text = "Pesquisar Passageiros";
            this.Load += new System.EventHandler(this.ClassePassageiros_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPesquisarPassageiros)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnPesquisarcadastroPassageiro;
        private System.Windows.Forms.TextBox txtPassaportePesquisar;
        private System.Windows.Forms.TextBox txtcpfPesquisarPassageiro;
        private System.Windows.Forms.TextBox txtNomePesquisarPassageiro;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvPesquisarPassageiros;
        private System.Windows.Forms.Button btnCadastroPassageiro;
    }
}