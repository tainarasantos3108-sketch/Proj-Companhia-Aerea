﻿namespace Sistema_de_compainha_aerea
{
    partial class GerenciamentoFuncionarioeSetores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GerenciamentoFuncionarioeSetores));
            this.tbcSetoresFuncionarios = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnExcluirSetor = new System.Windows.Forms.Button();
            this.btnSalvarSetor = new System.Windows.Forms.Button();
            this.btnCadastrarSetor = new System.Windows.Forms.Button();
            this.txtNomeSetor = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtPesquisarSetor = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnPesquisarSetor = new System.Windows.Forms.Button();
            this.dgvSetores = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgvFuncionarios = new System.Windows.Forms.DataGridView();
            this.btnPesquisarFuncionario = new System.Windows.Forms.Button();
            this.txtPesquisarFuncionario = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnRemoverFotoFuncionario = new System.Windows.Forms.Button();
            this.btnSelecionaFotoFuncionario = new System.Windows.Forms.Button();
            this.pbFuncionario = new System.Windows.Forms.PictureBox();
            this.btnLimparFuncionario = new System.Windows.Forms.Button();
            this.btnExcluirFuncionario = new System.Windows.Forms.Button();
            this.btnSalvarFuncionario = new System.Windows.Forms.Button();
            this.btnCadastrarFuncionario = new System.Windows.Forms.Button();
            this.dtpAdmissao = new System.Windows.Forms.DateTimePicker();
            this.cmbSetorFuncionario = new System.Windows.Forms.ComboBox();
            this.txtEmailFuncionario = new System.Windows.Forms.TextBox();
            this.mtbCaontatoFuncionario = new System.Windows.Forms.MaskedTextBox();
            this.mtbCpfFuncionario = new System.Windows.Forms.MaskedTextBox();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.txtNomeFuncionario = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnEditar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbcSetoresFuncionarios.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSetores)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFuncionarios)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFuncionario)).BeginInit();
            this.SuspendLayout();
            // 
            // tbcSetoresFuncionarios
            // 
            this.tbcSetoresFuncionarios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbcSetoresFuncionarios.Controls.Add(this.tabPage1);
            this.tbcSetoresFuncionarios.Controls.Add(this.tabPage2);
            this.tbcSetoresFuncionarios.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcSetoresFuncionarios.Location = new System.Drawing.Point(0, 0);
            this.tbcSetoresFuncionarios.Name = "tbcSetoresFuncionarios";
            this.tbcSetoresFuncionarios.SelectedIndex = 0;
            this.tbcSetoresFuncionarios.Size = new System.Drawing.Size(1282, 776);
            this.tbcSetoresFuncionarios.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 32);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1274, 740);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Setores";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCodigo);
            this.groupBox1.Controls.Add(this.btnLimpar);
            this.groupBox1.Controls.Add(this.btnExcluirSetor);
            this.groupBox1.Controls.Add(this.btnSalvarSetor);
            this.groupBox1.Controls.Add(this.btnCadastrarSetor);
            this.groupBox1.Controls.Add(this.txtNomeSetor);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(8, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(655, 597);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastro de Setores";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Enabled = false;
            this.txtCodigo.Location = new System.Drawing.Point(176, 76);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(100, 30);
            this.txtCodigo.TabIndex = 7;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(314, 201);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(99, 50);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnExcluirSetor
            // 
            this.btnExcluirSetor.Location = new System.Drawing.Point(221, 201);
            this.btnExcluirSetor.Name = "btnExcluirSetor";
            this.btnExcluirSetor.Size = new System.Drawing.Size(87, 50);
            this.btnExcluirSetor.TabIndex = 5;
            this.btnExcluirSetor.Text = "Excluir";
            this.btnExcluirSetor.UseVisualStyleBackColor = true;
            this.btnExcluirSetor.Click += new System.EventHandler(this.btnExcluirSetor_Click);
            // 
            // btnSalvarSetor
            // 
            this.btnSalvarSetor.Location = new System.Drawing.Point(122, 201);
            this.btnSalvarSetor.Name = "btnSalvarSetor";
            this.btnSalvarSetor.Size = new System.Drawing.Size(91, 50);
            this.btnSalvarSetor.TabIndex = 3;
            this.btnSalvarSetor.Text = "Salvar";
            this.btnSalvarSetor.UseVisualStyleBackColor = true;
            this.btnSalvarSetor.Click += new System.EventHandler(this.btnSalvarSetor_Click);
            // 
            // btnCadastrarSetor
            // 
            this.btnCadastrarSetor.Location = new System.Drawing.Point(26, 201);
            this.btnCadastrarSetor.Name = "btnCadastrarSetor";
            this.btnCadastrarSetor.Size = new System.Drawing.Size(90, 50);
            this.btnCadastrarSetor.TabIndex = 2;
            this.btnCadastrarSetor.Text = "Novo";
            this.btnCadastrarSetor.UseVisualStyleBackColor = true;
            this.btnCadastrarSetor.Click += new System.EventHandler(this.btnCadastrarSetor_Click);
            // 
            // txtNomeSetor
            // 
            this.txtNomeSetor.Location = new System.Drawing.Point(176, 112);
            this.txtNomeSetor.Name = "txtNomeSetor";
            this.txtNomeSetor.Size = new System.Drawing.Size(447, 30);
            this.txtNomeSetor.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome do Setor:";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.txtPesquisarSetor);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.btnPesquisarSetor);
            this.groupBox2.Controls.Add(this.dgvSetores);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox2.Location = new System.Drawing.Point(691, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(545, 609);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Listar de Setores";
            // 
            // txtPesquisarSetor
            // 
            this.txtPesquisarSetor.Location = new System.Drawing.Point(78, 59);
            this.txtPesquisarSetor.Name = "txtPesquisarSetor";
            this.txtPesquisarSetor.Size = new System.Drawing.Size(327, 30);
            this.txtPesquisarSetor.TabIndex = 11;
            this.txtPesquisarSetor.TextChanged += new System.EventHandler(this.txtPesquisarSetor_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 23);
            this.label4.TabIndex = 10;
            this.label4.Text = "Setor:";
            // 
            // btnPesquisarSetor
            // 
            this.btnPesquisarSetor.Location = new System.Drawing.Point(411, 52);
            this.btnPesquisarSetor.Name = "btnPesquisarSetor";
            this.btnPesquisarSetor.Size = new System.Drawing.Size(117, 37);
            this.btnPesquisarSetor.TabIndex = 8;
            this.btnPesquisarSetor.Text = "Pesquisar";
            this.btnPesquisarSetor.UseVisualStyleBackColor = true;
            this.btnPesquisarSetor.Click += new System.EventHandler(this.btnPesquisarSetor_Click);
            // 
            // dgvSetores
            // 
            this.dgvSetores.AllowUserToAddRows = false;
            this.dgvSetores.AllowUserToDeleteRows = false;
            this.dgvSetores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSetores.Location = new System.Drawing.Point(10, 124);
            this.dgvSetores.Name = "dgvSetores";
            this.dgvSetores.ReadOnly = true;
            this.dgvSetores.RowHeadersVisible = false;
            this.dgvSetores.RowHeadersWidth = 51;
            this.dgvSetores.RowTemplate.Height = 24;
            this.dgvSetores.Size = new System.Drawing.Size(522, 479);
            this.dgvSetores.TabIndex = 9;
            this.dgvSetores.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSetores_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 32);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1274, 740);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Funcionários";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.dgvFuncionarios);
            this.groupBox4.Controls.Add(this.btnPesquisarFuncionario);
            this.groupBox4.Controls.Add(this.txtPesquisarFuncionario);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox4.Location = new System.Drawing.Point(617, 21);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(651, 696);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Listar de Funcionários";
            // 
            // dgvFuncionarios
            // 
            this.dgvFuncionarios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvFuncionarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFuncionarios.Location = new System.Drawing.Point(26, 161);
            this.dgvFuncionarios.Name = "dgvFuncionarios";
            this.dgvFuncionarios.ReadOnly = true;
            this.dgvFuncionarios.RowHeadersVisible = false;
            this.dgvFuncionarios.RowHeadersWidth = 51;
            this.dgvFuncionarios.RowTemplate.Height = 24;
            this.dgvFuncionarios.Size = new System.Drawing.Size(609, 439);
            this.dgvFuncionarios.TabIndex = 3;
            this.dgvFuncionarios.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFuncionarios_CellContentClick);
            // 
            // btnPesquisarFuncionario
            // 
            this.btnPesquisarFuncionario.Location = new System.Drawing.Point(489, 86);
            this.btnPesquisarFuncionario.Name = "btnPesquisarFuncionario";
            this.btnPesquisarFuncionario.Size = new System.Drawing.Size(103, 38);
            this.btnPesquisarFuncionario.TabIndex = 2;
            this.btnPesquisarFuncionario.Text = "Pesquisar";
            this.btnPesquisarFuncionario.UseVisualStyleBackColor = true;
            this.btnPesquisarFuncionario.Click += new System.EventHandler(this.btnPesquisarFuncionario_Click);
            // 
            // txtPesquisarFuncionario
            // 
            this.txtPesquisarFuncionario.Location = new System.Drawing.Point(142, 40);
            this.txtPesquisarFuncionario.Name = "txtPesquisarFuncionario";
            this.txtPesquisarFuncionario.Size = new System.Drawing.Size(450, 30);
            this.txtPesquisarFuncionario.TabIndex = 1;
            this.txtPesquisarFuncionario.TextChanged += new System.EventHandler(this.txtPesquisarFuncionario_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 23);
            this.label11.TabIndex = 0;
            this.label11.Text = "Funcionário:";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.txtSalario);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.btnRemoverFotoFuncionario);
            this.groupBox3.Controls.Add(this.btnSelecionaFotoFuncionario);
            this.groupBox3.Controls.Add(this.pbFuncionario);
            this.groupBox3.Controls.Add(this.btnLimparFuncionario);
            this.groupBox3.Controls.Add(this.btnExcluirFuncionario);
            this.groupBox3.Controls.Add(this.btnSalvarFuncionario);
            this.groupBox3.Controls.Add(this.btnCadastrarFuncionario);
            this.groupBox3.Controls.Add(this.dtpAdmissao);
            this.groupBox3.Controls.Add(this.cmbSetorFuncionario);
            this.groupBox3.Controls.Add(this.txtEmailFuncionario);
            this.groupBox3.Controls.Add(this.mtbCaontatoFuncionario);
            this.groupBox3.Controls.Add(this.mtbCpfFuncionario);
            this.groupBox3.Controls.Add(this.txtCargo);
            this.groupBox3.Controls.Add(this.txtNomeFuncionario);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox3.Location = new System.Drawing.Point(0, 21);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(611, 696);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Cadastro Funcionários";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Bisque;
            this.label20.Location = new System.Drawing.Point(404, 661);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(193, 23);
            this.label20.TabIndex = 33;
            this.label20.Text = "(*) Campos obrigatórios";
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(125, 464);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(149, 30);
            this.txtSalario.TabIndex = 32;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(13, 464);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(17, 23);
            this.label19.TabIndex = 31;
            this.label19.Text = "*";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(13, 507);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(17, 23);
            this.label18.TabIndex = 30;
            this.label18.Text = "*";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(13, 423);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(17, 23);
            this.label17.TabIndex = 29;
            this.label17.Text = "*";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(13, 382);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(17, 23);
            this.label16.TabIndex = 28;
            this.label16.Text = "*";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(13, 334);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(17, 23);
            this.label15.TabIndex = 27;
            this.label15.Text = "*";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(13, 285);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 23);
            this.label14.TabIndex = 26;
            this.label14.Text = "*";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(13, 243);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 23);
            this.label13.TabIndex = 25;
            this.label13.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(311, 285);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 23);
            this.label12.TabIndex = 24;
            this.label12.Text = "*";
            // 
            // btnRemoverFotoFuncionario
            // 
            this.btnRemoverFotoFuncionario.Location = new System.Drawing.Point(178, 76);
            this.btnRemoverFotoFuncionario.Name = "btnRemoverFotoFuncionario";
            this.btnRemoverFotoFuncionario.Size = new System.Drawing.Size(106, 37);
            this.btnRemoverFotoFuncionario.TabIndex = 23;
            this.btnRemoverFotoFuncionario.Text = "Remover";
            this.btnRemoverFotoFuncionario.UseVisualStyleBackColor = true;
            this.btnRemoverFotoFuncionario.Click += new System.EventHandler(this.btnRemoverFotoFuncionario_Click);
            // 
            // btnSelecionaFotoFuncionario
            // 
            this.btnSelecionaFotoFuncionario.Location = new System.Drawing.Point(178, 29);
            this.btnSelecionaFotoFuncionario.Name = "btnSelecionaFotoFuncionario";
            this.btnSelecionaFotoFuncionario.Size = new System.Drawing.Size(108, 41);
            this.btnSelecionaFotoFuncionario.TabIndex = 22;
            this.btnSelecionaFotoFuncionario.Text = "Selecionar";
            this.btnSelecionaFotoFuncionario.UseVisualStyleBackColor = true;
            this.btnSelecionaFotoFuncionario.Click += new System.EventHandler(this.btnSelecionaFotoFuncionario_Click);
            // 
            // pbFuncionario
            // 
            this.pbFuncionario.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pbFuncionario.Location = new System.Drawing.Point(17, 29);
            this.pbFuncionario.Name = "pbFuncionario";
            this.pbFuncionario.Size = new System.Drawing.Size(155, 192);
            this.pbFuncionario.TabIndex = 21;
            this.pbFuncionario.TabStop = false;
            // 
            // btnLimparFuncionario
            // 
            this.btnLimparFuncionario.Location = new System.Drawing.Point(330, 602);
            this.btnLimparFuncionario.Name = "btnLimparFuncionario";
            this.btnLimparFuncionario.Size = new System.Drawing.Size(89, 37);
            this.btnLimparFuncionario.TabIndex = 20;
            this.btnLimparFuncionario.Text = "Limpar";
            this.btnLimparFuncionario.UseVisualStyleBackColor = true;
            this.btnLimparFuncionario.Click += new System.EventHandler(this.btnLimparFuncionario_Click);
            // 
            // btnExcluirFuncionario
            // 
            this.btnExcluirFuncionario.Location = new System.Drawing.Point(216, 602);
            this.btnExcluirFuncionario.Name = "btnExcluirFuncionario";
            this.btnExcluirFuncionario.Size = new System.Drawing.Size(108, 39);
            this.btnExcluirFuncionario.TabIndex = 19;
            this.btnExcluirFuncionario.Text = "Excluir";
            this.btnExcluirFuncionario.UseVisualStyleBackColor = true;
            this.btnExcluirFuncionario.Click += new System.EventHandler(this.btnExcluirFuncionario_Click);
            // 
            // btnSalvarFuncionario
            // 
            this.btnSalvarFuncionario.Location = new System.Drawing.Point(125, 600);
            this.btnSalvarFuncionario.Name = "btnSalvarFuncionario";
            this.btnSalvarFuncionario.Size = new System.Drawing.Size(89, 39);
            this.btnSalvarFuncionario.TabIndex = 17;
            this.btnSalvarFuncionario.Text = "Salvar";
            this.btnSalvarFuncionario.UseVisualStyleBackColor = true;
            this.btnSalvarFuncionario.Click += new System.EventHandler(this.btnSalvarFuncionario_Click);
            // 
            // btnCadastrarFuncionario
            // 
            this.btnCadastrarFuncionario.Location = new System.Drawing.Point(11, 600);
            this.btnCadastrarFuncionario.Name = "btnCadastrarFuncionario";
            this.btnCadastrarFuncionario.Size = new System.Drawing.Size(108, 37);
            this.btnCadastrarFuncionario.TabIndex = 16;
            this.btnCadastrarFuncionario.Text = "Cadastrar";
            this.btnCadastrarFuncionario.UseVisualStyleBackColor = true;
            this.btnCadastrarFuncionario.Click += new System.EventHandler(this.btnCadastrarFuncionario_Click);
            // 
            // dtpAdmissao
            // 
            this.dtpAdmissao.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpAdmissao.Location = new System.Drawing.Point(125, 507);
            this.dtpAdmissao.Name = "dtpAdmissao";
            this.dtpAdmissao.Size = new System.Drawing.Size(149, 30);
            this.dtpAdmissao.TabIndex = 15;
            // 
            // cmbSetorFuncionario
            // 
            this.cmbSetorFuncionario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSetorFuncionario.FormattingEnabled = true;
            this.cmbSetorFuncionario.Location = new System.Drawing.Point(125, 423);
            this.cmbSetorFuncionario.Name = "cmbSetorFuncionario";
            this.cmbSetorFuncionario.Size = new System.Drawing.Size(312, 31);
            this.cmbSetorFuncionario.TabIndex = 13;
            // 
            // txtEmailFuncionario
            // 
            this.txtEmailFuncionario.Location = new System.Drawing.Point(125, 331);
            this.txtEmailFuncionario.Name = "txtEmailFuncionario";
            this.txtEmailFuncionario.Size = new System.Drawing.Size(312, 30);
            this.txtEmailFuncionario.TabIndex = 12;
            // 
            // mtbCaontatoFuncionario
            // 
            this.mtbCaontatoFuncionario.Location = new System.Drawing.Point(408, 279);
            this.mtbCaontatoFuncionario.Mask = "(99) 9 0000-0000";
            this.mtbCaontatoFuncionario.Name = "mtbCaontatoFuncionario";
            this.mtbCaontatoFuncionario.Size = new System.Drawing.Size(187, 30);
            this.mtbCaontatoFuncionario.TabIndex = 11;
            // 
            // mtbCpfFuncionario
            // 
            this.mtbCpfFuncionario.Location = new System.Drawing.Point(125, 282);
            this.mtbCpfFuncionario.Mask = "000-000-000-00";
            this.mtbCpfFuncionario.Name = "mtbCpfFuncionario";
            this.mtbCpfFuncionario.Size = new System.Drawing.Size(180, 30);
            this.mtbCpfFuncionario.TabIndex = 10;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(125, 375);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(312, 30);
            this.txtCargo.TabIndex = 9;
            // 
            // txtNomeFuncionario
            // 
            this.txtNomeFuncionario.Location = new System.Drawing.Point(125, 236);
            this.txtNomeFuncionario.Name = "txtNomeFuncionario";
            this.txtNomeFuncionario.Size = new System.Drawing.Size(470, 30);
            this.txtNomeFuncionario.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(29, 464);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 23);
            this.label10.TabIndex = 7;
            this.label10.Text = "Salário:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(32, 507);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 23);
            this.label9.TabIndex = 6;
            this.label9.Text = "Admissão:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 423);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 23);
            this.label8.TabIndex = 5;
            this.label8.Text = "Setor:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(32, 382);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 23);
            this.label7.TabIndex = 4;
            this.label7.Text = "Cargo:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 334);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 23);
            this.label6.TabIndex = 3;
            this.label6.Text = "E-mail:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(326, 285);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 23);
            this.label5.TabIndex = 2;
            this.label5.Text = "Contato:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 282);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 23);
            this.label3.TabIndex = 1;
            this.label3.Text = "CPF:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 243);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nome:";
            // 
            // btnEditar
            // 
            this.btnEditar.HeaderText = "Editar";
            this.btnEditar.MinimumWidth = 6;
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Width = 125;
            // 
            // GerenciamentoFuncionarioeSetores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1294, 788);
            this.Controls.Add(this.tbcSetoresFuncionarios);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GerenciamentoFuncionarioeSetores";
            this.Text = "Setores e Funcionarios";
            this.Load += new System.EventHandler(this.GerenciamentoFuncionarioeSetores_Load);
            this.tbcSetoresFuncionarios.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSetores)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFuncionarios)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFuncionario)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcSetoresFuncionarios;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPesquisarSetor;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnExcluirSetor;
        private System.Windows.Forms.Button btnSalvarSetor;
        private System.Windows.Forms.Button btnCadastrarSetor;
        private System.Windows.Forms.TextBox txtNomeSetor;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvSetores;
        private System.Windows.Forms.TextBox txtPesquisarSetor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNomeFuncionario;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpAdmissao;
        private System.Windows.Forms.ComboBox cmbSetorFuncionario;
        private System.Windows.Forms.TextBox txtEmailFuncionario;
        private System.Windows.Forms.MaskedTextBox mtbCaontatoFuncionario;
        private System.Windows.Forms.MaskedTextBox mtbCpfFuncionario;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.Button btnLimparFuncionario;
        private System.Windows.Forms.Button btnExcluirFuncionario;
        private System.Windows.Forms.Button btnSalvarFuncionario;
        private System.Windows.Forms.Button btnCadastrarFuncionario;
        private System.Windows.Forms.Button btnPesquisarFuncionario;
        private System.Windows.Forms.TextBox txtPesquisarFuncionario;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dgvFuncionarios;
        private System.Windows.Forms.PictureBox pbFuncionario;
        private System.Windows.Forms.Button btnRemoverFotoFuncionario;
        private System.Windows.Forms.Button btnSelecionaFotoFuncionario;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.DataGridViewTextBoxColumn btnEditar;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.Label label20;
    }
}