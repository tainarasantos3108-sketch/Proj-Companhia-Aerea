﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_de_compainha_aerea
{
    public partial class Pagamentos : Form
    {
        int idPassageiroSelecionado = 0;
        int idVooSelecionado = 0;

        int idPagamentoSelecionado = 0;
        public Pagamentos()
        {
            InitializeComponent();
            CarregarAgendados();
            CarregarPagamentos();
        }

        private void CarregarAgendados()
        {
            Pagamento pagamento = new Pagamento();
            DataTable dados = pagamento.ListarAgendados();
            dgvListaAgendados.DataSource = dados;
            
        }

        private void dgvPagamento_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtValor.Clear();
                cmbStatusPagamento.SelectedIndex = -1;
                cmbFormaPagamento.SelectedIndex = -1;
                dtpPagamento.Value = DateTime.Now;

                idPassageiroSelecionado = Convert.ToInt32(dgvListaAgendados.Rows[e.RowIndex].Cells["ID_PASSAGEIRO"].Value);
                txtPassageiro.Text = dgvListaAgendados.Rows[e.RowIndex].Cells["NOME_PASSAGEIRO"].Value.ToString();
            }
        }

        private void btnSalvarPagamento_Click(object sender, EventArgs e)
        {
            if (idPassageiroSelecionado == 0)
            {
                MessageBox.Show("Selecione um passageiro.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtValor.Text))
            {
                MessageBox.Show("Digite o valor da passagem.");
                return;
            }

            if (string.IsNullOrWhiteSpace(cmbFormaPagamento.Text))
            {
                MessageBox.Show("Selecione a forma de pagamento.");
                return;
            }

            if (string.IsNullOrWhiteSpace(cmbStatusPagamento.Text))
            {
                MessageBox.Show("Selecione o status do pagamento.");
                return;
            }

            decimal valor = Convert.ToDecimal(txtValor.Text);

            Pagamento pagamento = new Pagamento();
            DataTable dados = pagamento.BuscarClasseEMilhas(idPassageiroSelecionado);

            if (dados.Rows.Count > 0)
            {
                string classe = dados.Rows[0]["CLASSE"].ToString().Trim();
                int milhas = Convert.ToInt32(dados.Rows[0]["MILHAS"]);

                if (classe.Equals("VIP", StringComparison.OrdinalIgnoreCase))
                {
                    if (milhas >= 4500)
                    {
                        valor = valor * 0.85m;

                        txtValor.Text = valor.ToString("N2");

                        MessageBox.Show("Desconto de 15% aplicado para este passageiro VIP.", "Desconto aplicado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Desconto não aplicado. O passageiro VIP não tem milha suficientes e precisa ter 4.500 milhas ou mais.", "Desconto não aplicado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            int idVoo = pagamento.BuscarVooDoPassageiro(idPassageiroSelecionado);
            pagamento.SalvarPagamento(idPassageiroSelecionado, idVoo, valor, dtpPagamento.Value, cmbFormaPagamento.Text, cmbStatusPagamento.Text);
            CarregarPagamentos();
            txtPassageiro.Clear();
            txtValor.Clear();
            cmbFormaPagamento.SelectedIndex = -1;
            cmbStatusPagamento.SelectedIndex = -1;
            dtpPagamento.Value = DateTime.Now;
            idPassageiroSelecionado = 0;
            idVooSelecionado = 0;
            MessageBox.Show("Pagamento salvo com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void CarregarPagamentos()
        {
            Pagamento pagamento = new Pagamento();
            DataTable dadospagamento = pagamento.ListarPagamentos();
            dgvListaPagamentoConfirmado.DataSource = dadospagamento;

            if (!dgvListaPagamentoConfirmado.Columns.Contains("Salvar"))
            {
                DataGridViewButtonColumn btnSalvarPagamentos = new DataGridViewButtonColumn();

                btnSalvarPagamentos.Name = "Salvar";
                btnSalvarPagamentos.HeaderText = "Ação";
                btnSalvarPagamentos.Text = "Salvar";
                btnSalvarPagamentos.UseColumnTextForButtonValue = true;
                dgvListaPagamentoConfirmado.Columns.Add(btnSalvarPagamentos);
            }

            if (!dgvListaPagamentoConfirmado.Columns.Contains("Editar"))
            {
                DataGridViewButtonColumn btnEditarPagamento = new DataGridViewButtonColumn();

                btnEditarPagamento.Name = "Editar";
                btnEditarPagamento.HeaderText = "Ação";
                btnEditarPagamento.Text = "Editar";
                btnEditarPagamento.UseColumnTextForButtonValue = true;
                dgvListaPagamentoConfirmado.Columns.Add(btnEditarPagamento);
            }

            dgvListaPagamentoConfirmado.Columns["ID_PAGAMENTO"].Visible = false;
            dgvListaPagamentoConfirmado.Columns["NOME_PASSAGEIRO"].HeaderText = "Passageiro";
            dgvListaPagamentoConfirmado.Columns["NOME_PASSAGEIRO"].Width = 200;
            dgvListaPagamentoConfirmado.Columns["VALOR"].HeaderText = "Valor";
            dgvListaPagamentoConfirmado.Columns["VALOR"].Width = 120;
            dgvListaPagamentoConfirmado.Columns["STATUS_PAGAMENTO"].HeaderText = "Pagamento";
            dgvListaPagamentoConfirmado.Columns["STATUS_PAGAMENTO"].Width = 120;
            dgvListaPagamentoConfirmado.Columns["DATA_PAGAMENTO"].HeaderText = "Data";
            dgvListaPagamentoConfirmado.Columns["DATA_PAGAMENTO"].Width = 100;
        }

        private void dgvListaPagamentoConfirmado_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            // BOTÃO EDITAR
            if (e.ColumnIndex == dgvListaPagamentoConfirmado.Columns["Editar"].Index)
            {
                idPagamentoSelecionado = Convert.ToInt32(dgvListaPagamentoConfirmado.Rows[e.RowIndex].Cells["ID_PAGAMENTO"].Value);
                Pagamento pagamento = new Pagamento();
                DataTable dados = pagamento.BuscarDadosPagamento(idPagamentoSelecionado);

                if (dados.Rows.Count > 0)
                {
                    idPassageiroSelecionado = Convert.ToInt32(dados.Rows[0]["ID_PASSAGEIRO"]);

                    idVooSelecionado = Convert.ToInt32(dados.Rows[0]["ID_VOO"]);

                    txtPassageiro.Text = dados.Rows[0]["NOME_PASSAGEIRO"].ToString();

                    txtValor.Text = Convert.ToDecimal(dados.Rows[0]["VALOR"]).ToString("N2");

                    cmbStatusPagamento.Text = dados.Rows[0]["STATUS_PAGAMENTO"].ToString();

                    dtpPagamento.Value = Convert.ToDateTime(dados.Rows[0]["DATA_PAGAMENTO"]);

                    cmbFormaPagamento.Text = dados.Rows[0]["FORMA_PAGAMENTO"].ToString();
                }
                else
                {
                    MessageBox.Show("Não foi possível localizar o pagamento.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }


            // BOTÃO SALVAR DA LISTA DE PAGAMENTOS
            if (e.ColumnIndex == dgvListaPagamentoConfirmado.Columns["Salvar"].Index)
            {
                if (idPagamentoSelecionado == 0)
                {
                    MessageBox.Show("Clique em Editar primeiro.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtPassageiro.Text))
                {
                    MessageBox.Show("Selecione um passageiro.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtValor.Text))
                {
                    MessageBox.Show("Digite o valor do pagamento.");
                    txtValor.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(cmbFormaPagamento.Text))
                {
                    MessageBox.Show("Selecione a forma de pagamento.");
                    cmbFormaPagamento.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(cmbStatusPagamento.Text))
                {
                    MessageBox.Show("Selecione o status do pagamento.");
                    cmbStatusPagamento.Focus();
                    return;
                }

                decimal valor;

                if (!decimal.TryParse(txtValor.Text, out valor))
                {
                    MessageBox.Show("Digite um valor válido.");
                    txtValor.Focus();
                    return;
                }

                Pagamento pagamento = new Pagamento();
                pagamento.AlterarPagamento(idPagamentoSelecionado, idPassageiroSelecionado, idVooSelecionado, valor, dtpPagamento.Value, cmbFormaPagamento.Text, cmbStatusPagamento.Text);
                CarregarPagamentos();
                idPagamentoSelecionado = 0;
                idPassageiroSelecionado = 0;
                idVooSelecionado = 0;
                txtPassageiro.Clear();
                txtValor.Clear();
                cmbFormaPagamento.SelectedIndex = -1;
                cmbStatusPagamento.SelectedIndex = -1;
                dtpPagamento.Value = DateTime.Now;
                MessageBox.Show("Pagamento alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvListaPagamentoConfirmado.CurrentRow == null)
                {
                    MessageBox.Show("Selecione o pagamento que deseja excluir.");
                    return;
                }

                int idPagamento = Convert.ToInt32(
                    dgvListaPagamentoConfirmado.CurrentRow.Cells["ID_PAGAMENTO"].Value
                );

                Pagamento pagamento = new Pagamento();
                pagamento.ExcluirPagamento(idPagamento);
                CarregarPagamentos();
                MessageBox.Show("Pagamento excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir o pagamento:\n\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

}
