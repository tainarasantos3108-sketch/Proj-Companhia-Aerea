﻿namespace Sistema_de_compainha_aerea
{
    partial class RelatorioAeroporto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource5 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.sistemadeAeroportoDataSet3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sistemadeAeroportoDataSet3 = new Sistema_de_compainha_aerea.SistemadeAeroportoDataSet3();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            ((System.ComponentModel.ISupportInitialize)(this.sistemadeAeroportoDataSet3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemadeAeroportoDataSet3)).BeginInit();
            this.SuspendLayout();
            // 
            // sistemadeAeroportoDataSet3BindingSource
            // 
            this.sistemadeAeroportoDataSet3BindingSource.DataSource = this.sistemadeAeroportoDataSet3;
            this.sistemadeAeroportoDataSet3BindingSource.Position = 0;
            // 
            // sistemadeAeroportoDataSet3
            // 
            this.sistemadeAeroportoDataSet3.DataSetName = "SistemadeAeroportoDataSet3";
            this.sistemadeAeroportoDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource5.Name = "DataSetPagamento";
            reportDataSource5.Value = this.sistemadeAeroportoDataSet3BindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource5);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Sistema_de_compainha_aerea.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ServerReport.BearerToken = null;
            this.reportViewer1.Size = new System.Drawing.Size(1295, 751);
            this.reportViewer1.TabIndex = 0;
            // 
            // RelatorioAeroporto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1295, 751);
            this.Controls.Add(this.reportViewer1);
            this.Name = "RelatorioAeroporto";
            this.Text = "Relatário";
            this.Load += new System.EventHandler(this.RelatorioAeroporto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sistemadeAeroportoDataSet3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemadeAeroportoDataSet3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource sistemadeAeroportoDataSet3BindingSource;
        private SistemadeAeroportoDataSet3 sistemadeAeroportoDataSet3;
    }
}