﻿namespace Sistema_de_compainha_aerea
{
    partial class Pagamentos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpPagamento = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbFormaPagamento = new System.Windows.Forms.ComboBox();
            this.cmbStatusPagamento = new System.Windows.Forms.ComboBox();
            this.btnSalvarPagamentos = new System.Windows.Forms.Button();
            this.dgvListaAgendados = new System.Windows.Forms.DataGridView();
            this.txtPassageiro = new System.Windows.Forms.TextBox();
            this.dgvListaPagamentoConfirmado = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaAgendados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaPagamentoConfirmado)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(64, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "💳 Pagamentos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(66, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Passageiro";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label3.Location = new System.Drawing.Point(372, 286);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(164, 23);
            this.label3.TabIndex = 3;
            this.label3.Text = "Data do Pagamento";
            // 
            // dtpPagamento
            // 
            this.dtpPagamento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPagamento.Location = new System.Drawing.Point(376, 317);
            this.dtpPagamento.Name = "dtpPagamento";
            this.dtpPagamento.Size = new System.Drawing.Size(200, 30);
            this.dtpPagamento.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(372, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 23);
            this.label5.TabIndex = 7;
            this.label5.Text = "Valor";
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(376, 208);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(244, 30);
            this.txtValor.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Location = new System.Drawing.Point(69, 286);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(176, 23);
            this.label6.TabIndex = 9;
            this.label6.Text = "Forma de pagamento";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label7.Location = new System.Drawing.Point(645, 178);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(175, 23);
            this.label7.TabIndex = 10;
            this.label7.Text = "Status do pagamento";
            // 
            // cmbFormaPagamento
            // 
            this.cmbFormaPagamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFormaPagamento.FormattingEnabled = true;
            this.cmbFormaPagamento.Items.AddRange(new object[] {
            "",
            "Dinheiro",
            "Pix",
            "Cartão/Deb.",
            "Cartão/Cred."});
            this.cmbFormaPagamento.Location = new System.Drawing.Point(70, 316);
            this.cmbFormaPagamento.Name = "cmbFormaPagamento";
            this.cmbFormaPagamento.Size = new System.Drawing.Size(287, 31);
            this.cmbFormaPagamento.TabIndex = 11;
            // 
            // cmbStatusPagamento
            // 
            this.cmbStatusPagamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatusPagamento.FormattingEnabled = true;
            this.cmbStatusPagamento.Items.AddRange(new object[] {
            "",
            "Pendente",
            "Confirmado",
            "Cancelado"});
            this.cmbStatusPagamento.Location = new System.Drawing.Point(649, 207);
            this.cmbStatusPagamento.Name = "cmbStatusPagamento";
            this.cmbStatusPagamento.Size = new System.Drawing.Size(244, 31);
            this.cmbStatusPagamento.TabIndex = 12;
            // 
            // btnSalvarPagamentos
            // 
            this.btnSalvarPagamentos.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnSalvarPagamentos.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnSalvarPagamentos.Location = new System.Drawing.Point(679, 442);
            this.btnSalvarPagamentos.Name = "btnSalvarPagamentos";
            this.btnSalvarPagamentos.Size = new System.Drawing.Size(96, 41);
            this.btnSalvarPagamentos.TabIndex = 13;
            this.btnSalvarPagamentos.Text = "Salvar";
            this.btnSalvarPagamentos.UseVisualStyleBackColor = false;
            this.btnSalvarPagamentos.Click += new System.EventHandler(this.btnSalvarPagamento_Click);
            // 
            // dgvListaAgendados
            // 
            this.dgvListaAgendados.AllowUserToAddRows = false;
            this.dgvListaAgendados.AllowUserToDeleteRows = false;
            this.dgvListaAgendados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaAgendados.Location = new System.Drawing.Point(32, 501);
            this.dgvListaAgendados.Name = "dgvListaAgendados";
            this.dgvListaAgendados.ReadOnly = true;
            this.dgvListaAgendados.RowHeadersVisible = false;
            this.dgvListaAgendados.RowHeadersWidth = 51;
            this.dgvListaAgendados.RowTemplate.Height = 24;
            this.dgvListaAgendados.Size = new System.Drawing.Size(861, 193);
            this.dgvListaAgendados.TabIndex = 15;
            this.dgvListaAgendados.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPagamento_CellClick);
            // 
            // txtPassageiro
            // 
            this.txtPassageiro.Location = new System.Drawing.Point(70, 208);
            this.txtPassageiro.Name = "txtPassageiro";
            this.txtPassageiro.Size = new System.Drawing.Size(278, 30);
            this.txtPassageiro.TabIndex = 16;
            // 
            // dgvListaPagamentoConfirmado
            // 
            this.dgvListaPagamentoConfirmado.AllowUserToAddRows = false;
            this.dgvListaPagamentoConfirmado.AllowUserToDeleteRows = false;
            this.dgvListaPagamentoConfirmado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaPagamentoConfirmado.Location = new System.Drawing.Point(24, 47);
            this.dgvListaPagamentoConfirmado.Name = "dgvListaPagamentoConfirmado";
            this.dgvListaPagamentoConfirmado.ReadOnly = true;
            this.dgvListaPagamentoConfirmado.RowHeadersVisible = false;
            this.dgvListaPagamentoConfirmado.RowHeadersWidth = 51;
            this.dgvListaPagamentoConfirmado.RowTemplate.Height = 24;
            this.dgvListaPagamentoConfirmado.Size = new System.Drawing.Size(421, 604);
            this.dgvListaPagamentoConfirmado.TabIndex = 17;
            this.dgvListaPagamentoConfirmado.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListaPagamentoConfirmado_CellContentClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvListaPagamentoConfirmado);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(946, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(469, 671);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lista de Pagamento";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Moccasin;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(985, 697);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(478, 69);
            this.label4.TabIndex = 18;
            this.label4.Text = "Os botões \"Salvar\" e \"Editar\" que se encotra dentro da tabela\r\nso podem se utiliz" +
    "ados para alterar os dados de pagamento\r\njá existentes.";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(781, 442);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(98, 41);
            this.btnCancelar.TabIndex = 19;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // Pagamentos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1499, 787);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtPassageiro);
            this.Controls.Add(this.dgvListaAgendados);
            this.Controls.Add(this.btnSalvarPagamentos);
            this.Controls.Add(this.cmbStatusPagamento);
            this.Controls.Add(this.cmbFormaPagamento);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtValor);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dtpPagamento);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Pagamentos";
            this.Text = "Pagamentos";
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaAgendados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaPagamentoConfirmado)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpPagamento;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbFormaPagamento;
        private System.Windows.Forms.ComboBox cmbStatusPagamento;
        private System.Windows.Forms.Button btnSalvarPagamentos;
        private System.Windows.Forms.DataGridView dgvListaAgendados;
        private System.Windows.Forms.TextBox txtPassageiro;
        private System.Windows.Forms.DataGridView dgvListaPagamentoConfirmado;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnCancelar;
    }
}