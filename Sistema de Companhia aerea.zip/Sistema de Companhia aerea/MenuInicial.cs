﻿using System;
using System.Data;
using System.Windows.Forms;
using System.IO;

namespace Sistema_de_compainha_aerea
{
    public partial class MenuInicial : Form
    {
        public MenuInicial()
        {
            InitializeComponent();
        }

        private void btnentraFuncionariosSetores_Click(object sender, EventArgs e)
        {
            GerenciamentoFuncionarioeSetores gerenciamento = new GerenciamentoFuncionarioeSetores();
            gerenciamento.Show();
        }

        private void btnFuncionariosSetores_Click(object sender, EventArgs e)
        {
            GerenciamentoFuncionarioeSetores gerenciamento = new GerenciamentoFuncionarioeSetores();
            gerenciamento.Show();
        }

        private void btnChecking_Click(object sender, EventArgs e)
        {
            ClassePassageiros classepassageiro = new ClassePassageiros();
            classepassageiro.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ClassePassageiros classepassageiro = new ClassePassageiros();
            classepassageiro.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClassePassageiros classepassageiro = new ClassePassageiros();
            classepassageiro.Show();
        }

        private void btnAgendamento_Click(object sender, EventArgs e)
        {
            agendamento Agendamento = new agendamento();
            Agendamento.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            agendamento Agendamento = new agendamento();
            Agendamento.Show();
        }

        private void btnVoos_Click(object sender, EventArgs e)
        {
            Voos voos = new Voos();
            voos.Show();
        }

        private void txtFuncionarioSetores_TextChanged(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario();
            dgvFuncionariosSetores.DataSource = funcionario.PesquisarFuncionario(txtFuncionarioSetores.Text);
        }

        private void cmbFuncionariosSetores_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFuncionariosSetores.SelectedIndex == -1)
                return;

            DataRowView setorSelecionado = cmbFuncionariosSetores.SelectedItem as DataRowView;

            if (setorSelecionado == null)
                return;

            int idSetor = Convert.ToInt32(setorSelecionado["ID_SETOR"]);

            Funcionario funcionario = new Funcionario();

            DataTable funcionarios = funcionario.ListarFuncionarios();

            DataView filtro = funcionarios.DefaultView;
            filtro.RowFilter = "ID_SETOR = " + idSetor;

            dgvFuncionariosSetores.DataSource = filtro;

            dgvFuncionariosSetores.Columns["ID_FUNCIONARIO"].Visible = false;
            dgvFuncionariosSetores.Columns["CPF_FUNCIONARIO"].Visible = false;
            dgvFuncionariosSetores.Columns["TELEFONE_FUNCIONARIO"].Visible = false;
            dgvFuncionariosSetores.Columns["EMAIL_FUNCIONARIO"].Visible = false;
            dgvFuncionariosSetores.Columns["CARGO"].Visible = false;
            dgvFuncionariosSetores.Columns["ID_SETOR"].Visible = false;
            dgvFuncionariosSetores.Columns["SALARIOS"].Visible = false;
            dgvFuncionariosSetores.Columns["DATA_ADMISSAO"].Visible = false;
            dgvFuncionariosSetores.Columns["IMAGEM_FUNCIONARIO"].Visible = false;
            dgvFuncionariosSetores.Columns["NOME_FUNCIONARIO"].HeaderText = "Funcionário";
            dgvFuncionariosSetores.Columns["NOME_SETOR"].HeaderText = "Setor";
        }

        private void MenuInicial_Load(object sender, EventArgs e)
        {          
            Setor setor = new Setor();

            cmbFuncionariosSetores.DataSource = setor.ListarSetores();
            cmbFuncionariosSetores.DisplayMember = "NOME_SETOR";
            cmbFuncionariosSetores.ValueMember = "ID_SETOR";
            cmbFuncionariosSetores.SelectedIndex = -1;

            Passageiro passageiro = new Passageiro();
            DataTable dadosEconomica = passageiro.ListarPassageiros();
            DataView filtro = dadosEconomica.DefaultView;
            filtro.RowFilter = "CLASSE = 'Econômica'";


            dgvEconomica.DataSource = filtro;
            dgvEconomica.Columns["ID_PASSAGEIRO"].Visible = false;
            dgvEconomica.Columns["CPF_PASSAGEIRO"].Visible = false;
            dgvEconomica.Columns["CONTATO_PASSAGEIRO"].Visible = false;
            dgvEconomica.Columns["EMAIL_PASSAGEIRO"].Visible = false;
            dgvEconomica.Columns["DATA_NASCIMENTO"].Visible = false;
            dgvEconomica.Columns["NACIONALIDADE"].Visible = false;
            dgvEconomica.Columns["PASSAPORTE"].Visible = false;
            dgvEconomica.Columns["SEXO"].Visible = false;
            dgvEconomica.Columns["IMAGEM"].Visible = false;
            dgvEconomica.Columns["MILHAS"].Visible = false;
            dgvEconomica.Columns["OBSERVACAO"].Visible = false;
            dgvEconomica.Columns["NOME_PASSAGEIRO"].HeaderText = "Passageiro";
            dgvEconomica.Columns["CLASSE"].HeaderText = "Classe";

            Passageiro passageiroVip = new Passageiro();
            DataTable dadosVip = passageiroVip.ListarPassageiros();
            DataView filtroVip = dadosVip.DefaultView;
            filtroVip.RowFilter = "CLASSE = 'VIP'";
            dgvVip.DataSource = filtroVip;

            dgvVip.Columns["ID_PASSAGEIRO"].Visible = false;
            dgvVip.Columns["CPF_PASSAGEIRO"].Visible = false;
            dgvVip.Columns["CONTATO_PASSAGEIRO"].Visible = false;
            dgvVip.Columns["EMAIL_PASSAGEIRO"].Visible = false;
            dgvVip.Columns["DATA_NASCIMENTO"].Visible = false;
            dgvVip.Columns["NACIONALIDADE"].Visible = false;
            dgvVip.Columns["PASSAPORTE"].Visible = false;
            dgvVip.Columns["SEXO"].Visible = false;
            dgvVip.Columns["IMAGEM"].Visible = false;
            dgvVip.Columns["MILHAS"].Visible = false;
            dgvVip.Columns["OBSERVACAO"].Visible = false;
            dgvVip.Columns["NOME_PASSAGEIRO"].HeaderText = "Passageiro";
            dgvVip.Columns["CLASSE"].HeaderText = "Classe";

            Voo voo = new Voo();
            DataTable dadosVoos = voo.ListarVoos();
            dgvVoos.DataSource = dadosVoos;

            dgvVoos.Columns["ID_VOO"].Visible = false;
            dgvVoos.Columns["TIPO_VOO"].Visible = false;
            dgvVoos.Columns["DATA_HORA_CHEGADA"].Visible = false;
            dgvVoos.Columns["PORTAO"].Visible = false;
            dgvVoos.Columns["TERMINAL"].Visible = false;
            dgvVoos.Columns["STATUS"].HeaderText = "Status";
            dgvVoos.Columns["ORIGEM"].HeaderText = "Origem";
            dgvVoos.Columns["DESTINO"].HeaderText = "Destino";
            dgvVoos.Columns["DATA_HORA_PARTIDA"].HeaderText = "Hora";

            Pagamento pagamento = new Pagamento();
            DataTable dados = pagamento.ListarPagamentos();

            dgvExibirPagamentos.DataSource = dados;

            dgvExibirPagamentos.Columns["ID_PAGAMENTO"].Visible = false;
            dgvExibirPagamentos.Columns["VALOR"].Visible = false;
            dgvExibirPagamentos.Columns["DATA_PAGAMENTO"].Visible = false;
            dgvExibirPagamentos.Columns["NOME_PASSAGEIRO"].HeaderText = "Passageiro";
            dgvExibirPagamentos.Columns["NOME_PASSAGEIRO"].Width = 200;
            dgvExibirPagamentos.Columns["STATUS_PAGAMENTO"].HeaderText = "Pagamentos";           
            dgvExibirPagamentos.Columns["STATUS_PAGAMENTO"].Width = 120;
        }

        private void dgvFuncionariosSetores_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtFuncionarioSetores.Text = dgvFuncionariosSetores.Rows[e.RowIndex].Cells["NOME_FUNCIONARIO"].Value.ToString();
            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Pagamentos pagamentos = new Pagamentos();
            pagamentos.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Pagamentos pagamentos = new Pagamentos();
            pagamentos.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            RelatorioAeroporto relatorio = new RelatorioAeroporto();
            relatorio.Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            RelatorioAeroporto relatorio = new RelatorioAeroporto();
            relatorio.Show();
        }

        private void MenuInicial_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

    }
}
