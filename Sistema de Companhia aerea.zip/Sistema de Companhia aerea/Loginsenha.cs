﻿namespace Sistema_de_compainha_aerea
{
    public class Loginsenha
    {
        public string Login { get; set; }

        public string Senha { get; set; } = string.Empty;

        public bool ValidarLogin(string login, string senha)
        {
            // Aqui você pode implementar a lógica de validação do login e senha
            // Por exemplo, verificar se o login e senha correspondem a valores esperados
            // Retorne true se o login for válido, caso contrário, retorne false
            // Exemplo simples de validação (substitua com sua lógica real):
            if (login == "admin" && senha == "1234")
            {
                return true; // Login válido
            }
            else
            {
                return false; // Login inválido
            }
        }
    }
}
