﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Sistema_de_compainha_aerea
{
    public partial class Voos : Form
    {
        int idVoo = 0;
        public Voos()
        {
            InitializeComponent();
        }

        private void Voos_Load(object sender, EventArgs e)
        {
            CarregarVoos();
        }

        private void btnSalvarVoos_Click(object sender, EventArgs e)
        {
            try
            {
                Voo voo = new Voo();

                string tipoVoo = cmbTipoVoo.Text;
                string origem = txtOrigem.Text;
                string destino = txtDestino.Text;
                DateTime dataHoraPartida = dtpDataPartida.Value.Date.Add(dtpHoraPartida.Value.TimeOfDay);
                DateTime dataHoraChegada = dtpDataChegada.Value.Date.Add(dtpHoraChegada.Value.TimeOfDay);
                string portao = cmbPortao.Text;
                string terminal = cmbTerminal.Text;
                string status = cmbStatusVoos.Text;

                if(idVoo == 0)
                {
                    voo.Salvarvoos(tipoVoo, origem, destino, dataHoraPartida, dataHoraChegada, portao, terminal, status);


                    MessageBox.Show("Voo salvo com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    voo.AlterarVoos(idVoo, tipoVoo, origem, destino, dataHoraPartida, dataHoraChegada, portao, terminal, status);

                    MessageBox.Show("Voo alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                LimparCamposVoos();
                txtOrigem.Focus();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro no método Salvar", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show(ex.Message);
               
            }
        }

        private void btnNovoVoo_Click(object sender, EventArgs e)
        {
            LimparCamposVoos();
            txtOrigem.Focus();
        }

        private void btnLimparVoo_Click(object sender, EventArgs e)
        {
            LimparCamposVoos();
        }

        private void btnExcluirvoos_Click(object sender, EventArgs e)
        {
            try
            {
                if(idVoo == 0)
                {
                    MessageBox.Show("Selecione um voo para excluir");
                    return;
                }

                DialogResult resposta = MessageBox.Show("Tem certeza que deseja excluir voo?", "Confirma exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if(resposta == DialogResult.No)
                {
                    return;
                }
                Voo voo = new Voo();
                voo.ExcluirVoos(idVoo);

                MessageBox.Show("Voo excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro no método Excluír", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show(ex.Message);
            }
            LimparCamposVoos();
            CarregarVoos();
        }

        private void CarregarVoos()
        {
            Voo voo = new Voo();

            dgvVoos.DataSource = voo.ListarVoos();

            dgvVoos.Columns["ID_VOO"].HeaderText = "Nº Voos";
            dgvVoos.Columns["ID_VOO"].Width = 70;
            dgvVoos.Columns["TIPO_VOO"].HeaderText = " Tipo de voo";
            dgvVoos.Columns["TIPO_vOO"].Width = 100;
            dgvVoos.Columns["ORIGEM"].HeaderText = "Origem";
            dgvVoos.Columns["ORIGEM"].Width = 110;
            dgvVoos.Columns["DESTINO"].HeaderText = "Destino";
            dgvVoos.Columns["DESTINO"].Width = 110;
            dgvVoos.Columns["DATA_HORA_PARTIDA"].HeaderText = "Partida";
            dgvVoos.Columns["DATA_HORA_PARTIDA"].Width = 150;
            dgvVoos.Columns["DATA_HORA_CHEGADA"].HeaderText = "Chegada";
            dgvVoos.Columns["DATA_HORA_CHEGADA"].Width = 150;
            dgvVoos.Columns["PORTAO"].HeaderText = "Portâo";
            dgvVoos.Columns["PORTAO"].Width = 120;
            dgvVoos.Columns["TERMINAL"].HeaderText = "Terminal";
            dgvVoos.Columns["TERMINAL"].Width = 120;
            dgvVoos.Columns["STATUS"].HeaderText = "Status";
            dgvVoos.Columns["STATUS"].Width = 120;

            if (!dgvVoos.Columns.Contains("EditarVoos"))
            {
                DataGridViewButtonColumn btnEditar = new DataGridViewButtonColumn();

                btnEditar.Name = "EditarVoos";
                btnEditar.HeaderText = "Editar";
                btnEditar.Text = "Editar";
                btnEditar.UseColumnTextForButtonValue = true;
                dgvVoos.Columns.Add(btnEditar);
            }
        }

        private void dgvVoos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dgvVoos.Columns["EditarVoos"].Index)
            {
                idVoo = Convert.ToInt32(dgvVoos.Rows[e.RowIndex].Cells["ID_VOO"].Value);
                label44.Text = idVoo.ToString();
                label45.Text =
                cmbTipoVoo.Text = dgvVoos.Rows[e.RowIndex].Cells["TIPO_VOO"].Value.ToString();
                label46.Text =
                txtOrigem.Text = dgvVoos.Rows[e.RowIndex].Cells["ORIGEM"].Value.ToString();
                label47.Text = 
                txtDestino.Text = dgvVoos.Rows[e.RowIndex].Cells["DESTINO"].Value.ToString();
                label48.Text = 
                Convert.ToDateTime(dgvVoos.Rows[e.RowIndex].Cells["DATA_HORA_PARTIDA"].Value).ToString("dd/MM/yyyy");
                label49.Text =
                Convert.ToDateTime(dgvVoos.Rows[e.RowIndex].Cells["DATA_HORA_CHEGADA"].Value).ToString("dd/MM/yyyy");
                label23.Text =
                cmbPortao.Text = dgvVoos.Rows[e.RowIndex].Cells["PORTAO"].Value.ToString();
                label25.Text =
                cmbTerminal.Text = dgvVoos.Rows[e.RowIndex].Cells["TERMINAL"].Value.ToString();
                cmbStatusVoos.Text = dgvVoos.Rows[e.RowIndex].Cells["STATUS"].Value.ToString();
            }
        }

       private void LimparCamposVoos()
        {
            cmbTipoVoo.SelectedIndex = -1;
            txtOrigem.Clear();
            txtDestino.Clear();
            dtpDataPartida.Value = DateTime.Now;
            dtpDataChegada.Value = DateTime.Now;
            cmbPortao.SelectedIndex = -1;
            cmbTerminal.SelectedIndex = -1;
            cmbStatusVoos.SelectedIndex = -1;
            idVoo = 0;
            label44.Text = "";
            label45.Text = "";
            label46.Text = "";
            label47.Text = "";
            label48.Text = "";
            label49.Text = "";
            label23.Text = "";
            label25.Text = "";
            label36.Text = "";
            label37.Text = "";
            label38.Text = "";
            label39.Text = "";
            label40.Text = "";
            label41.Text = "";
            label42.Text = "";
        }

        private void btnBuscarVoos_Click(object sender, EventArgs e)
        {
            try
            {
                Voo voo = new Voo();
                string Pesquisarvoo = txtBuscarVoos.Text;
                DateTime data = dtpBuscarDataVoo.Value;

                dgvVoos.DataSource = voo.Pesquisarvoo(Pesquisarvoo, data);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void txtBuscarVoos_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Voo voo = new Voo();
                string Pesquisarvoo = txtBuscarVoos.Text;
                DateTime data = dtpBuscarDataVoo.Value;

                dgvVoos.DataSource = voo.Pesquisarvoo(Pesquisarvoo, data);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void cmbTipoVoo_SelectedIndexChanged(object sender, EventArgs e)
        {
            label36.Text = cmbTipoVoo.Text;
        }

        private void txtOrigem_TextChanged(object sender, EventArgs e)
        {
            label37.Text = txtOrigem.Text;
        }

        private void txtDestino_TextChanged(object sender, EventArgs e)
        {
            label38.Text = txtDestino.Text;
        }

        private void dtpDataPartida_ValueChanged(object sender, EventArgs e)
        {
            label39.Text = dtpDataPartida.Value.ToString("dd/MM/yyyy");
        }

        private void dtpHoraPartida_ValueChanged(object sender, EventArgs e)
        {
            label40.Text = dtpDataPartida.Value.ToString("HH:mm");
        }

        private void cmbPortao_SelectedIndexChanged(object sender, EventArgs e)
        {
            label41.Text = cmbPortao.Text;
        }

        private void cmbTerminal_SelectedIndexChanged(object sender, EventArgs e)
        {
            label42.Text = cmbTerminal.Text;
        }
    }
 }
