﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_de_compainha_aerea
{
    public partial class agendamento : Form
    {
        int idVooSelecionado = 0;
        int idPassageiroSelecionado = 0;
        public agendamento()
        {
            InitializeComponent();
        }

        private void Pesquisarporvoos_Click(object sender, EventArgs e)
        {
            Voo voo = new Voo();
            DataTable dadosVoos = voo.PesquisarVoosAgendamento(txtorigemvoo.Text, txtDestinovoo.Text, dtpdatavoo.Value);
            dgvVoosEncontrados.DataSource = dadosVoos;

            if (dadosVoos.Rows.Count == 0)

            {
                MessageBox.Show("Voo não encontrado.");
                dgvVoosEncontrados.DataSource = null;
                return;
            }

            dgvVoosEncontrados.DataSource = dadosVoos;

            dgvVoosEncontrados.Columns["ID_VOO"].HeaderText = "Código";
            dgvVoosEncontrados.Columns["TIPO_VOO"].HeaderText = "Tipo de Voo";
            dgvVoosEncontrados.Columns["ORIGEM"].HeaderText = "Origem";
            dgvVoosEncontrados.Columns["DESTINO"].HeaderText = "Destino";
            dgvVoosEncontrados.Columns["DATA_HORA_PARTIDA"].HeaderText = "Data Partida";
            dgvVoosEncontrados.Columns["DATA_HORA_CHEGADA"].HeaderText = "Data Chegada";
            dgvVoosEncontrados.Columns["PORTAO"].HeaderText = "Portão";
            dgvVoosEncontrados.Columns["TERMINAL"].HeaderText = "Terminal";
            dgvVoosEncontrados.Columns["STATUS"].HeaderText = "Status";

        }

        private void dgvVoosEncontrados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                idVooSelecionado = Convert.ToInt32(dgvVoosEncontrados.Rows[e.RowIndex].Cells["ID_VOO"].Value);
            }

            string tipoVoo = dgvVoosEncontrados.Rows[e.RowIndex].Cells["TIPO_VOO"].Value.ToString();
        }

        private void btnConfirmaVoo_Click(object sender, EventArgs e)
        {
            if (idVooSelecionado == 0)
            {
                MessageBox.Show("Selecione um voo.");
                return;
            }

            Voo voo = new Voo();
            voo.AlterarStatusVoo(idVooSelecionado, "Confirmado");
            MessageBox.Show("Voo confirmado com sucesso.");
            idVooSelecionado = 0;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (idVooSelecionado == 0)
            {
                MessageBox.Show("Selecione um voo.");
                return;
            }

            Voo voo = new Voo();
            voo.AlterarStatusVoo(idVooSelecionado, "Cancelado");
            MessageBox.Show("Voo cancelado com sucesso.");
            idVooSelecionado = 0;
        }

        private void btnAtulizarvoos_Click(object sender, EventArgs e)
        {
            Voo voo = new Voo();

            DataTable dados = voo.PesquisarVoosAgendamento(txtorigemvoo.Text, txtDestinovoo.Text, dtpdatavoo.Value);

            dgvVoosEncontrados.DataSource = dados;
        }

        private void btnPesquisarPassageiroagendamento_Click(object sender, EventArgs e)
        {
            try
            {
                Passageiro passageiro = new Passageiro();
                DataTable dados = passageiro.PesquisarPassageiro("", txtcpfPassageiroAgendamento.Text, txtPassaporteAgendamento.Text);
                dgvListaAgendamento.DataSource = dados;

                if (dados.Rows.Count == 0)
                {
                    MessageBox.Show("Passageiro não encontrado! Verifique se o passageiro está cadastrado");
                    dgvListaAgendamento.DataSource = null;
                    return;
                }

                dgvListaAgendamento.DataSource = dados;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao pesquisar passageiro: " + ex.Message);
            }
        }

        private void btnConsultarPassageiro_Click(object sender, EventArgs e)
        {
            ClassePassageiros classepassageiro = new ClassePassageiros();
            classepassageiro.Show();
        }

        private void dgvListaAgendamento_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                idPassageiroSelecionado = Convert.ToInt32(
                    dgvListaAgendamento.Rows[e.RowIndex].Cells["ID_PASSAGEIRO"].Value
                );
            }
        }

        private void btnConfirmarAgendamento_Click(object sender, EventArgs e)
        {
            try
            {
                if (idPassageiroSelecionado == 0)
                {
                    MessageBox.Show("Selecione um passageiro.");
                    return;
                }

                string statusVoo = "";

                foreach (DataGridViewRow linha in dgvVoosEncontrados.Rows)
                {
                    if (linha.Cells["ID_VOO"].Value != null && Convert.ToInt32(linha.Cells["ID_VOO"].Value) == idVooSelecionado)
                    {
                        statusVoo = linha.Cells["STATUS"].Value.ToString();
                        break;
                    }
                }

                if (statusVoo == "Cancelado")
                {
                    MessageBox.Show("Este voo está cancelado e não pode ser agendado.");
                    return;
                }

                if (idVooSelecionado == 0)
                {
                    MessageBox.Show("Selecione um voo.");
                    return;
                }

                PassageirosVoos passageirosVoos = new PassageirosVoos();
                passageirosVoos.SalvarPassageiroVoo(idPassageiroSelecionado, idVooSelecionado);
                DialogResult resposta = MessageBox.Show("Deseja confirmar este agendamento?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                PreencherCartaoEmbarque();

                if (resposta == DialogResult.No)
                {
                    return;
                }

                MessageBox.Show("Agendamento confirmado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao confirmar o agendamento: " + ex.Message);
            }
        }

        private void btnRemoverAgendamento_Click(object sender, EventArgs e)
        {
            try
            {
                if (idPassageiroSelecionado == 0)
                {
                    MessageBox.Show("Selecione um passageiro.");
                    return;
                }

                if (idVooSelecionado == 0)
                {
                    MessageBox.Show("Selecione um voo.");
                    return;
                }

                DialogResult resposta = MessageBox.Show("Deseja cancelar este agendamento?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resposta == DialogResult.No)
                {
                    return;
                }

                PassageirosVoos passageirosVoos = new PassageirosVoos();
                passageirosVoos.ExcluirPassageiroVoo(
                    idPassageiroSelecionado,
                    idVooSelecionado
                );

                MessageBox.Show("Agendamento cancelado com sucesso!");

                idPassageiroSelecionado = 0;
                idVooSelecionado = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cancelar o agendamento: " + ex.Message);
            }
        }

        private void btnLimparDadosAgendamento_Click(object sender, EventArgs e)
        {
            txtcpfPassageiroAgendamento.Clear();
            txtPassaporteAgendamento.Clear();
            txtorigemvoo.Clear();
            txtDestinovoo.Clear();
            dgvListaAgendamento.DataSource = null;
            dgvVoosEncontrados.DataSource = null;
            idPassageiroSelecionado = 0;
            idVooSelecionado = 0;

            lbNomePassageiroCartao.Text = "---";
            lbClasse.Text = "---";
            lbOrigemCartao.Text = "---";
            lbDestinoCartao.Text = "---";
            lbVooCartao.Text = "---";
            lbDatacartao.Text = "---";
            lbHoraCartao.Text = "---";
            lbportao.Text = "---";
            lbTerminal.Text = "---";
        }

        private void PreencherCartaoEmbarque()
        {
            DataGridViewRow passageiro = null;
            DataGridViewRow voo = null;

            foreach (DataGridViewRow linha in dgvListaAgendamento.Rows)
            {
                if (linha.Cells["ID_PASSAGEIRO"].Value != null && Convert.ToInt32(linha.Cells["ID_PASSAGEIRO"].Value) == idPassageiroSelecionado)
                {
                    passageiro = linha;
                    break;
                }
            }

            foreach (DataGridViewRow linha in dgvVoosEncontrados.Rows)
            {
                if (linha.Cells["ID_VOO"].Value != null && Convert.ToInt32(linha.Cells["ID_VOO"].Value) == idVooSelecionado)
                {
                    voo = linha;
                    break;
                }
            }

            if (passageiro == null || voo == null)
            {
                MessageBox.Show("Não foi possível carregar os dados do cartão de embarque.");
                return;
            }

            lbNomePassageiroCartao.Text = passageiro.Cells["NOME_PASSAGEIRO"].Value.ToString();
            lbClasse.Text = passageiro.Cells["CLASSE"].Value.ToString();
            lbOrigemCartao.Text = voo.Cells["ORIGEM"].Value.ToString();
            lbDestinoCartao.Text = voo.Cells["DESTINO"].Value.ToString();
            lbVooCartao.Text = voo.Cells["DESTINO"].Value.ToString();
            lbDatacartao.Text = Convert.ToDateTime(voo.Cells["DATA_HORA_PARTIDA"].Value).ToString("dd/MM/yyyy");
            lbHoraCartao.Text = Convert.ToDateTime(voo.Cells["DATA_HORA_PARTIDA"].Value).ToString("HH:mm");
            lbportao.Text = voo.Cells["PORTAO"].Value.ToString();
            lbTerminal.Text = voo.Cells["TERMINAL"].Value.ToString();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap imagem = new Bitmap(pnlCartaoEmbarque.Width, pnlCartaoEmbarque.Height);

            pnlCartaoEmbarque.DrawToBitmap(
                imagem,
                new Rectangle(0, 0, pnlCartaoEmbarque.Width, pnlCartaoEmbarque.Height)
            );

            e.Graphics.DrawImage(imagem, 50, 50);
        }

        private void btnimprimircartao_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }
    }
}
